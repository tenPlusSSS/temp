# GLM-5.2 PCP decode LB 测试包

**服务器 agent 请先读 [SERVER_AGENT_RUNBOOK.md](SERVER_AGENT_RUNBOOK.md)，按顺序执行。**

用户确认的环境：A3 16 卡，TP=2、PCP=8，不开 MTP。本包进一步固定 DP=1、PP=1、DCP=1，
采用 V2 runner、FULL_DECODE_ONLY、异步调度、前缀缓存和 chunked prefill。
主测试 16 个请求，扩展测试 32 个请求；所有性能用例以每请求约 90% 输入 token 命中前缀缓存为目标。

| 文件 | 用途 |
| --- | --- |
| `SERVER_AGENT_RUNBOOK.md` | 从环境核对、服务拉起到 ABBA 和报告的完整执行顺序 |
| `serve.sh` / `launch_server.py` | 前台启动 RR/LB，保存配置、命令、版本和补丁哈希 |
| `server_config.json` | A3 W8A8C8 配置模板；模型路径需填写或通过命令传入 |
| `preflight.py` / `code_requirements.json` | 只读核对安装源码和模型配置；不自动升级环境 |
| `production/pcp_load_balance_main.patch` | 针对固定 ascend 主干基线的生产补丁 |
| `prepare_data.py` / `cases.py` | 构造并保存精确 token-ID 输入数据 |
| `run_group.py` / `run_serving.py` | 运行已启动服务上的 smoke、诊断或性能测试 |
| `prefix_cache.py` | 每轮缓存预热、精确计数验证、污染/抢占检查 |
| `pcp_trace.py` / `inspect_trace.py` | 验证 TP2 × PCP8 的实际请求放置、图尺寸、轮询回退 |
| `compare.py` / `review_outputs.py` | 吞吐比较、输出 token 首次分歧定位 |
| `TEST_STRATEGY.md` / `REPORT_TEMPLATE.md` | 数据口径、接受条件和报告模板 |
| `analyze.py` / `model_estimates.json` | 真实规划方法的 CPU cost 估算，不能当作 NPU 性能 |
| `VALIDATION.md` / `manifest.json` | 本机验证范围、文件完整性哈希 |

本包使用的固定版本：

- vllm-ascend：`a1df499e0762621c2b9561e2ee66c498a70d0328` + 附带补丁。
- vLLM：`ba15685ab7f4f5fbed8630bbb7441f8837e76fbe`。
- 此次模板按 A3 W8A8C8 权重的 Ascend 量化、主 KV int8、indexer KV int8 编写。
  用户尚未提供具体权重路径和量化变体，服务器 agent 必须核对实际权重；不能仅根据目录名字认定兼容。

这里没有 GLM-5.2 真机通过或收益声明。16 卡 TP2/PCP8 是用户指定的实验拓扑，
65536 长度和 16/32 并发是否能装下，需要实际验证。

接口已按配套源码核对：[CLI 入口](https://github.com/vllm-project/vllm/blob/ba15685ab7f4f5fbed8630bbb7441f8837e76fbe/vllm/entrypoints/cli/main.py)、
[Completion token-ID/stream/cache_salt 协议](https://github.com/vllm-project/vllm/blob/ba15685ab7f4f5fbed8630bbb7441f8837e76fbe/vllm/entrypoints/openai/completion/protocol.py)。
本机完成的检查见 `VALIDATION.md`。
