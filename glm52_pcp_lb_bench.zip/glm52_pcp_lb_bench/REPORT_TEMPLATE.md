# GLM-5.2 PCP8 / TP2 LB 报告

## 环境

- 日期、A3 型号/设备数、主机和独占情况：
- 权重来源、版本、量化、模型 config 哈希：
- vLLM / vllm-ascend commit、补丁哈希、实际 Python import 路径：
- CANN、驱动、torch/torch_npu：
- 完整启动命令及 server_config：
- TP2/PCP8/DP1/PP1/DCP1、无投机：
- batch、max_model_len、factor、图捕获集合：

## 机制与正确性

| case | 两个 TP 的八个 PCP rank 完整 | LB 状态/移动请求数 | RR→LB 最大实际 tokens | graph tokens/rows | 最大 cost 变化 | 输出检查状态 |
| --- | --- | --- | --- | --- | --- | --- |

说明 scheduler 是否保留构造时的碰撞顺序；图桶是否变化；真实输出分歧及调查结论。

## 缓存与窗口

- 每请求目标约 90%，实际块对齐比率及 token hits/queries：
- 缓存预热时间是否排除、各轮是否使用新 salt：
- 每波 preemptions=0、prefix_cache_verified、valid_window：
- 输出长度、窗口开始/结束 token 数、是否存在 batch 缩小或额外流量：

## 性能

| case | rr_a 三次 TPS | lb_a 三次 TPS | lb_b 三次 TPS | rr_b 三次 TPS | RR/LB 中位数 | gain | RR/LB TPOT |
| --- | --- | --- | --- | --- | --- | --- | --- |

另报各组中位数、同策略波动范围、TTFT、E2E；说明重启顺序和不合格波次。
不同 batch、输出预算、缓存条件、图桶或配置指纹必须分别报告。

## 结论与下一步

机制有效 / 未触发 / 证据不足：
正确性已验证范围 / 待调查差异：
有可测收益 / 无可测收益 / 样本不足：
如有 profiler，列出实际关键路径耗时及占比；代理 cost 不作为设备时间。
失败、OOM、排除用例及原因：
完整结果目录与日志路径：
