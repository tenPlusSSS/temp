# 给服务器 agent 的执行说明

## 0. 固定目标

在用户指定的 **A3 16 卡、TP2、PCP8、无 MTP** 环境，比较本次修改的 `round_robin` 与 `load_balance`。
DP/PP/DCP 均设为 1，factor=1.5。先完成 16 请求主测试；32 请求和 48K/60K 为独立扩展。
保留正、零、负收益，不以复现某个正收益为通过条件。

本包的策略、数据和输出判据见 `TEST_STRATEGY.md`。本机尚未跑过这个 GLM/NPU 组合。
运行时不得替换其他业务服务，不使用广泛匹配的 kill/pkill。只停止本实验自己启动的进程。
端口或设备仍被其他任务占用时，记录阻塞；不修改其他任务。

## 1. 环境和权重核对

将本包解压到新目录。先读取本机 GLM-5.2 权重来源、`config.json`、量化描述和已有运行配置，
确认是 GLM-5.2，并记录权重版本。架构名相同不能证明它不是 GLM-5.3。

`server_config.json` 是 W8A8C8 模板：`quantization=ascend`、主 KV int8、indexer KV int8。
如果实际权重不同，以该权重已验证的量化设置修改此文件，并在 RR/LB 全程保持一致。
本模板直接测 `/v1/completions` 的 token-ID 输入，不使用 DeepSeek tokenizer/parser，也不需要 chat/tool-call parser。
确认 `visible_devices` 是授权用于本实验的 16 个逻辑设备。

使用已经配置好 CANN/torch_npu 的 A3 Python 环境。通信参数沿用该服务器已有可用配置；
脚本不猜测网卡、不自动改 HCCL。记录 `npu-smi info`、CANN/驱动版本和启动日志。

```bash
set -euo pipefail
cd /absolute/path/to/glm52_pcp_lb_bench
export BENCH_DIR="$(pwd -P)"
export MODEL_PATH=/actual/path/to/GLM-5.2-w8a8c8
export RUN_ROOT="$(mktemp -d "$BENCH_DIR/run-glm52-$(date +%Y%m%d-%H%M%S)-XXXXXX")"
python -m unittest -v test_bench.py test_glm52.py 2>&1 | tee "$RUN_ROOT/cpu-tests.log"
npu-smi info > "$RUN_ROOT/npu-info.txt"
```

将 BENCH_DIR、MODEL_PATH、RUN_ROOT 三个绝对路径记录下来，所有后续终端复用，不能重新创建不同的 RUN_ROOT。

源码固定为：

- vLLM `ba15685ab7f4f5fbed8630bbb7441f8837e76fbe`。
- vllm-ascend `a1df499e0762621c2b9561e2ee66c498a70d0328` 加 `production/pcp_load_balance_main.patch`。

若当前已正确安装，直接验证。若未安装，在独立测试 checkout/环境内按上述版本构建，保留旧环境。
不要在旧 PR 修改上叠加这个 patch，不要重置用户工作树。对干净的指定 ascend 基线执行：

```bash
# 当前目录必须是独立的、已 checkout 到指定基线的 vllm-ascend 仓库。
git apply --check "$BENCH_DIR/production/pcp_load_balance_main.patch"
git apply "$BENCH_DIR/production/pcp_load_balance_main.patch"
python -m pip install -e . --no-build-isolation
```

这只安装 ascend 插件；vLLM 自身及 CANN/torch_npu 构建环境必须另外对齐。
回到测试包并执行只读检查：

```bash
cd "$BENCH_DIR"
python preflight.py --model-path "$MODEL_PATH" --output "$RUN_ROOT/preflight.json"
bash serve.sh round_robin perf --model-path "$MODEL_PATH" \
  --run-dir "$RUN_ROOT/dry-run" --dry-run > "$RUN_ROOT/command-preview.txt"
```

preflight 会检查实际 Python import 的源码路径、HEAD、四个生产文件的 LF 归一化哈希和模型配置，
并记录 tracked diff 哈希及工作树状态。检查状态里的额外修改和未跟踪源码，确保四组环境一致。
失败时修正实际环境；不要删除检查条件来得到通过。Git 无法证明版本的 wheel 安装需要先补源码/构建来源证据。
`--dry-run` 仅生成命令，不加载模型；它不能证明权重可用或显存足够。

在安装好的 ascend 源码目录中，用完整测试环境执行真实 UT 和仓库检查，并保存结果：

```bash
pytest -q tests/ut/worker/test_pcp_decode_balance.py \
  tests/ut/worker/test_pcp_manager_v2.py \
  tests/ut/worker/test_model_runner_v2.py tests/ut/test_ascend_config.py
bash format.sh ci
```

真实 UT 未执行或失败时必须报告，不能用本包的隔离 CPU 检查替代。四卡 E2E 的 DeepSeek 覆盖也不能替代 GLM 真机正确性回归。

## 2. 先拉起 RR 诊断服务

以下服务命令是**前台阻塞**命令。使用一个终端保留服务，另一个终端运行客户端。
每次启动使用新的 run-dir；`launch.json` 使用独占创建，防止覆盖旧实验。

服务终端：

```bash
mkdir -p "$RUN_ROOT/rr_trace"
set -o pipefail
bash "$BENCH_DIR/serve.sh" round_robin trace --model-path "$MODEL_PATH" \
  --run-dir "$RUN_ROOT/rr_trace" 2>&1 | tee "$RUN_ROOT/rr_trace/server.log"
```

启动脚本实际执行同一 Python 环境中的 `python -m vllm.entrypoints.cli.main serve`，
设置 16 个可见设备、V2 runner、TP2/PCP8、max_num_seqs=16、无任何 speculative-config。
默认 max_model_len=65536、max_num_batched_tokens=8192、block_size=32。
这些是实验配置，不是显存容量保证。启动失败时保留日志，再按第 7 节处理。

客户端终端：

```bash
curl -fsS http://127.0.0.1:50001/v1/models
cd "$BENCH_DIR"
python prepare_data.py --model glm52 --pcp 8 --requests-per-rank 2 \
  --out "$RUN_ROOT/data16" > "$RUN_ROOT/data16.log"
python run_group.py --stage smoke --run-dir "$RUN_ROOT/rr_trace" \
  --dataset-dir "$RUN_ROOT/data16"
```

确认返回模型名 glm52，服务日志来自上述启动进程。数据只生成一次，后续所有轮次读取同一 data16。
smoke 使用 2K/512、16 请求、每请求约 90% 缓存、输出 1024；它检查流式 token-ID、缓存计数和有效窗口，
不用于主收益结论。之后执行完整诊断：

```bash
python run_group.py --stage diagnostic --run-dir "$RUN_ROOT/rr_trace" \
  --dataset-dir "$RUN_ROOT/data16"
```

默认顺序：8K、16K、16K 均衡顺序、32K、32K 均衡顺序、uniform_8k、32K/8K 碰撞和均衡顺序、two_hot_32k。
每个用例 1 波，不做额外 warmup；但每波仍会执行缓存预热。
输出包括 results、client 日志、每用例 placement.txt / summary.jsonl，以及 pcp_trace 中每 worker 的日志。

## 3. 拉起 LB 诊断服务

正常结束本实验 RR 诊断服务，确认其 workers 退出、设备释放。服务终端：

```bash
mkdir -p "$RUN_ROOT/lb_trace"
set -o pipefail
bash "$BENCH_DIR/serve.sh" load_balance trace --model-path "$MODEL_PATH" \
  --run-dir "$RUN_ROOT/lb_trace" 2>&1 | tee "$RUN_ROOT/lb_trace/server.log"
```

服务就绪后，客户端：

```bash
python "$BENCH_DIR/run_group.py" --stage diagnostic --run-dir "$RUN_ROOT/lb_trace" \
  --dataset-dir "$RUN_ROOT/data16"
```

run_group 自动按完整 request_id 过滤该波 trace，要求 batch=16、TP=2，并检查全部 PCP rank。
两个 TP 切片各有八个 PCP rank；相同 pcp_rank 在不同 tp_rank 下是正常记录，不是重复数据。
每个 TP 切片内实际请求放置、c/q 和总 token 数必须与 owner 表一致，跨 TP 的 owner 和图尺寸也必须一致。

逐项记录：`tp_verification.verified`、`partition_verification.verified`、实际每 rank 请求/token 数、
graph tokens/rows、cost 分布、moved_request_count，以及以下状态：

| 状态 | 意义 |
| --- | --- |
| `rr_configured` | 服务配置为 RR |
| `lb_applied` | LB 计划的 owner 相对本轮 RR 发生变化 |
| `rr_retained` | LB 有计划但保留/回退轮询，具体回退原因未采集 |
| `rr_no_plan` | LB 配置下没有计划，需要核对路径 |
| `inconsistent_trace` | 日志证据不一致 |

hot_half 主用例若没有实际重分配，先核查 scheduler 实际顺序及加载代码，报告机制未触发。
负对照保持 RR 是正常现象；不能为了触发重新分配修改负对照。

## 4. 正式 ABBA

关闭诊断服务。正式轮必须以 perf 启动，不能仅关闭日志输出但保留 trace wrapper。
严格按四组顺序独立启动；每组中每个用例 1 warmup + 3 repeats。

| 顺序 | TAG | POLICY |
| --- | --- | --- |
| 1 | rr_a | round_robin |
| 2 | lb_a | load_balance |
| 3 | lb_b | load_balance |
| 4 | rr_b | round_robin |

每组服务终端执行下面的模板，按表设置 TAG/POLICY；上一组正常退出并释放设备后才执行下一组：

```bash
TAG=rr_a
POLICY=round_robin
mkdir -p "$RUN_ROOT/$TAG"
set -o pipefail
bash "$BENCH_DIR/serve.sh" "$POLICY" perf --model-path "$MODEL_PATH" \
  --run-dir "$RUN_ROOT/$TAG" 2>&1 | tee "$RUN_ROOT/$TAG/server.log"
```

每组服务就绪后，客户端设置同一个 TAG：

```bash
TAG=rr_a
python "$BENCH_DIR/run_group.py" --stage perf --run-dir "$RUN_ROOT/$TAG" \
  --dataset-dir "$RUN_ROOT/data16" --repeats 3
```

客户端策略取自 launch.json，不能用客户端标签切换服务策略。所有组使用完全相同的数据、case 顺序和输出长度。
每波新的缓存 salt 会避免不同重复轮间缓存命中变成 100%；输出文件仍记录实际缓存验证。

四组结束后：

```bash
python "$BENCH_DIR/compare.py" \
  "$RUN_ROOT/rr_a/results" "$RUN_ROOT/lb_a/results" \
  "$RUN_ROOT/lb_b/results" "$RUN_ROOT/rr_b/results" \
  --output "$RUN_ROOT/comparison.json"
python "$BENCH_DIR/review_outputs.py" \
  "$RUN_ROOT/rr_a/results" "$RUN_ROOT/lb_a/results" \
  "$RUN_ROOT/lb_b/results" "$RUN_ROOT/rr_b/results" \
  --output "$RUN_ROOT/output_review.json"
```

compare 拒绝 trace 数据、配置指纹不一致、输入/缓存条件不一致、抢占或缺失指标。
每用例应得到 RR 6 个、LB 6 个正式样本。必须另行保留 rr_a/lb_a/lb_b/rr_b 的组边界。

## 5. 32 请求扩展

在主实验完成后单独建立新 RUN_ROOT。所有 serve 命令增加 `--requests-per-rank 4`，
prepare_data 增加 `--requests-per-rank 4` 并保存 data32；run_group 会从 launch.json 自动读取 batch=32。
重复诊断和完整 ABBA，不能沿用 16 请求的放置证据或把两组样本混算。

## 6. 长上下文与混部补充

容量允许后可显式指定 `--cases hot_half_32k hot_half_48k hot_half_60k`，在新目录完成对应的两次诊断和完整 ABBA。
61440+1024=62464；输出 2048 时为 63488，均未超过 65536，但不保证 KV 内存能容纳。

本包正式指标截取无 prefill 的共同 decode 窗口。它可以回答 decode 优化是否生效；
不能单靠该指标判断真实混部的整体收益。混部收益另外报告包含剩余 prefill 的 E2E/TTFT，
若要模拟持续到达的业务流量，另立固定到达率、长度分布、缓存条件的实验，不与固定 batch 结果混算。

## 7. 失败处理与报告

- OOM/启动失败：保留配置和日志，不自动提高显存比例或改变 TP/PCP。若只能使用 32768 长度上限，
  两种策略统一调整 server_config，在新目录改测 `--cases hot_half_8k hot_half_16k balanced_order_16k uniform_8k`；
  32K 输入还要加输出，不能在 max_model_len=32768 下执行。报告这是缩小后的实验范围。
- 缓存未达到目标、计数缺失、抢占：该波不合格。保留证据，不关闭验证、不要把目标当成实测。
- 无共同窗口：统一把输出增加为 2048，在新目录重新完成该配置的两次诊断和完整 ABBA；不要混用输出预算。
- 缺失 TP/PCP trace：等待该波结束，检查全部 worker 文件、导入路径和目标 batch；不把空 trace 当成 RR 回退。
- 输出 token 不一致：查看 output_review 首次分歧、RR 重复稳定性、异常/NaN/串请求迹象，并用实际 GLM 准确率用例回归。
  未排查完前不要写“正确性已通过”，也不能仅因 RR 自身波动就认定为正常浮点误差。
- cost 降但无加速：按实报告，然后采集少量代表步骤的 NPU profile，分别定位 indexer、sparse attention、MoE、HCCL、
  graph padding 和 CPU 规划。Profiler 运行独立于正式 perf，不将其时间计入吞吐表。
- 修改任何影响可比性的参数后，重新开始成套对照，保留旧结果目录。

按 `REPORT_TEMPLATE.md` 写报告，交付完整 RUN_ROOT、修改后的 server_config、权重来源和预检结果。
不要只交付合并中位数或一张 cost 分布图。
