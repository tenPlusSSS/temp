# 本机验证记录

日期：2026-11-17。环境：Windows，CPU Python；没有可用的 NPU、vLLM、torch_npu 运行环境。

## 已完成

- 48 个 CPU 单元测试全部通过。包括实际 trace 包装函数在模拟 TP2 × PCP8 上保留原分区返回值、
  写出 16 个 worker 文件、忽略 dummy、记录真实返回分区，以及跨 TP owner/图形状一致性检查。
- 覆盖缺少 TP/PCP、重复 worker、错误 owner、错误 token/context、输入哈希不一致、trace 混入性能数据等拒绝路径。
- 覆盖精确 token-ID 流式计数、共同 decode 窗口、约 90% 缓存预热、指标延迟、抢占和缺失指标检查。
  HTTP/SSE 与运行环境使用替身；这不是实际 GLM 服务通过记录。
- RR/LB 命令对照仅 policy 不同；检查 TP2/PCP8、16/32 请求、无投机参数，以及 trace/perf 分离。
- 14 个 Python 源文件通过语法解析和 Ruff lint/format；9 个 CLI 的 `--help`、4 种策略/模式的启动 dry-run 通过。
- `serve.sh` 和 runbook 的 12 段 Bash 命令通过 `bash -n`，只检查语法，未执行服务/安装命令。
- 核对四个生产文件的 LF 归一化 SHA256，与 `code_requirements.json` 完全一致。
- 使用当前生产规划方法计算 13 用例 × 2 个 factor × 3 个 decode offset，共 78 组 CPU cost 估算。
  结果为 `model_estimates.json`，不包含 NPU 时间。主预算 factor 仍为 1.5。
- ZIP 打包后检查 CRC，并逐个核验 `manifest.json` 中的文件 SHA256。

原始日志见 `validation/cpu-tests.txt`、`validation/cli-checks.txt`、`validation/model-estimates.txt`、
`validation/static-checks.txt`。`validation/runbook-shell-blocks.sh` 仅为语法检查提取物，不要整体执行。

Windows 沙箱 TEMP 权限导致的初次测试异常已通过使用工作区临时目录解决。
Git Bash 在沙箱内启动失败，随后在沙箱外仅运行 `bash -n`，语法检查通过。

## 仍需服务器验证

- 实际权重身份与量化变体；当前配置只是 A3 W8A8C8 模板。
- 固定 vLLM/vllm-ascend 构建环境、真实仓库 UT/完整 hooks 和 GLM 模型正确性回归。
- A3 16 卡 TP2/PCP8 的模型加载、65536 长度和 16/32 并发容量、graph replay、通信及异步执行。
- 真实 worker-extension 导入、全部 16 个 worker 的 trace、实际 cache hit 粒度/计数、完整共同 decode 窗口。
- 输出 token 差异的原因、NPU profiler、ABBA 吞吐；本机没有性能提升或真机正确性结论。

测试要求保留零收益和负收益。代理 cost 降幅不能替代实际加速。
