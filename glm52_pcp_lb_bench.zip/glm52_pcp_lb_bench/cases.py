"""Controlled context distributions; client defaults use PCP8 / 16 requests."""

import random


def make_cases(pcp=16, requests_per_rank=2):
    if pcp < 2 or pcp % 2 or requests_per_rank not in (2, 4):
        raise ValueError("Use even PCP >= 2 and 2 or 4 requests per rank")
    batch, short = pcp * requests_per_rank, 512
    cases = []
    for long in (2048, 8192, 16384, 32768, 49152, 61440):
        cases.append(
            {
                "name": f"hot_half_{long // 1024}k",
                "pcp": pcp,
                "prompt_lengths": [
                    long if i % pcp < pcp // 2 else short for i in range(batch)
                ],
                "purpose": "long requests collide on half of round-robin ranks",
            }
        )
    balanced = [32768] * (batch // 2) + [short] * (batch // 2)
    shuffled = balanced.copy()
    random.Random(20261014).shuffle(shuffled)
    for name, lengths, purpose in (
        (
            "balanced_order_16k",
            [16384] * (batch // 2) + [short] * (batch // 2),
            "balanced order control for reduced-context servers",
        ),
        ("balanced_order_32k", balanced, "same lengths, balanced round-robin order"),
        ("shuffled_32k", shuffled, "seeded request-order control"),
        ("uniform_8k", [8192] * batch, "negative control for planner overhead"),
        (
            "two_hot_32k",
            [32768 if i in (0, pcp) else short for i in range(batch)],
            "relaxed token/request capacity and graph-padding sensitivity",
        ),
        (
            "hot_half_32k_short8k",
            [32768 if i % pcp < pcp // 2 else 8192 for i in range(batch)],
            "both contexts above GLM index_topk; test indexer-dominated hypothesis",
        ),
        (
            "balanced_order_32k_short8k",
            [32768] * (batch // 2) + [8192] * (batch // 2),
            "balanced order control with both contexts above top-k",
        ),
    ):
        cases.append(
            {"name": name, "pcp": pcp, "prompt_lengths": lengths, "purpose": purpose}
        )
    return cases


def get_case(name, pcp=16, requests_per_rank=2):
    return next(c for c in make_cases(pcp, requests_per_rank) if c["name"] == name)
