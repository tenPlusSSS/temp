"""Launch one foreground GLM server, with reviewable argv and source evidence."""

import argparse
import hashlib
import json
import math
import os
import shlex
import sys
from pathlib import Path

from preflight import HERE, inspect_checkpoint, inspect_runtime, validate_config


def build_command(config, policy, factor, mode, requests_per_rank):
    validate_config(config)
    if policy not in ("round_robin", "load_balance") or mode not in ("trace", "perf"):
        raise ValueError("Invalid policy or mode")
    if not math.isfinite(factor) or factor < 1 or requests_per_rank not in (2, 4):
        raise ValueError("Invalid factor or batch size")
    additional = {
        **config["additional_config"],
        "pcp_decode_balance_policy": policy,
        "pcp_decode_balance_token_factor": factor,
    }
    values = {
        "host": config["host"],
        "port": config["port"],
        "served-model-name": config["served_model_name"],
        "tensor-parallel-size": config["tp"],
        "prefill-context-parallel-size": config["pcp"],
        "decode-context-parallel-size": 1,
        "pipeline-parallel-size": 1,
        "data-parallel-size": 1,
        "max-num-seqs": config["pcp"] * requests_per_rank,
        "max-model-len": config["max_model_len"],
        "max-num-batched-tokens": config["max_num_batched_tokens"],
        "block-size": config["block_size"],
        "gpu-memory-utilization": config["gpu_memory_utilization"],
        "api-server-count": 1,
        "seed": 20261014,
        "distributed-executor-backend": "mp",
        "kv-cache-dtype": config["kv_cache_dtype"],
        "attention-config": json.dumps(config["attention_config"]),
        "compilation-config": json.dumps(config["compilation_config"]),
        "additional-config": json.dumps(additional),
    }
    if config.get("quantization"):
        values["quantization"] = config["quantization"]
    if mode == "trace":
        values["worker-extension-cls"] = "pcp_trace.TraceExtension"
    argv = [
        sys.executable,
        "-m",
        "vllm.entrypoints.cli.main",
        "serve",
        config["model_path"],
    ]
    for key, value in values.items():
        argv.extend(["--" + key, str(value)])
    argv.extend(
        [
            "--trust-remote-code",
            "--enable-expert-parallel",
            "--enable-prefix-caching",
            "--enable-chunked-prefill",
            "--async-scheduling",
        ]
    )
    return argv


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("policy", choices=["round_robin", "load_balance"])
    parser.add_argument("mode", choices=["trace", "perf"])
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--config", type=Path, default=HERE / "server_config.json")
    parser.add_argument("--model-path")
    parser.add_argument("--factor", type=float, default=1.5)
    parser.add_argument("--requests-per-rank", type=int, choices=[2, 4], default=2)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    if args.model_path:
        config["model_path"] = args.model_path
    argv = build_command(
        config, args.policy, args.factor, args.mode, args.requests_per_rank
    )
    print(shlex.join(argv), flush=True)
    if args.dry_run:
        print("DRY RUN: no model/source validation or NPU process started.")
        return
    checkpoint, runtime = inspect_checkpoint(config), inspect_runtime()
    env = os.environ.copy()
    env["VLLM_USE_V2_MODEL_RUNNER"] = "1"
    env["VLLM_WORKER_MULTIPROC_METHOD"] = "spawn"
    env["ASCEND_RT_VISIBLE_DEVICES"] = config["visible_devices"]
    # HCCL settings remain those of the server's working environment.
    if args.mode == "trace":
        env["PYTHONPATH"] = str(HERE) + os.pathsep + env.get("PYTHONPATH", "")
    env_keys = (
        "VLLM_USE_V2_MODEL_RUNNER",
        "VLLM_WORKER_MULTIPROC_METHOD",
        "ASCEND_RT_VISIBLE_DEVICES",
        "HCCL_BUFFSIZE",
        "HCCL_SOCKET_IFNAME",
        "HCCL_IF_IP",
        "GLOO_SOCKET_IFNAME",
        "PYTORCH_NPU_ALLOC_CONF",
        "OMP_NUM_THREADS",
    )
    recorded_env = {key: env.get(key) for key in env_keys}
    common = {
        "config": config,
        "factor": args.factor,
        "batch_size": config["pcp"] * args.requests_per_rank,
        "environment": recorded_env,
        "checkpoint": checkpoint,
        "commits": {name: runtime[name]["commit"] for name in ("vllm", "vllm_ascend")},
        "tracked_diff_sha256": {
            name: runtime[name]["tracked_diff_sha256"]
            for name in ("vllm", "vllm_ascend")
        },
        "production_sha256_lf": runtime["production_sha256_lf"],
    }
    manifest = {
        **common,
        "policy": args.policy,
        "mode": args.mode,
        "argv": argv,
        "runtime": runtime,
        "comparison_fingerprint": hashlib.sha256(
            json.dumps(common, sort_keys=True).encode()
        ).hexdigest(),
    }
    run_dir = args.run_dir.resolve()
    run_dir.mkdir(parents=True, exist_ok=True)
    with (run_dir / "launch.json").open("x", encoding="utf-8") as stream:
        json.dump(manifest, stream, indent=2)
    os.chdir(run_dir)
    print(f"Manifest: {run_dir / 'launch.json'}", flush=True)
    os.execvpe(argv[0], argv, env)


if __name__ == "__main__":
    main()
