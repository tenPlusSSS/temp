"""Read-only checks of installed source, checkpoint and benchmark topology."""

import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def sha_text(path):
    return hashlib.sha256(Path(path).read_text(encoding="utf-8").encode()).hexdigest()


def git(root, *args):
    result = subprocess.run(
        ["git", "-C", str(root), *args], capture_output=True, text=True, check=False
    )
    if result.returncode:
        raise ValueError(f"Cannot read Git checkout at {root}: {result.stderr.strip()}")
    return result.stdout.strip()


def validate_config(config):
    expected = {
        "model_path",
        "served_model_name",
        "host",
        "port",
        "tp",
        "pcp",
        "dp",
        "pp",
        "dcp",
        "visible_devices",
        "max_model_len",
        "max_num_batched_tokens",
        "block_size",
        "gpu_memory_utilization",
        "quantization",
        "kv_cache_dtype",
        "attention_config",
        "compilation_config",
        "additional_config",
    }
    if set(config) != expected:
        raise ValueError(
            f"Unknown or missing server config fields: {set(config) ^ expected}"
        )
    for field in ("port", "max_model_len", "max_num_batched_tokens", "block_size"):
        if type(config[field]) is not int or config[field] < 1:
            raise ValueError(f"{field} must be a positive integer")
    if (config["tp"], config["pcp"], config["dp"], config["pp"], config["dcp"]) != (
        2,
        8,
        1,
        1,
        1,
    ):
        raise ValueError("This execution package targets TP2/PCP8/DP1/PP1/DCP1")
    devices = config["visible_devices"].split(",")
    if (
        len(devices) != 16
        or len(set(devices)) != 16
        or not all(x.isdigit() for x in devices)
    ):
        raise ValueError("Set 16 distinct logical A3 device IDs")
    if not config.get("model_path"):
        raise ValueError("Set model_path in server_config.json or pass --model-path")
    if not 0 < config["gpu_memory_utilization"] < 1:
        raise ValueError("Invalid gpu_memory_utilization")
    if config["kv_cache_dtype"] == "turboquant_4bit_nc":
        raise ValueError("This baseline does not support TurboQuant with PCP")
    if config["compilation_config"].get("cudagraph_mode") != "FULL_DECODE_ONLY":
        raise ValueError("Use FULL_DECODE_ONLY for the primary A/B")
    forbidden = {
        "enable_pcp_decode_sharding",
        "enable_dsa_cp",
        "pcp_decode_balance_policy",
        "pcp_decode_balance_token_factor",
    }
    if forbidden & config["additional_config"].keys():
        raise ValueError(
            "Remove old sharding flags; policy/factor are set by the launcher"
        )


def inspect_checkpoint(config):
    path = Path(config["model_path"]) / "config.json"
    raw = json.loads(path.read_text(encoding="utf-8"))
    text = raw.get("text_config", raw)
    if "index_kpool" in raw or "index_kpool" in text:
        raise ValueError("KPool model is excluded by the main decode-sharding policy")
    if "GlmMoeDsaForCausalLM" not in raw.get("architectures", []):
        raise ValueError(
            "Expected the standard GLM-5.2 GlmMoeDsaForCausalLM architecture"
        )
    return {
        "config_path": str(path.resolve()),
        "config_sha256": sha_text(path),
        "architectures": raw["architectures"],
        "model_type": text.get("model_type"),
        "index_topk": text.get("index_topk"),
        "index_topk_freq": text.get("index_topk_freq"),
        "quantization_config": raw.get("quantization_config"),
        "note": "Architecture alone does not distinguish GLM-5.2 from GLM-5.3; record checkpoint provenance.",
    }


def inspect_runtime(requirements=None):
    requirements = requirements or json.loads(
        (HERE / "code_requirements.json").read_text()
    )
    roots, evidence = {}, {"python": sys.executable, "python_version": sys.version}
    for name in ("vllm", "vllm_ascend"):
        spec = importlib.util.find_spec(name)
        if spec is None or spec.origin is None:
            raise ValueError(f"{name} is not installed in this Python environment")
        module = Path(spec.origin).resolve()
        root = Path(git(module.parent, "rev-parse", "--show-toplevel"))
        head = git(root, "rev-parse", "HEAD")
        if head != requirements[name + "_commit"]:
            raise ValueError(f"{name} HEAD {head} differs from the pinned baseline")
        roots[name] = root
        evidence[name] = {
            "module": str(module),
            "root": str(root),
            "commit": head,
            "status": git(root, "status", "--short"),
            "tracked_diff_sha256": hashlib.sha256(
                git(root, "diff", "--binary", "HEAD").encode()
            ).hexdigest(),
        }
    actual = {p: sha_text(roots["vllm_ascend"] / p) for p in requirements["sha256_lf"]}
    if actual != requirements["sha256_lf"]:
        raise ValueError(
            "Installed production files do not match the migrated LB patch"
        )
    evidence["production_sha256_lf"] = actual
    return evidence


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=HERE / "server_config.json")
    parser.add_argument("--model-path")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    if args.model_path:
        config["model_path"] = args.model_path
    validate_config(config)
    result = {
        "config": config,
        "checkpoint": inspect_checkpoint(config),
        "runtime": inspect_runtime(),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2)
    print(args.output)


if __name__ == "__main__":
    main()
