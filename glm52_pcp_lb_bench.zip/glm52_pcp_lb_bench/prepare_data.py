"""Generate exact token-ID inputs once, using the active GLM tokenizer."""

import argparse
import hashlib
import json
from pathlib import Path

from cases import get_case, make_cases
from prefix_cache import make_cache_plan
from run_serving import make_prompts


def load_dataset(folder, case, model, seed):
    data = json.loads((Path(folder) / (case["name"] + ".json")).read_text())
    prompts = data["prompts"]
    if (
        data["model"] != model
        or data["seed"] != seed
        or data["pcp"] != case["pcp"]
        or list(map(len, prompts)) != case["prompt_lengths"]
        or hashlib.sha256(json.dumps(prompts).encode()).hexdigest()
        != data["prompt_sha256"]
    ):
        raise ValueError("Dataset model/topology/seed/length/hash mismatch")
    return prompts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", default="http://127.0.0.1:50001")
    parser.add_argument("--model", default="glm52")
    parser.add_argument("--pcp", type=int, default=8)
    parser.add_argument("--requests-per-rank", type=int, choices=[2, 4], default=2)
    parser.add_argument("--seed", type=int, default=20261014)
    parser.add_argument("--prefix-cache-block-size", type=int, default=32)
    parser.add_argument("--case", default="all")
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    selected = (
        make_cases(args.pcp, args.requests_per_rank)
        if args.case == "all"
        else [get_case(args.case, args.pcp, args.requests_per_rank)]
    )
    args.out.mkdir(parents=True, exist_ok=True)
    for case in selected:
        path = args.out / (case["name"] + ".json")
        if path.exists():
            raise ValueError(f"Preserve existing dataset: {path}")
        prompts = make_prompts(
            args.base_url, args.model, case["prompt_lengths"], args.seed
        )
        data = {
            **case,
            "model": args.model,
            "seed": args.seed,
            "prompts": prompts,
            "prompt_sha256": hashlib.sha256(json.dumps(prompts).encode()).hexdigest(),
            "cache_plan": make_cache_plan(prompts, 0.9, args.prefix_cache_block_size),
        }
        with path.open("x", encoding="utf-8") as stream:
            json.dump(data, stream)
        print(f"{case['name']}: {len(prompts)} requests, {data['prompt_sha256']}")


if __name__ == "__main__":
    main()
