"""Report token divergence within RR and across RR/LB; never infer its cause."""

import argparse
import itertools
import json
from pathlib import Path

from compare import comparable_key


def diff_outputs(left, right):
    a, b = left["output_token_ids"], right["output_token_ids"]
    if len(a) != len(b):
        raise ValueError("Output request count differs")
    changes = []
    for req, (xs, ys) in enumerate(zip(a, b, strict=True)):
        first = next((i for i, (x, y) in enumerate(zip(xs, ys)) if x != y), None)
        if first is None and len(xs) != len(ys):
            first = min(len(xs), len(ys))
        if first is not None:
            changes.append(
                {
                    "request_index": req,
                    "first_different_token_index": first,
                    "left_length": len(xs),
                    "right_length": len(ys),
                    "left_tokens": xs[max(0, first - 4) : first + 5],
                    "right_tokens": ys[max(0, first - 4) : first + 5],
                }
            )
    return {
        "left": left["request_id"],
        "right": right["request_id"],
        "changed_requests": changes,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", type=Path, nargs="+")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    groups = {}
    for folder in args.folders:
        for path in folder.rglob("*.json"):
            row = json.loads(path.read_text())
            if row.get("phase") == "measure" and row.get("valid_window"):
                groups.setdefault(comparable_key(row), []).append(row)
    result = []
    for rows in groups.values():
        rr = [r for r in rows if r["policy_label"] == "round_robin"]
        lb = [r for r in rows if r["policy_label"] == "load_balance"]
        if not rr or not lb:
            raise ValueError("Need matching RR and LB inputs for output review")
        within = [diff_outputs(a, b) for a, b in itertools.combinations(rr, 2)]
        cross = [diff_outputs(a, b) for a in rr for b in lb]
        result.append(
            {
                "case": rows[0]["case"],
                "rr_vs_rr": within,
                "rr_vs_lb": cross,
                "status": "NEEDS_REVIEW"
                if any(x["changed_requests"] for x in cross)
                else "TOKEN_IDENTICAL",
                "note": "RR repeat drift alone does not prove that an RR/LB difference is benign.",
            }
        )
    if not result:
        raise ValueError("No measured outputs found")
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2)
    print(args.output)


if __name__ == "__main__":
    main()
