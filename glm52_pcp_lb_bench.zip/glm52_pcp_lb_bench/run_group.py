"""Run client waves against one already-started server; never manage other processes."""

import argparse
import json
import subprocess
import sys
import urllib.request
from pathlib import Path

from cases import get_case

HERE = Path(__file__).resolve().parent
PRIMARY = [
    "hot_half_8k",
    "hot_half_16k",
    "balanced_order_16k",
    "hot_half_32k",
    "balanced_order_32k",
    "uniform_8k",
    "hot_half_32k_short8k",
    "balanced_order_32k_short8k",
    "two_hot_32k",
]


def run_client(args, manifest):
    config = manifest["config"]
    with urllib.request.urlopen(
        args.base_url.rstrip("/") + "/v1/models", timeout=15
    ) as response:
        models = json.load(response)
    if config["served_model_name"] not in [row["id"] for row in models["data"]]:
        raise ValueError("The endpoint does not serve the configured model")
    if args.stage == "diagnostic" and manifest["mode"] != "trace":
        raise ValueError("Diagnostic stage requires a trace server")
    if args.stage == "perf" and manifest["mode"] != "perf":
        raise ValueError("Performance stage must restart without the trace extension")
    rpr = manifest["batch_size"] // config["pcp"]
    cases = args.cases or (["hot_half_2k"] if args.stage == "smoke" else PRIMARY)
    # Check the whole requested set before consuming expensive server time.
    for name in cases:
        case = get_case(name, config["pcp"], rpr)
        if max(case["prompt_lengths"]) + args.output_tokens > config["max_model_len"]:
            raise ValueError(f"{name}: prompt + output exceeds the configured maximum")
        if (args.run_dir / "results" / name).exists():
            raise ValueError(
                "Choose a fresh group directory; preserve previous results"
            )
    for name in cases:
        folder = args.run_dir / "results" / name
        argv = [
            sys.executable,
            str(HERE / "run_serving.py"),
            "--base-url",
            args.base_url,
            "--model",
            config["served_model_name"],
            "--policy",
            manifest["policy"],
            "--factor",
            str(manifest["factor"]),
            "--pcp",
            str(config["pcp"]),
            "--requests-per-rank",
            str(rpr),
            "--max-model-len",
            str(config["max_model_len"]),
            "--prefix-cache-hit-ratio",
            "0.9",
            "--prefix-cache-block-size",
            str(config["block_size"]),
            "--dataset-dir",
            str(args.dataset_dir.resolve()),
            "--server-manifest",
            str(args.run_dir / "launch.json"),
            "--case",
            name,
            "--output-tokens",
            str(args.output_tokens),
            "--warmup-tokens",
            "64",
            "--window-tokens",
            "256",
            "--warmup-rounds",
            "1" if args.stage == "perf" else "0",
            "--repeats",
            str(args.repeats if args.stage == "perf" else 1),
            "--out",
            str(folder),
        ]
        with (args.run_dir / f"client-{name}.log").open("x", encoding="utf-8") as log:
            result = subprocess.run(
                argv, stdout=log, stderr=subprocess.STDOUT, check=False
            )
        if result.returncode:
            raise RuntimeError(
                f"{name} failed; inspect client-{name}.log and preserve raw results"
            )
        if args.stage == "diagnostic":
            for path in folder.glob("*.json"):
                request_id = json.loads(path.read_text())["request_id"]
                common = [
                    sys.executable,
                    str(HERE / "inspect_trace.py"),
                    str(args.run_dir / "pcp_trace"),
                    "--policy",
                    manifest["policy"],
                    "--request-contains",
                    request_id,
                    "--expected-tp-size",
                    str(config["tp"]),
                    "--expected-batch-size",
                    str(manifest["batch_size"]),
                    "--verify",
                ]
                for suffix, extra in (
                    ("placement.txt", ["--details"]),
                    ("summary.jsonl", []),
                ):
                    with (args.run_dir / f"{name}-{suffix}").open(
                        "x", encoding="utf-8"
                    ) as log:
                        subprocess.run(
                            common + extra,
                            stdout=log,
                            stderr=subprocess.STDOUT,
                            check=True,
                        )
        print(f"Completed {args.stage}: {name}", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--dataset-dir", type=Path, required=True)
    parser.add_argument(
        "--stage", choices=["smoke", "diagnostic", "perf"], required=True
    )
    parser.add_argument("--base-url", default="http://127.0.0.1:50001")
    parser.add_argument("--cases", nargs="+")
    parser.add_argument("--output-tokens", type=int, default=1024)
    parser.add_argument("--repeats", type=int, default=3)
    args = parser.parse_args()
    args.run_dir = args.run_dir.resolve()
    manifest = json.loads((args.run_dir / "launch.json").read_text())
    run_client(args, manifest)


if __name__ == "__main__":
    main()
