"""GLM topology, TP trace evidence, launch and reproducibility regressions."""

import copy
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from cases import get_case, make_cases
from compare import compare
from inspect_trace import group_snapshots, verify_snapshot, verify_tp_coverage
from launch_server import build_command
from preflight import inspect_checkpoint, validate_config
from prepare_data import load_dataset
from review_outputs import diff_outputs
from test_bench import result


def config():
    cfg = json.loads(Path(__file__).with_name("server_config.json").read_text())
    cfg["model_path"] = "/a path/GLM-5.2-w8a8c8"
    return cfg


def records():
    result = []
    ids = [f"pcpbench-r{i}" for i in range(16)]
    owners = [i % 8 for i in range(16)]
    for tp in range(2):
        for rank in range(8):
            result.append(
                {
                    "policy": "round_robin",
                    "factor": 1.5,
                    "pcp": 8,
                    "tp_rank": tp,
                    "tp_size": 2,
                    "world_rank": rank * 2 + tp,
                    "pcp_rank": rank,
                    "request_ids": ids,
                    "contexts": [100] * 16,
                    "scheduled_tokens": [1] * 16,
                    "owners": owners,
                    "padded_num_tokens": 2,
                    "padded_num_reqs": 2,
                    "mode": "FULL",
                    "local_partition": {
                        "num_tokens": 2,
                        "requests": [
                            {"request_id": ids[i], "c": 100, "q": 1}
                            for i in range(16)
                            if owners[i] == rank
                        ],
                    },
                }
            )
    return result


class GlmTests(unittest.TestCase):
    def test_workloads_have_expected_rr_collisions_for_both_batches(self):
        for rpr in (2, 4):
            for case in make_cases(8, rpr):
                self.assertEqual(len(case["prompt_lengths"]), 8 * rpr)
            hot = get_case("hot_half_32k", 8, rpr)["prompt_lengths"]
            balanced = get_case("balanced_order_32k", 8, rpr)["prompt_lengths"]
            self.assertEqual(sorted(hot), sorted(balanced))
            self.assertEqual(max(sum(hot[r::8]) for r in range(8)), 32768 * rpr)
            self.assertEqual(len({sum(balanced[r::8]) for r in range(8)}), 1)

    def test_sparse_control_keeps_both_lengths_above_topk(self):
        hot = get_case("hot_half_32k_short8k", 8)["prompt_lengths"]
        balanced = get_case("balanced_order_32k_short8k", 8)["prompt_lengths"]
        self.assertEqual(sorted(hot), sorted(balanced))
        self.assertGreater(min(hot), 2048)

    def test_launch_only_policy_differs_between_ab(self):
        cfg = config()
        before = copy.deepcopy(cfg)
        rr = build_command(cfg, "round_robin", 1.5, "perf", 2)
        lb = build_command(cfg, "load_balance", 1.5, "perf", 2)
        differences = [(a, b) for a, b in zip(rr, lb, strict=True) if a != b]
        self.assertEqual(len(differences), 1)
        a, b = map(json.loads, differences[0])
        self.assertEqual(a.pop("pcp_decode_balance_policy"), "round_robin")
        self.assertEqual(b.pop("pcp_decode_balance_policy"), "load_balance")
        self.assertEqual(a, b)
        self.assertEqual(cfg, before)
        self.assertEqual(rr[rr.index("--max-num-seqs") + 1], "16")
        self.assertIn(cfg["model_path"], rr)
        for flag in (
            "--speculative-config",
            "--tokenizer-mode",
            "--reasoning-parser",
            "--worker-extension-cls",
        ):
            self.assertNotIn(flag, rr)

    def test_trace_and_batch32_are_explicit(self):
        argv = build_command(config(), "load_balance", 1.5, "trace", 4)
        self.assertEqual(argv[argv.index("--max-num-seqs") + 1], "32")
        self.assertEqual(
            argv[argv.index("--worker-extension-cls") + 1], "pcp_trace.TraceExtension"
        )

    def test_invalid_topologies_and_unknown_flags_fail(self):
        for key, value in (
            ("tp", 1),
            ("pcp", 16),
            ("dp", 2),
            ("dcp", 2),
            ("pp", 2),
            ("visible_devices", "0,0"),
            ("model_path", None),
            ("block_size", 0),
            ("speculative_config", {"method": "mtp"}),
            ("kv_cache_dtype", "turboquant_4bit_nc"),
        ):
            cfg = config()
            cfg[key] = value
            with self.assertRaises(ValueError):
                validate_config(cfg)
        for key in (
            "enable_dsa_cp",
            "enable_pcp_decode_sharding",
            "pcp_decode_balance_policy",
        ):
            cfg = config()
            cfg["additional_config"][key] = True
            with self.assertRaises(ValueError):
                validate_config(cfg)

    def test_invalid_factor_fails(self):
        for value in (0.9, float("inf"), float("nan")):
            with self.assertRaises(ValueError):
                build_command(config(), "load_balance", value, "perf", 2)

    def test_complete_two_tp_slices_are_not_duplicate_pcp_records(self):
        rows = records()
        groups = group_snapshots(rows)
        self.assertEqual(len(groups), 2)
        self.assertTrue(all(verify_snapshot(g)["verified"] for g in groups))
        self.assertTrue(verify_tp_coverage(rows, 2)["verified"])

    def test_missing_tp_or_pcp_and_duplicate_records_fail(self):
        rows = records()
        for incomplete in (rows[:8], rows[:-1], rows + [rows[0]]):
            self.assertFalse(verify_tp_coverage(incomplete, 2)["verified"])

    def test_cross_tp_ownership_and_graph_mismatch_fail(self):
        for field, value in (
            ("owners", [0] * 16),
            ("padded_num_tokens", 3),
            ("tp_size", 1),
            ("world_rank", 0),
        ):
            rows = copy.deepcopy(records())
            rows[-1][field] = value
            self.assertFalse(verify_tp_coverage(rows, 2)["verified"])

    def test_trace_or_different_server_settings_cannot_enter_ab(self):
        rows = [result(), result("load_balance")]
        rows[0]["server_mode"] = "trace"
        with self.assertRaisesRegex(ValueError, "Trace"):
            compare(rows)
        rows[0]["server_mode"] = "perf"
        rows[0]["server_fingerprint"] = "different"
        with self.assertRaises(ValueError):
            compare(rows)

    def test_checkpoint_exclusion_uses_actual_config_fields(self):
        with tempfile.TemporaryDirectory() as folder:
            cfg = config()
            cfg["model_path"] = folder
            path = Path(folder) / "config.json"
            raw = {"architectures": ["GlmMoeDsaForCausalLM"], "index_topk": 2048}
            path.write_text(json.dumps(raw))
            self.assertEqual(inspect_checkpoint(cfg)["index_topk"], 2048)
            raw["index_kpool"] = None
            path.write_text(json.dumps(raw))
            with self.assertRaisesRegex(ValueError, "KPool"):
                inspect_checkpoint(cfg)

    def test_dataset_hash_model_and_lengths_are_checked(self):
        case = {"name": "test", "pcp": 8, "prompt_lengths": [2, 2]}
        prompts = [[1, 2], [3, 4]]
        data = {
            "prompts": prompts,
            "model": "glm52",
            "seed": 7,
            "pcp": 8,
            "prompt_sha256": hashlib.sha256(json.dumps(prompts).encode()).hexdigest(),
        }
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "test.json"
            path.write_text(json.dumps(data))
            self.assertEqual(load_dataset(folder, case, "glm52", 7), prompts)
            with self.assertRaises(ValueError):
                load_dataset(folder, case, "different", 7)
            data["prompts"][0][0] = 9
            path.write_text(json.dumps(data))
            with self.assertRaises(ValueError):
                load_dataset(folder, case, "glm52", 7)

    def test_output_diff_retains_first_divergence_without_diagnosing_cause(self):
        a = {"request_id": "rr", "output_token_ids": [[1, 2, 3], [4, 5]]}
        b = {"request_id": "lb", "output_token_ids": [[1, 9, 3], [4]]}
        diffs = diff_outputs(a, b)["changed_requests"]
        self.assertEqual([d["first_different_token_index"] for d in diffs], [1, 1])


if __name__ == "__main__":
    unittest.main()
