# Syntax-check only; commands are not executed by validation.
set -euo pipefail
cd /absolute/path/to/glm52_pcp_lb_bench
export BENCH_DIR="$(pwd -P)"
export MODEL_PATH=/actual/path/to/GLM-5.2-w8a8c8
export RUN_ROOT="$(mktemp -d "$BENCH_DIR/run-glm52-$(date +%Y%m%d-%H%M%S)-XXXXXX")"
python -m unittest -v test_bench.py test_glm52.py 2>&1 | tee "$RUN_ROOT/cpu-tests.log"
npu-smi info > "$RUN_ROOT/npu-info.txt"

# 当前目录必须是独立的、已 checkout 到指定基线的 vllm-ascend 仓库。
git apply --check "$BENCH_DIR/production/pcp_load_balance_main.patch"
git apply "$BENCH_DIR/production/pcp_load_balance_main.patch"
python -m pip install -e . --no-build-isolation

cd "$BENCH_DIR"
python preflight.py --model-path "$MODEL_PATH" --output "$RUN_ROOT/preflight.json"
bash serve.sh round_robin perf --model-path "$MODEL_PATH" \
  --run-dir "$RUN_ROOT/dry-run" --dry-run > "$RUN_ROOT/command-preview.txt"

pytest -q tests/ut/worker/test_pcp_decode_balance.py \
  tests/ut/worker/test_pcp_manager_v2.py \
  tests/ut/worker/test_model_runner_v2.py tests/ut/test_ascend_config.py
bash format.sh ci

mkdir -p "$RUN_ROOT/rr_trace"
set -o pipefail
bash "$BENCH_DIR/serve.sh" round_robin trace --model-path "$MODEL_PATH" \
  --run-dir "$RUN_ROOT/rr_trace" 2>&1 | tee "$RUN_ROOT/rr_trace/server.log"

curl -fsS http://127.0.0.1:50001/v1/models
cd "$BENCH_DIR"
python prepare_data.py --model glm52 --pcp 8 --requests-per-rank 2 \
  --out "$RUN_ROOT/data16" > "$RUN_ROOT/data16.log"
python run_group.py --stage smoke --run-dir "$RUN_ROOT/rr_trace" \
  --dataset-dir "$RUN_ROOT/data16"

python run_group.py --stage diagnostic --run-dir "$RUN_ROOT/rr_trace" \
  --dataset-dir "$RUN_ROOT/data16"

mkdir -p "$RUN_ROOT/lb_trace"
set -o pipefail
bash "$BENCH_DIR/serve.sh" load_balance trace --model-path "$MODEL_PATH" \
  --run-dir "$RUN_ROOT/lb_trace" 2>&1 | tee "$RUN_ROOT/lb_trace/server.log"

python "$BENCH_DIR/run_group.py" --stage diagnostic --run-dir "$RUN_ROOT/lb_trace" \
  --dataset-dir "$RUN_ROOT/data16"

TAG=rr_a
POLICY=round_robin
mkdir -p "$RUN_ROOT/$TAG"
set -o pipefail
bash "$BENCH_DIR/serve.sh" "$POLICY" perf --model-path "$MODEL_PATH" \
  --run-dir "$RUN_ROOT/$TAG" 2>&1 | tee "$RUN_ROOT/$TAG/server.log"

TAG=rr_a
python "$BENCH_DIR/run_group.py" --stage perf --run-dir "$RUN_ROOT/$TAG" \
  --dataset-dir "$RUN_ROOT/data16" --repeats 3

python "$BENCH_DIR/compare.py" \
  "$RUN_ROOT/rr_a/results" "$RUN_ROOT/lb_a/results" \
  "$RUN_ROOT/lb_b/results" "$RUN_ROOT/rr_b/results" \
  --output "$RUN_ROOT/comparison.json"
python "$BENCH_DIR/review_outputs.py" \
  "$RUN_ROOT/rr_a/results" "$RUN_ROOT/lb_a/results" \
  "$RUN_ROOT/lb_b/results" "$RUN_ROOT/rr_b/results" \
  --output "$RUN_ROOT/output_review.json"
