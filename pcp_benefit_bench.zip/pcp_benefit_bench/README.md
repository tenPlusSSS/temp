# PCP=16 / DeepSeek V4：load_balance 收益测试

本套用例针对你提供的部署：`DeepSeek-V4-Flash-0731-w8a8`，TP=1、PCP=16、DP=1、PP=1、DCP=1、max_num_seqs=32、8192 token 调度预算、FULL_DECODE_ONLY、npugraph_ex、异步调度、prefix cache 开启。默认 factor=1.5。测试工具单独放在本目录，没有修改推理生产代码。

**目标是构造能触发轮询失衡的负载，并客观测量收益。不能保证 NPU 一定加速，也不能把 attention 估算下降当成实测速度提升。**

## 1. 先跑哪一个

主用例 `hot_half_32k`：32 个请求，16 个长度 32768、16 个长度 512，输出各 1024 token。

```text
请求顺序：
[长×8, 短×8, 长×8, 短×8]

round_robin：
rank  0..7：长 + 长
rank 8..15：短 + 短

load_balance 理想结果：
rank 0..15：长 + 短
```

纯 decode 时 q=1，原轮询每 rank 两个请求，平均 token 数=2，候选 token 预算=ceil(1.5×32/16)=3。此主用例均衡后仍只需要每 rank 两个 token，**避免把更多 token / 更大图 padding 混入主收益测试**。

在 c 等于输入长度的固定快照上，实际当前分配函数的结果为：

| 用例 | 上下文和顺序 | RR 最大 A → LB 最大 A | 模型下降 | 最大实际 token |
| --- | --- | --- | --- | --- |
| hot_half_16k | `[16384×8,512×8]` 重复两次 | 32770 → 16898 | 48.43% | 2 → 2 |
| hot_half_32k | `[32768×8,512×8]` 重复两次 | 65538 → 33282 | 49.22% | 2 → 2 |
| balanced_order_32k | `[32768×16,512×16]` | 33282 → 33282 | 0% | 2 → 2 |
| shuffled_32k | 同样 16 长/16 短，固定种子打乱 | 65538 → 33282 | 49.22% | 2 → 2 |
| uniform_8k | 32 个请求都为 8192 | 16386 → 16386 | 0% | 2 → 2 |
| two_hot_32k | 下标 0、16 为 32768，其余 512 | 65538 → 32769 | 50% | 2 → 3 |

`balanced_order_32k` 是同长度分布、不同顺序的负对照；`uniform_8k` 检查规划开销；`two_hot_32k` 单独检查 request/token 放宽的收益是否被图桶增长抵消。打乱用例只是一组可复现的随机顺序，不代表生产流量总体。

上述结果由 `analyze.py` 提取当前 PCPManager 的真实 CPU 分配方法执行得到，不是另写一套近似算法。附带的 `model_estimates.json` 包含源码 SHA256、factor=1/1.5、decode 上下文增长 0/128/512 后共 36 个组合。请求初始顺序和相同上下文增量是这些静态估算的前提。

## 2. 快速运行 A/B

把整个目录复制到服务器，进入该目录。客户端只依赖 Python 3.10+ 标准库；CPU 模型分析另需 NumPy。先确保服务器已经安装当前完整修改。

第一次在服务终端运行：

```bash
bash serve.sh round_robin 1.5 perf
```

服务就绪后，在另一个终端运行：

```bash
python run_serving.py --policy round_robin --case hot_half_32k \
  --warmup-rounds 1 --repeats 3 --out results/rr_a
```

该命令完成后，正常停止这个测试服务，再启动另一策略：

```bash
bash serve.sh load_balance 1.5 perf
```

在客户端终端执行相同输入：

```bash
python run_serving.py --policy load_balance --case hot_half_32k \
  --warmup-rounds 1 --repeats 3 --out results/lb_a

python compare.py results/rr_a results/lb_a --output comparison.json
```

`serve.sh` 保留你提供的模型路径、端口、图、异步调度、量化和其他 additional-config；仅将策略/factor 参数化。脚本不会自动停止已有服务，也不会改端口绕过冲突。客户端 `--policy` / `--factor` 只是结果标签，**不会修改运行中服务器配置**，必须与实际启动命令一致。

不要在同一批 NPU 上同时启动两套服务。测试期间不要有其他请求。远程客户端需增加 `--base-url http://服务器地址:50001`；尽量在服务器本机或稳定低延迟连接运行。

首轮两组结果只用于初筛。正式报告再以 **A→B→B→A** 的服务启动顺序复测，分别用 `rr_a / lb_a / lb_b / rr_b` 保存；每次相同预热和重复次数，避免把温度、缓存或后台负载漂移当作策略收益。四组均完成后：

```bash
python compare.py results/rr_a results/lb_a results/lb_b results/rr_b \
  --output comparison_abba.json
```

## 3. 客户端到底测了什么

1. 调用该服务的 `/tokenize` 获取合法普通 token ID，构造精确长度的 token-ID prompts；两种策略使用相同 seed，结果中保存输入哈希。
2. 一次 `/v1/completions` 请求提交有序的 32 个 token-ID prompts，`n=1`。这样减少 32 个独立 HTTP 请求的到达乱序。实际 scheduler 顺序仍应通过下一节诊断确认，不能仅凭提交顺序断言 owner。
3. 使用 `temperature=0`、`ignore_eos=true`、每请求固定 1024 输出 token。不给 stop 条件；返回真实 delta token IDs。
4. 每轮独立 `cache_salt`，且每个请求首个 block 不同，保留 prefix cache 开关但避免前一轮预热/APC 命中造成输入工作量差异。相同 seed 的输入 token IDs 在 A/B 中保持一致。
5. 完整跑完预热轮，排除该轮结果。测量轮中，等**所有 32 个请求**都已经返回至少 65 个 token，再取共同起点。
6. 从共同起点开始，直到每个请求至少再返回 256 个 token，取共同终点；要求全部请求仍距结束有至少 32 token 余量。不足则保存原始事件并报错，不用 batch 缩小后的尾段冒充收益。
7. 用共同时间窗口中实际收到的 token 数计算吞吐。这里不把一个 SSE chunk 当一个 token；一个 chunk 含多个 token 时按实际 ID 数计数。
8. 读取 `/metrics` 前后抢占计数。发生抢占直接中止对比；指标缺失时比较工具默认拒绝，只有明确加 `--allow-missing-metrics` 才放行，且结果会标注没有验证。

输出字段：

| 字段 | 含义 |
| --- | --- |
| steady_output_tps | 全部请求共同 decode 窗口中的输出 tokens/s，主要指标 |
| batch_equivalent_tpot_ms | `32×窗口秒数×1000/窗口 token 数`，固定 batch 的等效 TPOT |
| chunk_amortized_gap_p50/p95_ms | 相邻流式 chunk 间隔除以 delta token 数；有合并 chunk 时不等同于真实单 token ITL 分位数 |
| single_token_chunk_fraction | 一 token 一个 chunk 的比例，检查流式合并程度 |
| mean_ttft_s | 输入提交到首 token 的均值，含 prefill，作为辅助指标 |
| e2e_output_tps | 包含 prefill 和尾段的整批输出吞吐，单独报告 |
| tokens_at_window_start/end | 每请求窗口边界输出计数，用于检查上下文进展 |
| preemptions | 测试波次内抢占增量，合格结果应为 0 |
| output_sha256 | 每请求完整输出 token 哈希，检查 A/B 输出差异 |

这是**客户端观察到的稳态吞吐/等效 TPOT**，含采样、调度、序列化与传输影响；不是 NPU attention kernel 的单独耗时。比较工具输出正负收益、中位数和 min/max，不筛掉负收益。输出哈希不同需要单独看数值精度/正确性，不能只看吞吐就宣布成功。

如果 1024 输出没有足够共同窗口，两边同时改为 `--output-tokens 2048`，重做相同用例；不能一边 1024、一边 2048。总长度需低于 65536。不要只调低窗口把抢占或失去共同 batch 的问题隐藏掉。

## 4. 先确认实际触发了失衡：单独诊断轮

建议正式计时前，两种策略各做一次诊断。诊断模块仅通过可选 worker extension 在当前进程包装 `partition_batch`，不修改仓库文件，也不改变分配结果。它会读 CPU 元数据并写少量文件，因此**诊断服务的结果不能用于性能报告**。

```bash
bash serve.sh round_robin 1.5 trace
# 另一终端：
python run_serving.py --policy round_robin --case hot_half_32k \
  --warmup-rounds 0 --repeats 1 --out diagnostics/rr
python inspect_trace.py pcp_trace
```

正常停服务，再启动 `bash serve.sh load_balance 1.5 trace`，同样运行客户端并保存到 `diagnostics/lb`。日志位于**服务启动目录**的 `pcp_trace/worker-进程号.jsonl`；远程客户端应在服务端读取。

只记录包含 `pcpbench-` 请求 ID 的真实 32 请求、q=1、纯 decode 批次，排除 capture/dummy。每波最多记录 16 次，间隔 32 步。每条包含：

- 当前实际请求顺序、c、owner。
- 按同一份实际输入重算的轮询 attention 和实际 owner 的 attention。
- 各 rank 实际请求/token 数（这里 q=1，两者相同）。
- 分区收到的最终 padded tokens / padded requests，及 FULL / 非 FULL 标识。
- 当前 policy、factor 和是否存在 plan。

主用例期望看到：RR 的实际 attention 呈约八高八低；LB 的实际 attention 接近均匀；两者实际最大 tokens=2，且图 padding 桶一致。随着各请求在 prefill 期间已生成的 token 数不同，数值不会恰好等于静态表格。

若顺序已经被 scheduler 改得很均匀，就说明该轮没有触发预期失衡，不能据此否定/证明此策略收益。若 LB 的 `has_plan=false`，先检查是否运行当前修改、MRV2、decode sharding 和对应策略。若最大 tokens=3 或图桶变化，则将该轮归入“布局/图同时变化”，不能说只测到了 attention 收益。

诊断完成后重新以 `perf` 启动，再做正式 A/B。不要把 `diagnostics` 目录传给比较工具。

## 5. 推荐测试顺序

先 `hot_half_32k` 确认机制，再 `hot_half_16k` 看上下文长度敏感性；之后跑 `balanced_order_32k` 和 `uniform_8k` 验证负对照，最后测 `shuffled_32k`、`two_hot_32k`。

每种策略均可用以下命令跑全套：

```bash
python run_serving.py --policy round_robin --case all --out results/rr_all
# 正常重启为 load_balance 后：
python run_serving.py --policy load_balance --case all --out results/lb_all
python compare.py results/rr_all results/lb_all --output comparison_all.json
```

factor=1.0 对主用例通常仍允许每 rank 一长一短；`two_hot_32k` 更适合比较 factor=1.0/1.5 对图尺寸的影响。比较不同 factor 时必须同时改服务端和客户端标签，并分开保存结果；同一 A/B 配对中 factor 要一致。

## 6. DeepSeek V4 的解释边界

本地模型实现包含 sliding window、压缩 KV 和 indexer/top-k 路径，不能把 A=q*c+q*(q+1)/2 当作其精确 kernel 时间。尤其长上下文可能改变 indexer 扫描成本，而稀疏 attention 的访问规模受到压缩/选择规则影响。具体阈值来自你服务器权重的 config.json，本套用例不假定未知的阈值。

主用例预计能降低当前策略的 attention 代理指标，但最终是否加速还取决于 NPU 算子、MoE、通信和 CPU 规划。若 trace 显示均衡且图桶一致，而吞吐无提升，下一步应检查 attention/indexer 的实际时间占比；不要通过删掉负对照或更改测量窗口制造正收益。

这些是合成机制测试，不能代表全部生产流量。先验证机制，再用真实长度分布和到达速率测线上收益。当前工具刻意不加新请求，保证窗口内 32 请求共同活跃。

## 7. 本地验证与版本

2026-10-14：当前源码 CPU 模型分析共 36 组，客户端/指标计算/对比/诊断包装使用 CPU 测试验证。模型分析文件保存真实源码 SHA256；没有在本机运行 DeepSeek V4 或 NPU 性能测试。服务器 extension 导入、真实 HTTP SSE、HCCL、npugraph_ex/异步执行仍需服务器验证。

```bash
python -m unittest -v test_bench.py
python analyze.py --source /path/to/vllm-ascend/vllm_ascend/worker/v2/pcp_manager.py \
  --output model_estimates_server.json
```

只有分析脚本使用 NumPy，并执行所选本地源码方法，应只传入你信任的当前代码文件。

服务接口按配套 vLLM 提交 `ced6857afa0ea7b2e3f0846a62e1394e90f15607` 核对：[Completion 协议](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/openai/completion/protocol.py) 支持批量 token prompts、request_id、cache_salt 和流式 delta token IDs；[Worker 扩展入口](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/v1/worker/worker_base.py) 在 worker 初始化时导入扩展类。如果服务器使用其他 vLLM 版本，不支持字段时客户端会报错，不会把文本 chunk 数伪装成 token 数。

保存实验报告时同时记录服务完整命令、vLLM/vllm-ascend 提交及未提交补丁、CANN/驱动版本、卡型、服务器日志和图捕获信息。`--policy` 标签和模型名称本身不足以证明两套服务配置一致。
