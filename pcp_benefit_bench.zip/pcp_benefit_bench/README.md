# PCP=16 / DeepSeek V4：load_balance 收益测试

**交给服务器端 agent 执行时，先读 [SERVER_AGENT_RUNBOOK.md](SERVER_AGENT_RUNBOOK.md)。** 其中给出了独立结果目录、RR/LB 全 rank 诊断、精确 request_id 筛选、32K/48K/60K 正式 ABBA、失败处理及报告要求。本文解释用例与指标细节。

本套用例针对你提供的部署：`DeepSeek-V4-Flash-0731-w8a8`，TP=1、PCP=16、DP=1、PP=1、DCP=1、max_num_seqs=32、8192 token 调度预算、FULL_DECODE_ONLY、npugraph_ex、异步调度、prefix cache 开启。默认 factor=1.5。测试工具单独放在本目录，没有修改推理生产代码。

**目标是构造能触发轮询失衡的负载，并客观测量收益。不能保证 NPU 一定加速，也不能把 attention 估算下降当成实测速度提升。**

## 1. 先跑哪一个

主用例 `hot_half_32k`：32 个请求，16 个长度 32768、16 个长度 512，输出各 1024 token。

```text
请求顺序：
[长×8, 短×8, 长×8, 短×8]

round_robin：
rank  0..7：长 + 长
rank 8..15：短 + 短

load_balance 理想结果：
rank 0..15：长 + 短
```

纯 decode 时 q=1，原轮询每 rank 两个请求，平均 token 数=2，候选 token 预算=ceil(1.5×32/16)=3。此主用例均衡后仍只需要每 rank 两个 token，**避免把更多 token / 更大图 padding 混入主收益测试**。

在 c 等于输入长度的固定快照上，实际当前分配函数的结果为：

| 用例 | 上下文和顺序 | RR 最大 A → LB 最大 A | 模型下降 | 最大实际 token |
| --- | --- | --- | --- | --- |
| hot_half_8k | `[8192×8,512×8]` 重复两次 | 16386 → 8706 | 46.87% | 2 → 2 |
| hot_half_16k | `[16384×8,512×8]` 重复两次 | 32770 → 16898 | 48.43% | 2 → 2 |
| hot_half_32k | `[32768×8,512×8]` 重复两次 | 65538 → 33282 | 49.22% | 2 → 2 |
| hot_half_48k | `[49152×8,512×8]` 重复两次 | 98306 → 49666 | 49.48% | 2 → 2 |
| hot_half_60k | `[61440×8,512×8]` 重复两次 | 122882 → 61954 | 49.58% | 2 → 2 |
| balanced_order_32k | `[32768×16,512×16]` | 33282 → 33282 | 0% | 2 → 2 |
| shuffled_32k | 同样 16 长/16 短，固定种子打乱 | 65538 → 33282 | 49.22% | 2 → 2 |
| uniform_8k | 32 个请求都为 8192 | 16386 → 16386 | 0% | 2 → 2 |
| two_hot_32k | 下标 0、16 为 32768，其余 512 | 65538 → 32769 | 50% | 2 → 3 |

`balanced_order_32k` 是同长度分布、不同顺序的负对照；`uniform_8k` 检查规划开销；`two_hot_32k` 单独检查 request/token 放宽的收益是否被图桶增长抵消。打乱用例只是一组可复现的随机顺序，不代表生产流量总体。

上述结果由 `analyze.py` 提取当前 PCPManager 的真实 CPU 分配方法执行得到，不是另写一套近似算法。附带的 `model_estimates.json` 包含源码 SHA256、factor=1/1.5、decode 上下文增长 0/128/512 后共 54 个组合。请求初始顺序和相同上下文增量是这些静态估算的前提。

## 2. 快速运行 A/B

把整个目录复制到服务器，进入该目录。客户端只依赖 Python 3.10+ 标准库；CPU 模型分析另需 NumPy。先确保服务器已经安装当前完整修改。

第一次在服务终端运行：

```bash
bash serve.sh round_robin 1.5 perf
```

服务就绪后，在另一个终端运行：

```bash
python run_serving.py --policy round_robin --case hot_half_32k \
  --warmup-rounds 1 --repeats 3 --out results/rr_a
```

该命令完成后，正常停止这个测试服务，再启动另一策略：

```bash
bash serve.sh load_balance 1.5 perf
```

在客户端终端执行相同输入：

```bash
python run_serving.py --policy load_balance --case hot_half_32k \
  --warmup-rounds 1 --repeats 3 --out results/lb_a

python compare.py results/rr_a results/lb_a --output comparison.json
```

`serve.sh` 保留你提供的模型路径、端口、图、异步调度、量化和其他 additional-config；仅将策略/factor 参数化。脚本不会自动停止已有服务，也不会改端口绕过冲突。客户端 `--policy` / `--factor` 只是结果标签，**不会修改运行中服务器配置**，必须与实际启动命令一致。

不要在同一批 NPU 上同时启动两套服务。测试期间不要有其他请求。远程客户端需增加 `--base-url http://服务器地址:50001`；尽量在服务器本机或稳定低延迟连接运行。

首轮两组结果只用于初筛。正式报告再以 **A→B→B→A** 的服务启动顺序复测，分别用 `rr_a / lb_a / lb_b / rr_b` 保存；每次相同预热和重复次数，避免把温度、缓存或后台负载漂移当作策略收益。四组均完成后：

```bash
python compare.py results/rr_a results/lb_a results/lb_b results/rr_b \
  --output comparison_abba.json
```

## 3. 客户端到底测了什么

1. 调用该服务的 `/tokenize` 获取合法普通 token ID，构造精确长度的 token-ID prompts；两种策略使用相同 seed，结果中保存输入哈希。
2. 一次 `/v1/completions` 请求提交有序的 32 个 token-ID prompts，`n=1`。这样减少 32 个独立 HTTP 请求的到达乱序。实际 scheduler 顺序仍应通过下一节诊断确认，不能仅凭提交顺序断言 owner。
3. 使用 `temperature=0`、`ignore_eos=true`、每请求固定 1024 输出 token。不给 stop 条件；返回真实 delta token IDs。
4. 每轮独立 `cache_salt`，且每个请求首个 block 不同，保留 prefix cache 开关但避免前一轮预热/APC 命中造成输入工作量差异。相同 seed 的输入 token IDs 在 A/B 中保持一致。
5. 完整跑完预热轮，排除该轮结果。测量轮中，等**所有 32 个请求**都已经返回至少 65 个 token，再取共同起点。
6. 从共同起点开始，直到每个请求至少再返回 256 个 token，取共同终点；要求全部请求仍距结束有至少 32 token 余量。不足则保存原始事件并报错，不用 batch 缩小后的尾段冒充收益。
7. 用共同时间窗口中实际收到的 token 数计算吞吐。这里不把一个 SSE chunk 当一个 token；一个 chunk 含多个 token 时按实际 ID 数计数。
8. 读取 `/metrics` 前后抢占计数。发生抢占直接中止对比；指标缺失时比较工具默认拒绝，只有明确加 `--allow-missing-metrics` 才放行，且结果会标注没有验证。

输出字段：

| 字段 | 含义 |
| --- | --- |
| steady_output_tps | 全部请求共同 decode 窗口中的输出 tokens/s，主要指标 |
| batch_equivalent_tpot_ms | `32×窗口秒数×1000/窗口 token 数`，固定 batch 的等效 TPOT |
| chunk_amortized_gap_p50/p95_ms | 相邻流式 chunk 间隔除以 delta token 数；有合并 chunk 时不等同于真实单 token ITL 分位数 |
| single_token_chunk_fraction | 一 token 一个 chunk 的比例，检查流式合并程度 |
| mean_ttft_s | 输入提交到首 token 的均值，含 prefill，作为辅助指标 |
| e2e_output_tps | 包含 prefill 和尾段的整批输出吞吐，单独报告 |
| tokens_at_window_start/end | 每请求窗口边界输出计数，用于检查上下文进展 |
| preemptions | 测试波次内抢占增量，合格结果应为 0 |
| output_sha256 | 每请求完整输出 token 哈希，检查 A/B 输出差异 |

这是**客户端观察到的稳态吞吐/等效 TPOT**，含采样、调度、序列化与传输影响；不是 NPU attention kernel 的单独耗时。比较工具输出正负收益、中位数和 min/max，不筛掉负收益。输出哈希不同需要单独看数值精度/正确性，不能只看吞吐就宣布成功。

如果 1024 输出没有足够共同窗口，两边同时改为 `--output-tokens 2048`，重做相同用例；不能一边 1024、一边 2048。总长度需低于 65536。不要只调低窗口把抢占或失去共同 batch 的问题隐藏掉。

## 4. 先确认实际触发了失衡：单独诊断轮

建议正式计时前，两种策略各做一次诊断。诊断模块仅通过可选 worker extension 在当前进程包装 `partition_batch`，不修改仓库文件，也不改变分配结果。它会读 CPU 元数据并写少量文件，因此**诊断服务的结果不能用于性能报告**。

```bash
bash serve.sh round_robin 1.5 trace
# 另一终端：
python run_serving.py --policy round_robin --case hot_half_32k \
  --warmup-rounds 0 --repeats 1 --out diagnostics/rr
python inspect_trace.py pcp_trace
```

正常停服务，再启动 `bash serve.sh load_balance 1.5 trace`，同样运行客户端并保存到 `diagnostics/lb`。新版日志位于**服务启动目录**的 `pcp_trace/worker-rank编号-进程号.jsonl`；远程客户端应在服务端读取。旧版的 `worker-进程号.jsonl` 也可由新版查看工具读取。

只记录包含 `pcpbench-` 请求 ID 的真实 32 请求、q=1、纯 decode 批次，排除 capture/dummy。新版在每个 PCP rank 记录实际返回的本地分区；每 rank 每波最多记录 16 次，间隔 32 步。每条包含：

- 当前实际请求顺序、c、owner。
- 按同一份实际输入重算的轮询 attention 和实际 owner 的 attention。
- 各 rank 实际请求/token 数（这里 q=1，两者相同）。
- 分区收到的最终 padded tokens / padded requests，及 FULL / 非 FULL 标识。
- 当前 policy、factor 和是否存在 plan。
- 本 worker 的 `pcp_rank`、`local_partition.requests`（实际请求 ID/c/q）、实际 token 数和返回的 padding 大小。
- `local_matches_assignment`：实际本地请求、c/q、token 总数是否与分配表一致。

`owners`、`actual.rows/attention` 是从 plan（无 plan 时从轮询规则）得到的分配表及统计；独立的实际分区证据来自 `local_partition`。旧版只有前者，不应把旧日志称为 16 个 rank 的独立观测。

### 4.1 展开已有日志，不必重新跑模型

更新本目录的 `inspect_trace.py` 后，可以直接读取之前保存的 JSONL：

```bash
python inspect_trace.py pcp_trace --details --policy round_robin \
  --request-contains hot_half_32k --limit 1
python inspect_trace.py pcp_trace --details --policy load_balance \
  --request-contains hot_half_32k --limit 1
```

按 rank 打印每个请求 ID、全局批次下标、`c`、`q`、`seq_len=c+q`、原轮询 rank 和分配 rank；同时打印该 rank 的实际请求数、token 数、`sum_c`、`max_c`、attention 代理指标。`c` 是该步之前已计算的 token 数，包含已生成历史，并非固定的初始 prompt 长度。旧日志会标注 `source=plan_or_round_robin_only`、`all_ranks_verified=False`，表示缺少独立本地分区证据，不表示分配错误。

### 4.2 核对各 rank 实际分区

使用新版整个目录，以 `trace` 模式重新启动服务并完成诊断请求后执行：

```bash
python inspect_trace.py pcp_trace --details --verify --policy load_balance \
  --request-contains 本轮完整request_id --limit 1
```

把 `本轮完整request_id` 替换为 `diagnostics/lb/*.json` 中的 `request_id`。它包含唯一后缀，可避免混入旧版日志或前一轮数据。看所有采样步时去掉 `--limit 1`。

只有同一请求集合、同一 c/q 快照下，16 个 rank 的本地证据齐全且各出现一次、owner 表一致、实际 request/c/q 与归属一致、实际 token 总数匹配，才显示 `all_ranks_verified=True`。实际请求来自 `partition_batch` 的返回值，显示 `source=partition_return`。缺失 rank、重复 rank、不同上下文的记录不会拼成一次验证通过；`--verify` 遇到缺失或不一致返回非零状态。旧日志请使用 4.1，不要用 `--verify` 要求它提供不存在的证据。

日志只读取已有 CPU 数组，不新增设备张量读取或 NPU 同步；所有 rank 的日志写入仍会增加诊断开销。正式测速须重启为 `perf`。

主用例期望看到：RR 的实际 attention 呈约八高八低；LB 的实际 attention 接近均匀；两者实际最大 tokens=2，且图 padding 桶一致。随着各请求在 prefill 期间已生成的 token 数不同，数值不会恰好等于静态表格。

若顺序已经被 scheduler 改得很均匀，就说明该轮没有触发预期失衡，不能据此否定/证明此策略收益。若 LB 的 `has_plan=false`，先检查是否运行当前修改、MRV2、decode sharding 和对应策略。若最大 tokens=3 或图桶变化，则将该轮归入“布局/图同时变化”，不能说只测到了 attention 收益。

诊断完成后重新以 `perf` 启动，再做正式 A/B。不要把 `diagnostics` 目录传给比较工具。

### 4.3 是否保留或回退到 round_robin

新版查看工具会比较每个请求的 `owners[i]` 与 `i % PCP`（本 trace 只采集全局纯 decode 且 q=1 的批次），旧 JSONL 也支持。默认 JSON 摘要和 `--details` 均显示：

| assignment_status | 判定 | 含义 |
| --- | --- | --- |
| lb_applied | LB + 有 plan + 至少一个 owner 改变 | 规划采用了与轮询不同的分配 |
| rr_retained | LB + 有 plan + 所有 owner 与轮询相同 | 规划最终保留/回退为轮询；可能是正常的“没有更好方案” |
| rr_no_plan | LB + 无 plan + 轮询分配 | 本轮未使用 LB plan，不能冒充“执行了规划再回退” |
| rr_configured | RR 配置 + 轮询分配 | 本来就启用轮询，不属于 LB 回退 |
| inconsistent_trace | 例如无 plan 却记录非轮询 owner | 日志信息不符合当前采集逻辑，需要核查 |

`moved_request_count` 是相对本轮轮询归属改变的请求数，不是相对上一 decode step 的迁移数，也不表示 KV cache 被搬运。`fallback_to_round_robin=true` 对应 `rr_retained`；`rr_no_plan` 时该字段为 null，保留是否执行过规划的未知性。

**`has_plan=true` 本身不能证明 LB 改变了分配，也不能只比较每 rank 请求数或 attention 汇总来判断 owner 是否改变。** 原分配本来均衡时，保留轮询是预期行为。

以上状态首先描述保存的 owner 表。只有 `all_ranks_verified=True` 时，`actual_matches_round_robin` 才给出实际分区是否为轮询的布尔结果；旧日志或验证失败时该字段是 null，不把计划当成设备执行证据。

日志尚未捕获算法内部具体返回分支，因此 `rr_retained` 的 `fallback_reason` 标为 `not_recorded`。不能仅凭 owner 相同就断言是 token/request 容量不足、收益不足或其他保护分支。当前诊断仍是每 32 个符合条件的 decode 步采样，不能据此统计整个运行的精确回退率。

## 5. 推荐测试顺序

先 `hot_half_32k` 确认机制，再按 8K/16K/32K/48K/60K 做长度扫描；之后跑 `balanced_order_32k` 和 `uniform_8k` 验证负对照，最后测 `shuffled_32k`、`two_hot_32k`。`--case all` 现在也包含 48K/60K，请先确认单个长用例能够维持无抢占的共同 decode 窗口。

每种策略均可用以下命令跑全套：

```bash
python run_serving.py --policy round_robin --case all --out results/rr_all
# 正常重启为 load_balance 后：
python run_serving.py --policy load_balance --case all --out results/lb_all
python compare.py results/rr_all results/lb_all --output comparison_all.json
```

factor=1.0 对主用例通常仍允许每 rank 一长一短；`two_hot_32k` 更适合比较 factor=1.0/1.5 对图尺寸的影响。比较不同 factor 时必须同时改服务端和客户端标签，并分开保存结果；同一 A/B 配对中 factor 要一致。

### 5.1 检验“上下文还不够长”的假设

保持 PCP=16、batch=32、短请求长度 512、factor=1.5、图配置不变，只改变 16 个长请求的长度。每个长度都做相同 RR/LB 对照；可以先测 48K，再测 60K。服务以对应策略的 `perf` 模式启动后，客户端例如：

```bash
python run_serving.py --policy round_robin --case hot_half_48k \
  --warmup-rounds 1 --repeats 3 --out results/rr_48k_a
# 正常重启服务为 load_balance / perf 后：
python run_serving.py --policy load_balance --case hot_half_48k \
  --warmup-rounds 1 --repeats 3 --out results/lb_48k_a
python compare.py results/rr_48k_a results/lb_48k_a --output comparison_48k.json
```

60K 使用 `hot_half_60k` 和新的结果目录。初筛后照 §2 做 ABBA。所有长度默认各输出 1024；若长短请求进度差导致共同窗口不足，两种策略一同改为 2048 重跑。为了比较完整长度曲线，应将其他长度也使用相同输出预算重测，别与旧 1024 结果混成同一配对。

| 用例 | 长 prompt token 数 | 加 1024 输出后的最长序列 | 相对 32K 用例的总 prompt token 数 |
| --- | --- | --- | --- |
| hot_half_32k | 32768 | 33792 | 1.00× |
| hot_half_48k | 49152 | 50176 | 1.49× |
| hot_half_60k | 61440 | 62464 | 1.86× |

60K 加 2048 输出为 63488，仍在当前 `max_model_len=65536` 内。**这里仅确认序列长度合法，不能证明服务器 KV cache 容量足够。** 长用例会增加缓存需求和 prefill 时间；出现抢占、请求无法共同活跃或 OOM 时，该固定 batch 实验条件不成立。保留失败记录，不要减少 batch 后继续与原 batch=32 结果当作同一个实验。

比较时记录每个长度的 RR/LB 稳态吞吐、graph tokens/rows、实际 rank 放置和 `sum_c/max_c`，必要时增加 indexer/attention 设备 profile：

- 长度增加后 LB 收益稳定出现且图桶仍相同：支持长度相关工作占比或算子形状敏感性影响收益，需要 profile 区分。
- RR 和 LB 一起变慢、二者始终无差异：上下文确实影响总耗时，但均衡目标未必能改善关键路径。
- 长度增加后二者都变化很小：可能受固定开销、稀疏访问上限或其他工作限制，仍需设备计时确认。

32K 已有约 49.22% 的代理下降，60K 仅增至约 49.58%。这组测试主要增大绝对上下文工作量，不能保证改善分配比例或获得速度收益。每 rank 请求数仍约为 2，不能用它单独排除“长+长与长+短算子耗时相近”的解释。

## 6. DeepSeek V4 的解释边界

本地模型实现包含 sliding window、压缩 KV 和 indexer/top-k 路径，不能把 A=q*c+q*(q+1)/2 当作其精确 kernel 时间。尤其长上下文可能改变 indexer 扫描成本，而稀疏 attention 的访问规模受到压缩/选择规则影响。具体阈值来自你服务器权重的 config.json，本套用例不假定未知的阈值。

主用例预计能降低当前策略的 attention 代理指标，但最终是否加速还取决于 NPU 算子、MoE、通信和 CPU 规划。若 trace 显示均衡且图桶一致，而吞吐无提升，下一步应检查 attention/indexer 的实际时间占比；不要通过删掉负对照或更改测量窗口制造正收益。

这些是合成机制测试，不能代表全部生产流量。先验证机制，再用真实长度分布和到达速率测线上收益。当前工具刻意不加新请求，保证窗口内 32 请求共同活跃。

## 7. 本地验证与版本

2026-10-15：当前源码 CPU 模型分析共 54 组；25 项本地测试覆盖客户端、指标计算、对比、全 rank 诊断、旧日志兼容、错误分区检测及轮询保留/未规划/重新分配的状态区分。模型分析文件保存真实源码 SHA256；本机没有运行 DeepSeek V4 或 NPU 性能测试。用户已反馈旧版工具在服务器的 32K ABBA 测试没有可测收益；本次新增的全 rank 诊断和长上下文用例仍需服务器验证。

```bash
python -m unittest -v test_bench.py
python analyze.py --source /path/to/vllm-ascend/vllm_ascend/worker/v2/pcp_manager.py \
  --output model_estimates_server.json
```

只有分析脚本使用 NumPy，并执行所选本地源码方法，应只传入你信任的当前代码文件。

服务接口按配套 vLLM 提交 `ced6857afa0ea7b2e3f0846a62e1394e90f15607` 核对：[Completion 协议](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/entrypoints/openai/completion/protocol.py) 支持批量 token prompts、request_id、cache_salt 和流式 delta token IDs；[Worker 扩展入口](https://github.com/vllm-project/vllm/blob/ced6857afa0ea7b2e3f0846a62e1394e90f15607/vllm/v1/worker/worker_base.py) 在 worker 初始化时导入扩展类。如果服务器使用其他 vLLM 版本，不支持字段时客户端会报错，不会把文本 chunk 数伪装成 token 数。

保存实验报告时同时记录服务完整命令、vLLM/vllm-ascend 提交及未提交补丁、CANN/驱动版本、卡型、服务器日志和图捕获信息。`--policy` 标签和模型名称本身不足以证明两套服务配置一致。
