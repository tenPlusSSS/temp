# Validation — 2026-10-15

- 25 standard-library unit tests passed, including synthetic SSE client integration, isolated diagnostic wrapper execution for all 16 ranks, old-log rendering, rejection of missing/duplicate ranks, inconsistent owners, wrong actual placements, context/token-count mismatches and mismatched snapshots, and distinction between applied LB, retained RR, configured RR and missing LB plans.
- 54 analyses ran selected real CPU methods from the current PCPManager (nine cases, factors 1.0/1.5, context offsets 0/128/512). These are cost-model estimates, not device timing.
- The 8K/16K/32K/48K/60K length sweep fits max_model_len=65536 with 1024 or 2048 output tokens. This is a sequence-length check, not a hardware memory-capacity guarantee.
- Ruff lint/format, Python source parsing and Bash syntax checks passed.
- CLI smoke checks passed for complete all-rank details, nonzero verification exit on incomplete evidence, and backward-compatible rendering of legacy plan-only logs (synthetic CPU fixtures).
- Source SHA256 matches model_estimates.json. Production repository files were not changed by this benchmark task.
- NOT run here: the actual DeepSeek V4 server, remote HTTP streaming, worker-extension loading under vLLM, HCCL, NPU kernels, graph replay, or hardware performance measurements.
- The user supplied a previous server report for hot_half_32k: no measurable throughput benefit. The new all-rank trace and longer cases have not yet been validated on that server.
- Added SERVER_AGENT_RUNBOOK.md with exact-run diagnostic filtering, separate RR/LB trace startups, four independent perf startups for ABBA, failure handling and report requirements. Its Bash code blocks passed syntax checking without running the server or NPU tests.
