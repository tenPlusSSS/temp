"""Run actual production CPU assignment methods; never claim NPU speedups."""

import argparse
import ast
import hashlib
import json
import math
from collections.abc import Iterator
from pathlib import Path
from types import SimpleNamespace

import numpy as np
from cases import make_cases


def load_manager(source):
    tree = ast.parse(source.read_text(encoding="utf-8"))
    cls = next(
        n
        for n in tree.body
        if isinstance(n, ast.ClassDef) and n.name == "AscendPCPManager"
    )
    methods = {
        "_balance_decode_owners",
        "_get_decode_token_budget",
        "_get_local_request_capacity",
        "_iter_rank_chunks",
        "is_decode_sharded",
    }
    cls.body = [
        n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name in methods
    ]
    if len(cls.body) != len(methods):
        raise ValueError("Source does not contain the expected current strategy")
    cls.bases = []
    module = ast.fix_missing_locations(ast.Module(body=[cls], type_ignores=[]))
    namespace = {"np": np, "math": math, "Iterator": Iterator}
    # Execute only selected methods from the user's trusted local checkout.
    exec(compile(module, str(source), "exec", flags=0x1000000), namespace)  # noqa: S102
    return namespace["AscendPCPManager"]


def analyze_case(manager_type, case, factor=1.5, decode_offset=0):
    world = case["pcp"]
    counts = np.ones(len(case["prompt_lengths"]), dtype=np.int32)
    contexts = np.array(case["prompt_lengths"], dtype=np.int64) + decode_offset
    manager = manager_type()
    manager.pcp_world_size = world
    manager.decode_balance_token_factor = factor
    manager._decode_owner_ranks = None
    manager._input_buffers = SimpleNamespace(max_num_reqs=64, max_num_tokens=8192)
    manager._local_block_tables = [np.empty((64, 0))]
    manager.vllm_config = SimpleNamespace(
        parallel_config=SimpleNamespace(
            pcp_shard_decode_requests=True, pipeline_parallel_size=1
        ),
        speculative_config=None,
    )
    owners = manager._balance_decode_owners(
        counts, np.zeros(len(counts), dtype=bool), contexts
    )
    rr = np.arange(len(counts)) % world

    def stats(assignment):
        tokens = [
            sum(int(counts[i]) for i in range(len(counts)) if assignment[i] == r)
            for r in range(world)
        ]
        work = [
            sum(int(contexts[i]) + 1 for i in range(len(counts)) if assignment[i] == r)
            for r in range(world)
        ]
        return {
            "tokens": tokens,
            "attention_work": work,
            "max_tokens": max(tokens),
            "max_attention": max(work),
        }

    old, new = stats(rr), stats(owners)
    return {
        "case": case["name"],
        "factor": factor,
        "decode_offset": decode_offset,
        "candidate_budget": manager._get_decode_token_budget(counts),
        "round_robin": old,
        "load_balance": new,
        "owners": owners.tolist(),
        "estimated_attention_reduction_pct": 100
        * (1 - new["max_attention"] / old["max_attention"]),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--source", type=Path, required=True, help="Current worker/v2/pcp_manager.py"
    )
    parser.add_argument("--output", type=Path, default=Path("model_estimates.json"))
    args = parser.parse_args()
    manager_type = load_manager(args.source)
    rows = [
        analyze_case(manager_type, c, f, offset)
        for c in make_cases()
        for f in (1.0, 1.5)
        for offset in (0, 128, 512)
    ]
    args.output.write_text(
        json.dumps(
            {
                "kind": "CPU cost-model estimates, NOT NPU timings",
                "source_sha256": hashlib.sha256(args.source.read_bytes()).hexdigest(),
                "cases": make_cases(),
                "results": rows,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    for r in rows:
        if r["factor"] == 1.5 and r["decode_offset"] == 0:
            print(
                f"{r['case']:24} Amax {r['round_robin']['max_attention']:7} -> "
                f"{r['load_balance']['max_attention']:7}; tokens "
                f"{r['round_robin']['max_tokens']} -> {r['load_balance']['max_tokens']}; "
                f"model reduction {r['estimated_attention_reduction_pct']:.2f}%"
            )


if __name__ == "__main__":
    main()
