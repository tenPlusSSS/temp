"""Deterministic workloads for TP=1 / PCP=16 / DP=1 / PP=1."""

import random


def make_cases():
    world, batch, short = 16, 32, 512
    cases = []
    for long in (16384, 32768):
        lengths = [long if i % world < world // 2 else short for i in range(batch)]
        cases.append(
            {
                "name": f"hot_half_{long // 1024}k",
                "pcp": world,
                "prompt_lengths": lengths,
                "purpose": "16 long requests collide in pairs on eight round-robin ranks",
            }
        )
    balanced = [32768] * 16 + [short] * 16
    shuffled = balanced.copy()
    random.Random(20261014).shuffle(shuffled)
    cases.extend(
        [
            {
                "name": "balanced_order_32k",
                "pcp": world,
                "prompt_lengths": balanced,
                "purpose": "same length multiset, already one long plus one short per RR rank",
            },
            {
                "name": "shuffled_32k",
                "pcp": world,
                "prompt_lengths": shuffled,
                "purpose": "seeded order control; do not assume the serving scheduler preserves order",
            },
            {
                "name": "uniform_8k",
                "pcp": world,
                "prompt_lengths": [8192] * batch,
                "purpose": "negative control: balanced attention; expose planner overhead",
            },
            {
                "name": "two_hot_32k",
                "pcp": world,
                "prompt_lengths": [
                    32768 if i in (0, 16) else short for i in range(batch)
                ],
                "purpose": "only two long requests collide; may grow local token/graph demand",
            },
        ]
    )
    return cases


def get_case(name):
    return next(c for c in make_cases() if c["name"] == name)
