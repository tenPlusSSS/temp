"""Summarize measured server results, rejecting mismatched or preempted runs."""

import argparse
import json
import statistics
from pathlib import Path


def comparable_key(row):
    return (
        row["case"],
        row["model"],
        row["pcp"],
        row["batch_size"],
        row["prompt_sha256"],
        row["seed"],
        row["output_tokens_per_request"],
        row["warmup_tokens"],
        row["window_tokens"],
        row["factor_label"],
    )


def compare(rows, allow_missing_metrics=False):
    groups = {}
    for row in rows:
        if row.get("phase") != "measure":
            continue
        if row.get("valid_window") is False:
            raise ValueError("Invalid steady window: " + row["request_id"])
        if row.get("preemptions") != 0 and not (
            allow_missing_metrics and row.get("preemptions") is None
        ):
            raise ValueError(
                "Preempted run or missing preemption metrics: " + row["request_id"]
            )
        key = comparable_key(row)
        groups.setdefault(key, {"round_robin": [], "load_balance": []})[
            row["policy_label"]
        ].append(row)
    if not groups:
        raise ValueError("No measured results")
    result = []
    for key, policies in groups.items():
        rr, lb = policies["round_robin"], policies["load_balance"]
        if not rr or not lb or len(rr) != len(lb):
            raise ValueError(
                f"Missing/mismatched A/B inputs or repeat counts: {key[0]}"
            )
        old = statistics.median(r["steady_output_tps"] for r in rr)
        new = statistics.median(r["steady_output_tps"] for r in lb)
        result.append(
            {
                "case": key[0],
                "repeats_per_policy": len(rr),
                "factor": key[-1],
                "rr_steady_tps_median": old,
                "lb_steady_tps_median": new,
                "throughput_gain_pct": 100 * (new / old - 1),
                "rr_tpot_ms_median": statistics.median(
                    r["batch_equivalent_tpot_ms"] for r in rr
                ),
                "lb_tpot_ms_median": statistics.median(
                    r["batch_equivalent_tpot_ms"] for r in lb
                ),
                "rr_tps_min_max": [
                    min(r["steady_output_tps"] for r in rr),
                    max(r["steady_output_tps"] for r in rr),
                ],
                "lb_tps_min_max": [
                    min(r["steady_output_tps"] for r in lb),
                    max(r["steady_output_tps"] for r in lb),
                ],
                "output_hash_sets_equal": {tuple(r["output_sha256"]) for r in rr}
                == {tuple(r["output_sha256"]) for r in lb},
                "preemption_metrics_verified": all(
                    r.get("preemptions") == 0 for r in rr + lb
                ),
            }
        )
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--allow-missing-metrics", action="store_true")
    parser.add_argument("--output", type=Path, default=Path("comparison.json"))
    args = parser.parse_args()
    files = sorted(
        {p.resolve() for folder in args.folders for p in folder.rglob("*.json")}
    )
    rows = [json.loads(p.read_text(encoding="utf-8")) for p in files]
    result = compare(rows, args.allow_missing_metrics)
    args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    for row in result:
        print(json.dumps(row, ensure_ascii=False))


if __name__ == "__main__":
    main()
