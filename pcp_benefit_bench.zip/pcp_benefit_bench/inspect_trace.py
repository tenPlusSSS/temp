"""Show actual rank ownership and graph padding from diagnostic workers."""

import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    args = parser.parse_args()
    count = 0
    for path in sorted(args.folder.glob("*.jsonl")):
        for line in path.read_text(encoding="utf-8").splitlines():
            row = json.loads(line)
            old, new = (
                max(row["round_robin"]["attention"]),
                max(row["actual"]["attention"]),
            )
            print(
                json.dumps(
                    {
                        "request": row["request_ids"][0],
                        "policy": row["policy"],
                        "step": row["decode_step_in_trace"],
                        "rr_rows": row["round_robin"]["rows"],
                        "actual_rows": row["actual"]["rows"],
                        "rr_attention": row["round_robin"]["attention"],
                        "actual_attention": row["actual"]["attention"],
                        "model_reduction_pct": 100 * (1 - new / old),
                        "graph_tokens": row["padded_num_tokens"],
                        "graph_rows": row["padded_num_reqs"],
                        "has_plan": row["has_plan"],
                        "mode": row["mode"],
                    }
                )
            )
            count += 1
    if not count:
        raise SystemExit(
            "No real 32-request pure-decode trace. Check worker import and pcpbench request IDs."
        )


if __name__ == "__main__":
    main()
