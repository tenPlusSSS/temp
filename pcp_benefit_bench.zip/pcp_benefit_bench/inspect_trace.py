"""Inspect planned ownership and independently observed local partitions."""

import argparse
import json
from collections import Counter
from pathlib import Path


def assignment_status(row):
    """Classify the saved owner table; do not invent the branch's reason."""
    if len(row["owners"]) != len(row["request_ids"]):
        raise ValueError("Owner count does not match request count")
    moved = sum(owner != i % row["pcp"] for i, owner in enumerate(row["owners"]))
    same = moved == 0
    fallback = None
    if row["policy"] == "round_robin" and same:
        status, fallback = "rr_configured", False
    elif row["policy"] == "load_balance" and row["has_plan"]:
        status = "rr_retained" if same else "lb_applied"
        fallback = same
    elif row["policy"] == "load_balance" and same:
        status = "rr_no_plan"
    else:
        status = "inconsistent_trace"
    return {
        "assignment_status": status,
        "matches_round_robin": same,
        "moved_request_count": moved,
        "fallback_to_round_robin": fallback,
        "fallback_reason": "not_recorded" if fallback else None,
    }


def group_snapshots(records):
    groups = {}
    for row in records:
        # Match full input snapshots across processes, never just step counters.
        key = (
            row["policy"],
            row["factor"],
            row["pcp"],
            tuple(row["request_ids"]),
            tuple(row["contexts"]),
            tuple(row.get("scheduled_tokens", [1] * len(row["request_ids"]))),
        )
        groups.setdefault(key, []).append(row)
    return list(groups.values())


def verify_snapshot(rows):
    first = rows[0]
    world = first["pcp"]
    observed = [r for r in rows if "local_partition" in r]
    ranks = Counter(r["pcp_rank"] for r in observed)
    missing = sorted(set(range(world)) - ranks.keys())
    duplicate = sorted(r for r, count in ranks.items() if count != 1)
    unexpected = sorted(ranks.keys() - set(range(world)))
    owners_agree = all(r["owners"] == first["owners"] for r in rows)
    expected = sorted(
        (owner, req_id, c, q)
        for req_id, c, q, owner in zip(
            first["request_ids"],
            first["contexts"],
            first.get("scheduled_tokens", [1] * len(first["request_ids"])),
            first["owners"],
            strict=True,
        )
    )
    actual = sorted(
        (r["pcp_rank"], req["request_id"], req["c"], req["q"])
        for r in observed
        for req in r["local_partition"]["requests"]
    )
    local_counts_match = all(
        sum(req["q"] for req in r["local_partition"]["requests"])
        == r["local_partition"]["num_tokens"]
        for r in observed
    )
    complete = not missing and not duplicate and not unexpected
    return {
        "verified": complete
        and owners_agree
        and actual == expected
        and local_counts_match,
        "complete": complete,
        "observed_ranks": sorted(ranks),
        "missing_ranks": missing,
        "duplicate_ranks": duplicate,
        "unexpected_ranks": unexpected,
        "owners_agree": owners_agree,
        "placements_match": actual == expected if complete else None,
        "local_token_counts_match": local_counts_match if observed else None,
        "legacy_plan_only": not observed,
    }


def print_details(rows):
    row = next((r for r in rows if r.get("pcp_rank", 0) == 0), rows[0])
    check = verify_snapshot(rows)
    decision = assignment_status(row)
    print(
        f"policy={row['policy']} step={row['decode_step_in_trace']} "
        f"batch={row['request_ids'][0]} plan={row['has_plan']} "
        f"assignment_status={decision['assignment_status']} "
        f"moved_request_count={decision['moved_request_count']} "
        f"graph_tokens/rows={row['padded_num_tokens']}/{row['padded_num_reqs']} "
        f"all_ranks_verified={check['verified']}"
    )
    print(
        "assignment="
        + json.dumps(
            {
                **decision,
                "actual_matches_round_robin": (
                    decision["matches_round_robin"] if check["verified"] else None
                ),
            }
        )
    )
    indices = {req_id: i for i, req_id in enumerate(row["request_ids"])}
    observed = {r["pcp_rank"]: r for r in rows if "local_partition" in r}
    counts = row.get("scheduled_tokens", [1] * len(row["request_ids"]))
    for rank in range(row["pcp"]):
        if rank in observed:
            requests = observed[rank]["local_partition"]["requests"]
            source = "partition_return"
        else:
            requests = [
                {"request_id": req_id, "c": c, "q": q}
                for req_id, c, q, owner in zip(
                    row["request_ids"],
                    row["contexts"],
                    counts,
                    row["owners"],
                    strict=True,
                )
                if owner == rank
            ]
            source = "plan_or_round_robin_only"
        work = sum(r["q"] * r["c"] + r["q"] * (r["q"] + 1) // 2 for r in requests)
        print(
            f"rank={rank:02d} source={source} reqs={len(requests)} "
            f"tokens={sum(r['q'] for r in requests)} "
            f"sum_c={sum(r['c'] for r in requests)} "
            f"max_c={max((r['c'] for r in requests), default=0)} attention_proxy={work}"
        )
        for req in requests:
            index = indices.get(req["request_id"])
            rr = index % row["pcp"] if index is not None else "unknown"
            owner = row["owners"][index] if index is not None else "unknown"
            print(
                f"  index={index} req={req['request_id']} c={req['c']} q={req['q']} "
                f"seq_len={req['c'] + req['q']} rr_rank={rr} assigned_rank={owner}"
            )
    if not check["verified"]:
        print("verification=" + json.dumps(check))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument(
        "--details", action="store_true", help="Print every request by rank"
    )
    parser.add_argument(
        "--verify", action="store_true", help="Require all ranks' actual partitions"
    )
    parser.add_argument("--policy", choices=["round_robin", "load_balance"])
    parser.add_argument(
        "--request-contains", default="", help="Filter case/run ID substring"
    )
    parser.add_argument(
        "--limit", type=int, default=0, help="Maximum snapshots; 0 means all"
    )
    args = parser.parse_args()
    if args.limit < 0:
        parser.error("--limit must be nonnegative")
    records = []
    for path in sorted(args.folder.glob("*.jsonl")):
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            if args.policy and row["policy"] != args.policy:
                continue
            if not any(args.request_contains in req for req in row["request_ids"]):
                continue
            records.append(row)
    groups = group_snapshots(records)
    if args.limit:
        groups = groups[: args.limit]
    if not groups:
        raise SystemExit(
            "No matching real 32-request pure-decode trace. Check filters and worker import."
        )
    failed = False
    for rows in groups:
        row = next((r for r in rows if r.get("pcp_rank", 0) == 0), rows[0])
        check = verify_snapshot(rows)
        decision = assignment_status(row)
        failed |= not check["verified"]
        if args.details:
            print_details(rows)
        else:
            old = max(row["round_robin"]["attention"])
            new = max(row["actual"]["attention"])
            print(
                json.dumps(
                    {
                        "request": row["request_ids"][0],
                        "policy": row["policy"],
                        "step": row["decode_step_in_trace"],
                        "rr_rows": row["round_robin"]["rows"],
                        "actual_rows": row["actual"]["rows"],
                        "rr_attention": row["round_robin"]["attention"],
                        "actual_attention": row["actual"]["attention"],
                        "model_reduction_pct": 100 * (1 - new / old),
                        "graph_tokens": row["padded_num_tokens"],
                        "graph_rows": row["padded_num_reqs"],
                        "has_plan": row["has_plan"],
                        "mode": row["mode"],
                        **decision,
                        "actual_matches_round_robin": (
                            decision["matches_round_robin"]
                            if check["verified"]
                            else None
                        ),
                        "partition_verification": check,
                    }
                )
            )
    if args.verify and failed:
        raise SystemExit(
            "Some snapshots lack all-rank evidence or have inconsistent partitions."
        )


if __name__ == "__main__":
    main()
