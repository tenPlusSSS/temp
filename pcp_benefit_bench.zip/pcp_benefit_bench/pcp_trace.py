"""Opt-in, diagnostic-only worker extension; restart without it for timings.

Import via --worker-extension-cls pcp_trace.TraceExtension. No repository files
are changed. Captures only real pcpbench requests, never graph-capture dummies.
"""

import functools
import json
import os
from pathlib import Path

from vllm_ascend.worker.v2.pcp_manager import AscendPCPManager


class TraceExtension:
    """Marker class loaded by vLLM's worker-extension import mechanism."""


def install(manager_type):
    original = manager_type.partition_batch
    if getattr(original, "_pcp_bench_trace", False):
        return

    @functools.wraps(original)
    def traced(self, input_batch, padded_num_tokens=None, padded_num_reqs=None):
        record = None
        ids = input_batch.req_ids
        if (
            self.pcp_rank == 0
            and self.is_decode_sharded
            and len(ids) == 32
            and all("pcpbench-" in r for r in ids)
            and not input_batch.is_prefilling_np.any()
            and all(int(q) == 1 for q in input_batch.num_scheduled_tokens)
        ):
            state = getattr(self, "_pcp_bench_trace_state", None)
            key = tuple(ids)
            if state is None or state["ids"] != key:
                state = {"ids": key, "steps": 0, "written": 0}
                self._pcp_bench_trace_state = state
            state["steps"] += 1
            if state["written"] < 16 and (state["steps"] - 1) % 32 == 0:
                contexts = list(map(int, input_batch.num_computed_tokens_np))
                plan = self._decode_partition_plan
                world = self.pcp_world_size
                rr = [i % world for i in range(len(ids))]
                owners = list(map(int, plan.owner_ranks)) if plan is not None else rr

                def totals(assignment):
                    return {
                        "rows": [
                            sum(owner == r for owner in assignment)
                            for r in range(world)
                        ],
                        "attention": [
                            sum(
                                contexts[i] + 1
                                for i, owner in enumerate(assignment)
                                if owner == r
                            )
                            for r in range(world)
                        ],
                    }

                record = {
                    "policy": self.decode_balance_policy,
                    "factor": self.decode_balance_token_factor,
                    "pcp": world,
                    "request_ids": list(ids),
                    "contexts": contexts,
                    "owners": owners,
                    "round_robin": totals(rr),
                    "actual": totals(owners),
                    "has_plan": plan is not None,
                    "decode_step_in_trace": state["steps"],
                    "padded_num_tokens": padded_num_tokens,
                    "padded_num_reqs": padded_num_reqs,
                    "mode": "FULL" if padded_num_reqs is not None else "non_FULL",
                }
                state["written"] += 1
        local = original(self, input_batch, padded_num_tokens, padded_num_reqs)
        if record is not None:
            folder = Path.cwd() / "pcp_trace"
            folder.mkdir(exist_ok=True)
            with (folder / f"worker-{os.getpid()}.jsonl").open(
                "a", encoding="utf-8"
            ) as stream:
                stream.write(json.dumps(record) + "\n")
        return local

    traced._pcp_bench_trace = True
    manager_type.partition_batch = traced


# This module is imported inside each worker by the explicitly selected extension.
install(AscendPCPManager)
