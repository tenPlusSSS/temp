"""Construct bounded shared prefixes and validate token-level APC counters."""

import json
import math
import time
from fractions import Fraction

DEFAULT_PREFIX_HIT_RATIO = 0.9
DEFAULT_PREFIX_BLOCK_SIZE = 32
QUERIES = "vllm:prefix_cache_queries_total"
HITS = "vllm:prefix_cache_hits_total"
PREEMPTIONS = "vllm:num_preemptions_total"


class CacheValidationError(ValueError):
    def __init__(self, message, details):
        super().__init__(message)
        self.details = details


def make_cache_plan(prompts, ratio=DEFAULT_PREFIX_HIT_RATIO, block_size=32):
    if not math.isfinite(ratio) or not 0 <= ratio < 1:
        raise ValueError("Prefix cache hit ratio must be finite and in [0, 1)")
    if block_size < 1:
        raise ValueError("Prefix cache block size must be positive")
    lengths = list(map(len, prompts))
    if not lengths or min(lengths) < 1:
        raise ValueError("Prompts must be nonempty")
    fraction = Fraction(str(ratio))
    prefixes = [
        (length * fraction.numerator // (fraction.denominator * block_size))
        * block_size
        for length in lengths
    ]
    if ratio > 0:
        if min(prefixes) < block_size:
            raise ValueError(
                "A prompt is too short for the requested nonzero cached prefix"
            )
        if len({tuple(p[:block_size]) for p in prompts}) != len(prompts):
            raise ValueError(
                "First-block collision would invalidate per-request cache bounds"
            )
    return {
        "mode": "primed_prefix" if ratio > 0 else "cold",
        "target_ratio": ratio,
        "block_size": block_size,
        "prompt_lengths": lengths,
        "prefix_tokens_per_request": prefixes,
        "aligned_ratios_per_request": [
            n / length for n, length in zip(prefixes, lengths, strict=True)
        ],
        "expected_cached_tokens": sum(prefixes),
        "expected_query_tokens": sum(lengths),
        "aligned_hit_ratio": sum(prefixes) / sum(lengths),
    }


def make_prime_prompts(prompts, plan):
    # All token IDs come from the server-tokenized prompts. At the first new
    # token, diverge deliberately: even the prime's generated output cannot
    # accidentally warm the measured suffix.
    candidates = sorted({token for prompt in prompts for token in prompt[:64]})
    if len(candidates) < 2:
        raise ValueError(
            "Need two distinct valid token IDs to separate prime and measured suffixes"
        )
    priming = []
    for prompt, count in zip(prompts, plan["prefix_tokens_per_request"], strict=True):
        if count < 1 or count >= len(prompt):
            raise ValueError(
                "Priming requires a nonempty prefix and an uncached suffix"
            )
        token = next(token for token in candidates if token != prompt[count])
        priming.append(prompt[:count] + [token])
    return priming


def counter_delta(before, after, key):
    old, new = before.get(key), after.get(key)
    if not isinstance(old, (int, float)) or not isinstance(new, (int, float)):
        return None
    if not math.isfinite(old) or not math.isfinite(new) or new < old:
        return None
    return new - old


def wait_for_queries(read_metrics, before, expected, timeout=30):
    """Drain delayed engine metrics before crossing prime/measurement boundaries."""
    deadline = time.monotonic() + timeout
    while True:
        after = read_metrics()
        delta = counter_delta(before, after, QUERIES)
        if delta is None or delta >= expected or time.monotonic() >= deadline:
            return after
        time.sleep(0.25)


def validate_cache_counters(plan, before, after):
    queries = counter_delta(before, after, QUERIES)
    hits = counter_delta(before, after, HITS)
    preemptions = counter_delta(before, after, PREEMPTIONS)
    errors = []
    if queries != plan["expected_query_tokens"]:
        errors.append(
            f"Query counter delta {queries} != expected {plan['expected_query_tokens']}"
        )
    if hits != plan["expected_cached_tokens"]:
        errors.append(
            f"Hit counter delta {hits} != expected {plan['expected_cached_tokens']}"
        )
    if preemptions != 0:
        errors.append(f"Preemption counter delta must be zero, got {preemptions}")
    return {
        "verified": not errors,
        "query_tokens": queries,
        "cached_tokens": hits,
        "actual_hit_ratio": hits / queries if hits is not None and queries else None,
        "expected_cached_tokens": plan["expected_cached_tokens"],
        "expected_query_tokens": plan["expected_query_tokens"],
        "preemptions": preemptions,
        "errors": errors,
    }


def prime_cache(args, prompts, plan, cache_salt, post_json, read_metrics):
    priming = make_prime_prompts(prompts, plan)
    before = read_metrics()
    if any(key not in before for key in (QUERIES, HITS, PREEMPTIONS)):
        raise CacheValidationError(
            "Required cache/preemption metrics are missing before priming",
            {"metrics": before},
        )
    body = {
        "model": args.model,
        "prompt": priming,
        "n": 1,
        "temperature": 0,
        "seed": args.seed,
        "max_tokens": 1,
        "ignore_eos": True,
        "add_special_tokens": False,
        "stream": False,
        "return_token_ids": True,
        "request_id": "pcpcache-prime-" + cache_salt,
        "cache_salt": cache_salt,
    }
    started = time.perf_counter()
    with post_json(args.base_url, "/v1/completions", body, args.timeout) as response:
        result = json.load(response)
    elapsed = time.perf_counter() - started
    choices = result.get("choices", [])
    valid_choices = (
        len(choices) == len(priming)
        and {choice.get("index") for choice in choices} == set(range(len(priming)))
        and all(choice.get("finish_reason") == "length" for choice in choices)
    )
    usage = result.get("usage") or {}
    prime_plan = {
        "expected_query_tokens": sum(map(len, priming)),
        "expected_cached_tokens": 0,
    }
    after = wait_for_queries(
        read_metrics,
        before,
        prime_plan["expected_query_tokens"],
        args.cache_metrics_timeout,
    )
    validation = validate_cache_counters(prime_plan, before, after)
    details = {
        "request_id": body["request_id"],
        "prompt_lengths": list(map(len, priming)),
        "elapsed_s": elapsed,
        "usage": usage,
        "metrics_before": before,
        "metrics_after": after,
        "validation": validation,
    }
    if (
        not valid_choices
        or usage.get("prompt_tokens") != prime_plan["expected_query_tokens"]
        or usage.get("completion_tokens") != len(priming)
        or not validation["verified"]
    ):
        raise CacheValidationError(
            "Cache priming was incomplete, contaminated, or not verified", details
        )
    return details
