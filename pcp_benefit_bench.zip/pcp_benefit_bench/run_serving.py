"""Measure a fixed 32-request decode window on the user's running server.

Uses batched token-ID prompts and actual streamed delta token IDs. No inference
latency is inferred from the CPU attention model. Standard library only.
"""

import argparse
import bisect
import hashlib
import json
import math
import random
import statistics
import time
import urllib.error
import urllib.request
import uuid
from itertools import pairwise
from pathlib import Path

from cases import get_case, make_cases


def post_json(base, route, body, timeout=3600):
    request = urllib.request.Request(
        base.rstrip("/") + route,
        data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json"},
    )
    return urllib.request.urlopen(request, timeout=timeout)


def metrics(base):
    try:
        with urllib.request.urlopen(
            base.rstrip("/") + "/metrics", timeout=15
        ) as response:
            text = response.read().decode()
        totals = {}
        for line in text.splitlines():
            if not line or line.startswith("#"):
                continue
            name = line.split("{", 1)[0].split()[0]
            if name in (
                "vllm:num_preemptions_total",
                "vllm:prefix_cache_hits_total",
                "vllm:prefix_cache_queries_total",
            ):
                totals[name] = totals.get(name, 0.0) + float(line.split()[-1])
        return totals
    except (OSError, ValueError) as exc:
        return {"error": str(exc)}


def iter_sse(response):
    data = []
    for raw in response:
        line = raw.decode("utf-8").rstrip("\r\n")
        if not line:
            if data:
                yield "\n".join(data)
                data = []
        elif line.startswith("data:"):
            data.append(line[5:].lstrip())
    if data:
        yield "\n".join(data)


def percentile(values, quantile):
    values = sorted(values)
    index = (len(values) - 1) * quantile
    lo, hi = math.floor(index), math.ceil(index)
    return values[lo] + (values[hi] - values[lo]) * (index - lo)


def summarize(events, expected_output, warmup_tokens=64, window_tokens=256):
    """All events are (arrival time, number of delta IDs), per request."""
    times, cumulative = [], []
    for stream in events:
        if not stream:
            raise ValueError("A request returned no token IDs")
        total, values = 0, []
        for _, count in stream:
            total += count
            values.append(total)
        if total != expected_output:
            raise ValueError(
                f"Expected {expected_output} output tokens, received {total}"
            )
        times.append([t for t, _ in stream])
        cumulative.append(values)

    # Wait for ALL requests to finish prefill and emit warmup_tokens+1 tokens.
    start = max(
        t[bisect.bisect_left(c, warmup_tokens + 1)] for t, c in zip(times, cumulative)
    )
    starts = [c[bisect.bisect_right(t, start) - 1] for t, c in zip(times, cumulative)]
    targets = [n + window_tokens for n in starts]
    if any(n + 32 >= expected_output for n in targets):
        raise ValueError(
            "No full-batch steady window: increase --output-tokens or reduce context/batch"
        )
    end = max(
        t[bisect.bisect_left(c, n)] for t, c, n in zip(times, cumulative, targets)
    )
    ends = [c[bisect.bisect_right(t, end) - 1] for t, c in zip(times, cumulative)]
    if any(n + 32 >= expected_output for n in ends):
        raise ValueError("A request approaches completion inside the common window")
    duration = end - start
    if duration <= 0:
        raise ValueError("Buffered response has no measurable steady window")
    token_count = sum(b - a for a, b in zip(starts, ends))
    intervals = []
    for stream in events:
        for (previous, _), (now, count) in pairwise(stream):
            if start <= previous < now <= end:
                intervals.append((now - previous) * 1000 / count)
    return {
        "steady_start_s": start,
        "steady_end_s": end,
        "steady_duration_s": duration,
        "tokens_at_window_start": starts,
        "tokens_at_window_end": ends,
        "steady_output_tokens": token_count,
        "steady_output_tps": token_count / duration,
        "batch_equivalent_tpot_ms": len(events) * duration * 1000 / token_count,
        "chunk_amortized_gap_p50_ms": percentile(intervals, 0.5) if intervals else None,
        "chunk_amortized_gap_p95_ms": percentile(intervals, 0.95)
        if intervals
        else None,
        "single_token_chunk_fraction": sum(n == 1 for e in events for _, n in e)
        / sum(len(e) for e in events),
        "mean_ttft_s": statistics.mean(e[0][0] for e in events),
    }


def make_prompts(base, model, lengths, seed):
    # Ask this exact server's tokenizer for known-valid ordinary token IDs.
    text = "Performance benchmark. Read the following records and continue the numbered list. "
    text += " ".join(
        f"Record {i}: the quick brown fox visited city {i * 7}." for i in range(100)
    )
    with post_json(
        base, "/tokenize", {"model": model, "prompt": text, "add_special_tokens": False}
    ) as r:
        pool = json.load(r)["tokens"]
    if not pool or not all(isinstance(t, int) and t >= 0 for t in pool):
        raise ValueError("/tokenize must return integer token IDs")
    rng = random.Random(seed)
    prompts = []
    for length in lengths:
        # Different complete first blocks prevent within-wave prefix sharing.
        prefix = [rng.choice(pool) for _ in range(min(64, length))]
        offset = rng.randrange(len(pool))
        rotated = pool[offset:] + pool[:offset]
        remaining = length - len(prefix)
        prompts.append(
            prefix + (rotated * ((remaining + len(pool) - 1) // len(pool)))[:remaining]
        )
    if len({tuple(p[:32]) for p in prompts}) != len(prompts):
        raise ValueError("First-block collision; change seed")
    return prompts


def run_wave(args, case, prompts, phase, repeat):
    run_id = f"pcpbench-{case['name']}-{phase}-{repeat}-{uuid.uuid4().hex}"
    body = {
        "model": args.model,
        "prompt": prompts,
        "n": 1,
        "temperature": 0,
        "seed": args.seed,
        "max_tokens": args.output_tokens,
        "ignore_eos": True,
        "add_special_tokens": False,
        "stream": True,
        "return_token_ids": True,
        "stream_options": {"include_usage": True},
        "request_id": run_id,
        "cache_salt": run_id,
    }
    before = metrics(args.base_url)
    events, outputs = [[] for _ in prompts], [[] for _ in prompts]
    finishes, observed_prompts = {}, {}
    usage, done = None, False
    start = time.perf_counter()
    try:
        with post_json(
            args.base_url, "/v1/completions", body, args.timeout
        ) as response:
            for data in iter_sse(response):
                now = time.perf_counter() - start
                if data == "[DONE]":
                    done = True
                    break
                chunk = json.loads(data)
                if "error" in chunk:
                    raise ValueError(chunk["error"])
                if chunk.get("usage"):
                    usage = chunk["usage"]
                for choice in chunk.get("choices", []):
                    index = choice["index"]
                    if not 0 <= index < len(prompts):
                        raise ValueError(f"Unexpected choice index {index}")
                    ids = choice.get("token_ids")
                    if ids:
                        events[index].append((now, len(ids)))
                        outputs[index].extend(ids)
                    elif choice.get("text") and ids is None:
                        raise ValueError(
                            "Server omitted delta token_ids; cannot count text chunks as tokens"
                        )
                    if choice.get("prompt_token_ids") is not None:
                        observed_prompts[index] = len(choice["prompt_token_ids"])
                    if choice.get("finish_reason"):
                        finishes[index] = choice["finish_reason"]
    except urllib.error.HTTPError as exc:
        raise RuntimeError(
            f"HTTP {exc.code}: {exc.read().decode(errors='replace')}"
        ) from exc
    elapsed = time.perf_counter() - start
    after = metrics(args.base_url)
    if (
        not done
        or len(finishes) != len(prompts)
        or any(v != "length" for v in finishes.values())
    ):
        raise ValueError(
            f"Incomplete/early-stopped batch: done={done}, finishes={finishes}"
        )
    if observed_prompts != {i: len(p) for i, p in enumerate(prompts)}:
        raise ValueError("Prompt token lengths not confirmed by the server")
    if usage and (
        usage.get("prompt_tokens") != sum(map(len, prompts))
        or usage.get("completion_tokens") != len(prompts) * args.output_tokens
    ):
        raise ValueError(f"Unexpected aggregate usage: {usage}")
    result = {
        "schema": 1,
        "case": case["name"],
        "policy_label": args.policy,
        "factor_label": args.factor,
        "phase": phase,
        "repeat": repeat,
        "model": args.model,
        "pcp": case["pcp"],
        "batch_size": len(prompts),
        "request_id": run_id,
        "seed": args.seed,
        "prompt_lengths": list(map(len, prompts)),
        "prompt_sha256": hashlib.sha256(json.dumps(prompts).encode()).hexdigest(),
        "output_tokens_per_request": args.output_tokens,
        "warmup_tokens": args.warmup_tokens,
        "window_tokens": args.window_tokens,
        "events": events,
        "output_sha256": [
            hashlib.sha256(json.dumps(o).encode()).hexdigest() for o in outputs
        ],
        "e2e_s": elapsed,
        "e2e_output_tps": sum(map(len, outputs)) / elapsed,
        "metrics_before": before,
        "metrics_after": after,
        "usage": usage,
    }
    key = "vllm:num_preemptions_total"
    result["preemptions"] = (
        after[key] - before[key] if key in before and key in after else None
    )
    if phase == "measure":
        try:
            result.update(
                summarize(
                    events, args.output_tokens, args.warmup_tokens, args.window_tokens
                )
            )
            result["valid_window"] = True
        except ValueError as exc:
            result["valid_window"] = False
            result["window_error"] = str(exc)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", default="http://127.0.0.1:50001")
    parser.add_argument("--model", default="DeepSeek-V4-Flash-w8a8")
    parser.add_argument(
        "--policy",
        choices=["round_robin", "load_balance"],
        required=True,
        help="Label only; restart server with matching serve.sh policy",
    )
    parser.add_argument(
        "--factor", type=float, default=1.5, help="Label; must match the server"
    )
    parser.add_argument(
        "--case",
        choices=[c["name"] for c in make_cases()] + ["all"],
        default="hot_half_32k",
    )
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--warmup-rounds", type=int, default=1)
    parser.add_argument("--output-tokens", type=int, default=1024)
    parser.add_argument("--warmup-tokens", type=int, default=64)
    parser.add_argument("--window-tokens", type=int, default=256)
    parser.add_argument("--seed", type=int, default=20261014)
    parser.add_argument("--timeout", type=int, default=3600)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if (
        args.repeats < 1
        or args.warmup_rounds < 0
        or args.warmup_tokens < 0
        or args.window_tokens < 1
    ):
        parser.error("Invalid counts")
    if args.output_tokens <= args.warmup_tokens + args.window_tokens + 64:
        parser.error("Insufficient output budget for the common steady window")
    args.out.mkdir(parents=True, exist_ok=True)
    selected = make_cases() if args.case == "all" else [get_case(args.case)]
    for case in selected:
        if max(case["prompt_lengths"]) + args.output_tokens > 65536:
            parser.error("Prompt plus output exceeds supplied max-model-len=65536")
        prompts = make_prompts(
            args.base_url, args.model, case["prompt_lengths"], args.seed
        )
        for phase, repetitions in (
            ("warmup", args.warmup_rounds),
            ("measure", args.repeats),
        ):
            for repeat in range(repetitions):
                result = run_wave(args, case, prompts, phase, repeat)
                path = args.out / f"{result['request_id']}.json"
                path.write_text(json.dumps(result, indent=2), encoding="utf-8")
                print(
                    json.dumps(
                        {
                            k: v
                            for k, v in result.items()
                            if k
                            in (
                                "case",
                                "policy_label",
                                "phase",
                                "repeat",
                                "steady_output_tps",
                                "batch_equivalent_tpot_ms",
                                "preemptions",
                                "window_error",
                            )
                        }
                    ),
                    flush=True,
                )
                if result.get("valid_window") is False:
                    raise RuntimeError(
                        result["window_error"] + f"; raw stream saved to {path}"
                    )
                if result["preemptions"] not in (0, None):
                    raise RuntimeError(
                        "Preemption occurred; this is not a clean fixed-batch comparison"
                    )


if __name__ == "__main__":
    main()
