#!/usr/bin/env bash
set -euo pipefail

# Same deployment as supplied by the user. Only policy/factor vary in A/B.
policy="${1:-round_robin}"
factor="${2:-1.5}"
mode="${3:-perf}"
case "$policy" in round_robin|load_balance) ;; *) echo "Invalid policy" >&2; exit 2 ;; esac
case "$mode" in perf|trace) ;; *) echo "Use perf or trace" >&2; exit 2 ;; esac
bench_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
extra_args=()
if [[ "$mode" == trace ]]; then
  export PYTHONPATH="$bench_dir${PYTHONPATH:+:$PYTHONPATH}"
  extra_args+=(--worker-extension-cls pcp_trace.TraceExtension)
fi
additional_config="$(python -c 'import json,math,sys; f=float(sys.argv[2]); assert math.isfinite(f) and f>=1; print(json.dumps({"ascend_compilation_config":{"enable_npugraph_ex":True,"enable_static_kernel":False},"enable_cpu_binding":True,"enable_flashcomm1":True,"enable_dsa_cp":False,"multistream_overlap_shared_expert":True,"enable_pcp_decode_sharding":True,"pcp_decode_balance_policy":sys.argv[1],"pcp_decode_balance_token_factor":f}))' "$policy" "$factor")"
printf 'policy=%s factor=%s mode=%s\n' "$policy" "$factor" "$mode"
VLLM_USE_V2_MODEL_RUNNER=1 vllm serve /mnt/weight/DeepSeek-V4-Flash-0731-w8a8 \
  --max-model-len 65536 --block-size 32 --max-num-batched-tokens 8192 \
  --served-model-name DeepSeek-V4-Flash-w8a8 --max-num-seqs 32 \
  --data-parallel-size 1 --pipeline-parallel-size 1 --tensor-parallel-size 1 \
  --prefill-context-parallel-size 16 --decode-context-parallel-size 1 \
  --gpu-memory-utilization 0.9 --api-server-count 1 \
  --enable-prefix-caching --enable-chunked-prefill --enable-expert-parallel \
  --tokenizer-mode deepseek_v4 --tool-call-parser deepseek_v4 \
  --enable-auto-tool-choice --reasoning-parser deepseek_v4 \
  --model-loader-extra-config '{"enable_multithread_load": true, "num_threads": 128}' \
  --quantization ascend --attention-config '{"indexer_kv_dtype": "int8"}' \
  --host 0.0.0.0 --port 50001 \
  --compilation-config '{"cudagraph_mode": "FULL_DECODE_ONLY"}' \
  --async-scheduling --additional-config "$additional_config" "${extra_args[@]}"
