"""CPU tests of workload construction, streaming accounting and comparison."""

import ast
import copy
import functools
import io
import itertools
import json
import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from cases import get_case, make_cases
from compare import compare
from inspect_trace import (
    assignment_status,
    group_snapshots,
    print_details,
    verify_snapshot,
)
from run_serving import iter_sse, run_wave, summarize


def result(policy="round_robin"):
    return {
        "phase": "measure",
        "case": "test",
        "model": "model",
        "pcp": 16,
        "batch_size": 32,
        "prompt_sha256": "same",
        "seed": 1,
        "output_tokens_per_request": 1024,
        "warmup_tokens": 64,
        "window_tokens": 256,
        "factor_label": 1.5,
        "preemptions": 0,
        "request_id": policy,
        "policy_label": policy,
        "steady_output_tps": 100 if policy == "round_robin" else 120,
        "batch_equivalent_tpot_ms": 320 if policy == "round_robin" else 320 / 1.2,
        "output_sha256": ["same"],
    }


class BenchTests(unittest.TestCase):
    def test_primary_lengths_align_with_rank_collisions(self):
        for name in (f"hot_half_{k}k" for k in (8, 16, 32, 48, 60)):
            case = get_case(name)
            lengths = case["prompt_lengths"]
            self.assertEqual(len(lengths), 32)
            for rank in range(16):
                self.assertEqual(lengths[rank], lengths[rank + 16])
                self.assertEqual(lengths[rank] > 512, rank < 8)

    def test_length_sweep_fits_with_2048_output_tokens(self):
        for k in (8, 16, 32, 48, 60):
            lengths = get_case(f"hot_half_{k}k")["prompt_lengths"]
            self.assertEqual(lengths.count(k * 1024), 16)
            self.assertEqual(lengths.count(512), 16)
            self.assertLessEqual(max(lengths) + 2048, 65536)

    def test_controls_preserve_length_multiset(self):
        target = sorted(get_case("hot_half_32k")["prompt_lengths"])
        for name in ("balanced_order_32k", "shuffled_32k"):
            self.assertEqual(sorted(get_case(name)["prompt_lengths"]), target)
        self.assertEqual(make_cases(), make_cases())

    def test_negative_control(self):
        self.assertEqual(set(get_case("uniform_8k")["prompt_lengths"]), {8192})

    def test_sse_multiline_and_comments(self):
        wire = io.BytesIO(
            b': keepalive\r\ndata: {"x":\r\ndata: 1}\r\n\r\ndata: [DONE]\n\n'
        )
        events = list(iter_sse(wire))
        self.assertEqual(json.loads(events[0]), {"x": 1})
        self.assertEqual(events[1], "[DONE]")

    def test_common_window_excludes_all_prefills(self):
        streams = [[(i + delay, 1) for i in range(500)] for delay in (0, 10)]
        stats = summarize(streams, 500, 4, 50)
        self.assertEqual(stats["steady_start_s"], 14)
        self.assertEqual(stats["tokens_at_window_start"], [15, 5])
        self.assertEqual(stats["steady_output_tokens"], 100)
        self.assertEqual(stats["steady_output_tps"], 2)
        self.assertEqual(stats["batch_equivalent_tpot_ms"], 1000)

    def test_delta_tokens_not_chunk_count(self):
        streams = [[(i, 4) for i in range(200)] for _ in range(2)]
        stats = summarize(streams, 800, 4, 80)
        self.assertEqual(stats["steady_output_tps"], 8)
        self.assertEqual(stats["single_token_chunk_fraction"], 0)

    def test_reject_shrinking_batch(self):
        streams = [[(i + delay, 1) for i in range(200)] for delay in (0, 120)]
        with self.assertRaisesRegex(ValueError, "window"):
            summarize(streams, 200, 4, 80)

    def test_reject_truncated_tokens(self):
        with self.assertRaisesRegex(ValueError, "Expected"):
            summarize([[(0, 1)]], 100)

    def test_compare_signed_gain(self):
        rows = [result(), result("load_balance")]
        self.assertAlmostEqual(compare(rows)[0]["throughput_gain_pct"], 20)
        rows[1]["steady_output_tps"] = 80
        self.assertAlmostEqual(compare(rows)[0]["throughput_gain_pct"], -20)

    def test_compare_rejects_input_mismatch(self):
        rows = [result(), result("load_balance")]
        rows[1]["prompt_sha256"] = "different"
        with self.assertRaisesRegex(ValueError, "mismatch"):
            compare(rows)

    def test_compare_rejects_preemption_or_missing_metrics(self):
        for value in (1, None):
            rows = [result(), result("load_balance")]
            rows[1]["preemptions"] = value
            with self.assertRaises(ValueError):
                compare(rows)
        rows[1]["preemptions"] = None
        self.assertFalse(compare(rows, True)[0]["preemption_metrics_verified"])

    def test_full_client_streaming_path_with_fake_server(self):
        prompts = [[10 + i] * 8 for i in range(32)]
        wire = []
        for token in range(160):
            choices = []
            for index in range(32):
                choice = {"index": index, "token_ids": [token], "text": "x"}
                if token == 0:
                    choice["prompt_token_ids"] = prompts[index]
                if token == 159:
                    choice["finish_reason"] = "length"
                choices.append(choice)
            wire.append("data: " + json.dumps({"choices": choices}) + "\n\n")
        wire.extend(
            [
                'data: {"choices":[],"usage":{"prompt_tokens":256,"completion_tokens":5120}}\n\n',
                "data: [DONE]\n\n",
            ]
        )
        args = SimpleNamespace(
            model="test",
            seed=1,
            output_tokens=160,
            base_url="unused",
            timeout=1,
            policy="round_robin",
            factor=1.5,
            warmup_tokens=4,
            window_tokens=32,
        )
        with (
            patch(
                "run_serving.post_json", return_value=io.BytesIO("".join(wire).encode())
            ),
            patch(
                "run_serving.metrics", return_value={"vllm:num_preemptions_total": 0}
            ),
            patch("run_serving.time.perf_counter", side_effect=itertools.count()),
        ):
            output = run_wave(args, {"name": "test", "pcp": 16}, prompts, "measure", 0)
        self.assertEqual(output["steady_output_tps"], 32)
        self.assertEqual(output["preemptions"], 0)
        self.assertEqual(output["steady_output_tokens"], 1024)
        self.assertEqual(len(output["output_sha256"]), 32)

    def test_trace_extension_preserves_partition_and_ignores_dummies(self):
        # Load just the actual installer, with no vLLM import or device dependency.
        source = Path(__file__).with_name("pcp_trace.py")
        tree = ast.parse(source.read_text(encoding="utf-8"))
        node = next(
            n
            for n in tree.body
            if isinstance(n, ast.FunctionDef) and n.name == "install"
        )
        namespace = {"functools": functools, "json": json, "os": os, "Path": Path}
        exec(  # noqa: S102 -- Execute the local diagnostic installer in isolation.
            compile(ast.Module(body=[node], type_ignores=[]), str(source), "exec"),
            namespace,
        )

        class Manager:
            pcp_rank, pcp_world_size, is_decode_sharded = 0, 16, True
            decode_balance_policy, decode_balance_token_factor = "round_robin", 1.5
            _decode_partition_plan = None

            def partition_batch(
                self, batch, padded_num_tokens=None, padded_num_reqs=None
            ):
                owners = (
                    self._decode_partition_plan.owner_ranks
                    if self._decode_partition_plan is not None
                    else [i % self.pcp_world_size for i in range(len(batch.req_ids))]
                )
                indices = [
                    i for i, owner in enumerate(owners) if owner == self.pcp_rank
                ]
                self.last_partition = SimpleNamespace(
                    req_ids=[batch.req_ids[i] for i in indices],
                    num_computed_tokens_np=[
                        batch.num_computed_tokens_np[i] for i in indices
                    ],
                    num_scheduled_tokens=[
                        batch.num_scheduled_tokens[i] for i in indices
                    ],
                    num_tokens=len(indices),
                    num_tokens_after_padding=padded_num_tokens,
                    num_reqs_after_padding=padded_num_reqs,
                )
                self._decode_partition_plan = None
                return self.last_partition

        namespace["install"](Manager)
        wrapper = Manager.partition_batch
        namespace["install"](Manager)
        self.assertIs(wrapper, Manager.partition_batch)
        manager = Manager()
        batch = SimpleNamespace(
            req_ids=[f"dummy-{i}" for i in range(32)],
            is_prefilling_np=SimpleNamespace(any=lambda: False),
            num_scheduled_tokens=[1] * 32,
            num_computed_tokens_np=get_case("hot_half_32k")["prompt_lengths"],
        )
        with (
            tempfile.TemporaryDirectory() as folder,
            patch.object(Path, "cwd", return_value=Path(folder)),
        ):
            self.assertIs(manager.partition_batch(batch, 2, 2), manager.last_partition)
            self.assertEqual(list(Path(folder).iterdir()), [])
            batch.req_ids = [f"pcpbench-test-{i}" for i in range(32)]
            for policy in ("round_robin", "load_balance"):
                for rank in range(16):
                    manager = Manager()
                    manager.pcp_rank = rank
                    manager.decode_balance_policy = policy
                    if policy == "load_balance":
                        manager._decode_partition_plan = SimpleNamespace(
                            owner_ranks=list(range(16))
                            + [(i + 8) % 16 for i in range(16)]
                        )
                    self.assertIs(
                        manager.partition_batch(batch, 2, 2), manager.last_partition
                    )
                    self.assertIsNone(manager._decode_partition_plan)
            records = [
                json.loads(line)
                for path in (Path(folder) / "pcp_trace").glob("*.jsonl")
                for line in path.read_text().splitlines()
            ]
            groups = group_snapshots(records)
            self.assertEqual(len(groups), 2)
            for rows in groups:
                self.assertTrue(verify_snapshot(rows)["verified"])
                for record in rows:
                    expected_cost = (
                        65538 if record["policy"] == "round_robin" else 33282
                    )
                    self.assertEqual(max(record["actual"]["attention"]), expected_cost)
                    self.assertEqual(record["mode"], "FULL")
                    self.assertEqual(record["actual"]["rows"], [2] * 16)
                    self.assertTrue(record["local_matches_assignment"])
                    self.assertEqual(
                        record["has_plan"], record["policy"] == "load_balance"
                    )


def placement_records():
    base = {
        "policy": "load_balance",
        "factor": 1.5,
        "pcp": 2,
        "request_ids": ["pcpbench-long", "pcpbench-short"],
        "contexts": [32768, 512],
        "scheduled_tokens": [1, 1],
        "owners": [0, 1],
        "has_plan": True,
        "decode_step_in_trace": 1,
        "padded_num_tokens": 1,
        "padded_num_reqs": 1,
    }
    return [
        {
            **base,
            "pcp_rank": rank,
            "local_partition": {
                "requests": [{"request_id": base["request_ids"][rank], "c": c, "q": 1}],
                "num_tokens": 1,
            },
        }
        for rank, c in enumerate(base["contexts"])
    ]


class PlacementTests(unittest.TestCase):
    def test_rr_plan_is_retained_even_when_has_plan_is_true(self):
        row = placement_records()[0]
        decision = assignment_status(row)
        self.assertEqual(decision["assignment_status"], "rr_retained")
        self.assertTrue(decision["fallback_to_round_robin"])
        self.assertEqual(decision["moved_request_count"], 0)
        self.assertEqual(decision["fallback_reason"], "not_recorded")

    def test_no_plan_is_not_labeled_as_planner_fallback(self):
        row = placement_records()[0]
        row["has_plan"] = False
        decision = assignment_status(row)
        self.assertEqual(decision["assignment_status"], "rr_no_plan")
        self.assertIsNone(decision["fallback_to_round_robin"])
        row["policy"] = "round_robin"
        self.assertEqual(assignment_status(row)["assignment_status"], "rr_configured")
        self.assertFalse(assignment_status(row)["fallback_to_round_robin"])

    def test_owner_changes_are_detected_even_if_rank_counts_are_identical(self):
        row = placement_records()[0]
        row["owners"] = [1, 0]
        decision = assignment_status(row)
        self.assertEqual(decision["assignment_status"], "lb_applied")
        self.assertEqual(decision["moved_request_count"], 2)
        self.assertFalse(decision["fallback_to_round_robin"])

    def test_inconsistent_owners_are_not_called_fallback(self):
        row = placement_records()[0]
        row["owners"] = [1, 0]
        row["has_plan"] = False
        self.assertEqual(
            assignment_status(row)["assignment_status"], "inconsistent_trace"
        )
        row["owners"] = [0]
        with self.assertRaisesRegex(ValueError, "Owner count"):
            assignment_status(row)

    def test_all_rank_observation_is_required(self):
        rows = placement_records()
        self.assertTrue(verify_snapshot(rows)["verified"])
        self.assertEqual(verify_snapshot(rows[:1])["missing_ranks"], [1])
        self.assertFalse(verify_snapshot(rows[:1])["verified"])
        self.assertFalse(verify_snapshot(rows + rows[:1])["verified"])

    def test_incorrect_actual_partition_is_not_hidden_by_owner_plan(self):
        rows = placement_records()
        rows[1]["local_partition"] = copy.deepcopy(rows[0]["local_partition"])
        check = verify_snapshot(rows)
        self.assertTrue(check["complete"])
        self.assertFalse(check["placements_match"])
        self.assertFalse(check["verified"])

    def test_context_and_token_count_mismatch(self):
        for field in ("context", "tokens"):
            rows = placement_records()
            local = rows[1]["local_partition"]
            if field == "context":
                local["requests"][0]["c"] += 1
            else:
                local["num_tokens"] += 1
            self.assertFalse(verify_snapshot(rows)["verified"])

    def test_owners_must_agree_across_ranks(self):
        rows = placement_records()
        rows[1]["owners"] = [1, 0]
        self.assertFalse(verify_snapshot(rows)["verified"])

    def test_distinct_contexts_and_runs_are_never_merged(self):
        rows = placement_records()
        self.assertEqual(len(group_snapshots(rows)), 1)
        changed = copy.deepcopy(rows[1])
        changed["contexts"][0] += 1
        self.assertEqual(len(group_snapshots(rows[:1] + [changed])), 2)
        changed = copy.deepcopy(rows[1])
        changed["request_ids"][0] = "pcpbench-other-run"
        self.assertEqual(len(group_snapshots(rows[:1] + [changed])), 2)

    def test_legacy_details_are_labeled_as_unverified(self):
        row = placement_records()[0]
        del row["local_partition"]
        del row["pcp_rank"]
        del row["scheduled_tokens"]
        check = verify_snapshot([row])
        self.assertTrue(check["legacy_plan_only"])
        self.assertFalse(check["verified"])
        with patch("sys.stdout", new_callable=io.StringIO) as output:
            print_details([row])
        self.assertIn("plan_or_round_robin_only", output.getvalue())
        self.assertIn("c=32768 q=1 seq_len=32769", output.getvalue())

    def test_details_use_returned_partition(self):
        rows = placement_records()
        with patch("sys.stdout", new_callable=io.StringIO) as output:
            print_details(rows)
        self.assertIn("all_ranks_verified=True", output.getvalue())
        self.assertIn("source=partition_return", output.getvalue())


if __name__ == "__main__":
    unittest.main()
