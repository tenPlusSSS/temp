"""CPU tests of workload construction, streaming accounting and comparison."""

import ast
import functools
import io
import itertools
import json
import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from cases import get_case, make_cases
from compare import compare
from run_serving import iter_sse, run_wave, summarize


def result(policy="round_robin"):
    return {
        "phase": "measure",
        "case": "test",
        "model": "model",
        "pcp": 16,
        "batch_size": 32,
        "prompt_sha256": "same",
        "seed": 1,
        "output_tokens_per_request": 1024,
        "warmup_tokens": 64,
        "window_tokens": 256,
        "factor_label": 1.5,
        "preemptions": 0,
        "request_id": policy,
        "policy_label": policy,
        "steady_output_tps": 100 if policy == "round_robin" else 120,
        "batch_equivalent_tpot_ms": 320 if policy == "round_robin" else 320 / 1.2,
        "output_sha256": ["same"],
    }


class BenchTests(unittest.TestCase):
    def test_primary_lengths_align_with_rank_collisions(self):
        for name in ("hot_half_16k", "hot_half_32k"):
            case = get_case(name)
            lengths = case["prompt_lengths"]
            self.assertEqual(len(lengths), 32)
            for rank in range(16):
                self.assertEqual(lengths[rank], lengths[rank + 16])
                self.assertEqual(lengths[rank] > 512, rank < 8)

    def test_controls_preserve_length_multiset(self):
        target = sorted(get_case("hot_half_32k")["prompt_lengths"])
        for name in ("balanced_order_32k", "shuffled_32k"):
            self.assertEqual(sorted(get_case(name)["prompt_lengths"]), target)
        self.assertEqual(make_cases(), make_cases())

    def test_negative_control(self):
        self.assertEqual(set(get_case("uniform_8k")["prompt_lengths"]), {8192})

    def test_sse_multiline_and_comments(self):
        wire = io.BytesIO(
            b': keepalive\r\ndata: {"x":\r\ndata: 1}\r\n\r\ndata: [DONE]\n\n'
        )
        events = list(iter_sse(wire))
        self.assertEqual(json.loads(events[0]), {"x": 1})
        self.assertEqual(events[1], "[DONE]")

    def test_common_window_excludes_all_prefills(self):
        streams = [[(i + delay, 1) for i in range(500)] for delay in (0, 10)]
        stats = summarize(streams, 500, 4, 50)
        self.assertEqual(stats["steady_start_s"], 14)
        self.assertEqual(stats["tokens_at_window_start"], [15, 5])
        self.assertEqual(stats["steady_output_tokens"], 100)
        self.assertEqual(stats["steady_output_tps"], 2)
        self.assertEqual(stats["batch_equivalent_tpot_ms"], 1000)

    def test_delta_tokens_not_chunk_count(self):
        streams = [[(i, 4) for i in range(200)] for _ in range(2)]
        stats = summarize(streams, 800, 4, 80)
        self.assertEqual(stats["steady_output_tps"], 8)
        self.assertEqual(stats["single_token_chunk_fraction"], 0)

    def test_reject_shrinking_batch(self):
        streams = [[(i + delay, 1) for i in range(200)] for delay in (0, 120)]
        with self.assertRaisesRegex(ValueError, "window"):
            summarize(streams, 200, 4, 80)

    def test_reject_truncated_tokens(self):
        with self.assertRaisesRegex(ValueError, "Expected"):
            summarize([[(0, 1)]], 100)

    def test_compare_signed_gain(self):
        rows = [result(), result("load_balance")]
        self.assertAlmostEqual(compare(rows)[0]["throughput_gain_pct"], 20)
        rows[1]["steady_output_tps"] = 80
        self.assertAlmostEqual(compare(rows)[0]["throughput_gain_pct"], -20)

    def test_compare_rejects_input_mismatch(self):
        rows = [result(), result("load_balance")]
        rows[1]["prompt_sha256"] = "different"
        with self.assertRaisesRegex(ValueError, "mismatch"):
            compare(rows)

    def test_compare_rejects_preemption_or_missing_metrics(self):
        for value in (1, None):
            rows = [result(), result("load_balance")]
            rows[1]["preemptions"] = value
            with self.assertRaises(ValueError):
                compare(rows)
        rows[1]["preemptions"] = None
        self.assertFalse(compare(rows, True)[0]["preemption_metrics_verified"])

    def test_full_client_streaming_path_with_fake_server(self):
        prompts = [[10 + i] * 8 for i in range(32)]
        wire = []
        for token in range(160):
            choices = []
            for index in range(32):
                choice = {"index": index, "token_ids": [token], "text": "x"}
                if token == 0:
                    choice["prompt_token_ids"] = prompts[index]
                if token == 159:
                    choice["finish_reason"] = "length"
                choices.append(choice)
            wire.append("data: " + json.dumps({"choices": choices}) + "\n\n")
        wire.extend(
            [
                'data: {"choices":[],"usage":{"prompt_tokens":256,"completion_tokens":5120}}\n\n',
                "data: [DONE]\n\n",
            ]
        )
        args = SimpleNamespace(
            model="test",
            seed=1,
            output_tokens=160,
            base_url="unused",
            timeout=1,
            policy="round_robin",
            factor=1.5,
            warmup_tokens=4,
            window_tokens=32,
        )
        with (
            patch(
                "run_serving.post_json", return_value=io.BytesIO("".join(wire).encode())
            ),
            patch(
                "run_serving.metrics", return_value={"vllm:num_preemptions_total": 0}
            ),
            patch("run_serving.time.perf_counter", side_effect=itertools.count()),
        ):
            output = run_wave(args, {"name": "test", "pcp": 16}, prompts, "measure", 0)
        self.assertEqual(output["steady_output_tps"], 32)
        self.assertEqual(output["preemptions"], 0)
        self.assertEqual(output["steady_output_tokens"], 1024)
        self.assertEqual(len(output["output_sha256"]), 32)

    def test_trace_extension_preserves_partition_and_ignores_dummies(self):
        # Load just the actual installer, with no vLLM import or device dependency.
        source = Path(__file__).with_name("pcp_trace.py")
        tree = ast.parse(source.read_text(encoding="utf-8"))
        node = next(
            n
            for n in tree.body
            if isinstance(n, ast.FunctionDef) and n.name == "install"
        )
        namespace = {"functools": functools, "json": json, "os": os, "Path": Path}
        exec(  # noqa: S102 -- Execute the local diagnostic installer in isolation.
            compile(ast.Module(body=[node], type_ignores=[]), str(source), "exec"),
            namespace,
        )

        class Manager:
            pcp_rank, pcp_world_size, is_decode_sharded = 0, 16, True
            decode_balance_policy, decode_balance_token_factor = "round_robin", 1.5
            _decode_partition_plan = None

            def partition_batch(
                self, batch, padded_num_tokens=None, padded_num_reqs=None
            ):
                return batch, padded_num_tokens, padded_num_reqs

        namespace["install"](Manager)
        wrapper = Manager.partition_batch
        namespace["install"](Manager)
        self.assertIs(wrapper, Manager.partition_batch)
        manager = Manager()
        batch = SimpleNamespace(
            req_ids=[f"dummy-{i}" for i in range(32)],
            is_prefilling_np=SimpleNamespace(any=lambda: False),
            num_scheduled_tokens=[1] * 32,
            num_computed_tokens_np=get_case("hot_half_32k")["prompt_lengths"],
        )
        with (
            tempfile.TemporaryDirectory() as folder,
            patch.object(Path, "cwd", return_value=Path(folder)),
        ):
            self.assertEqual(manager.partition_batch(batch, 2, 2), (batch, 2, 2))
            self.assertEqual(list(Path(folder).iterdir()), [])
            batch.req_ids = [f"pcpbench-test-{i}" for i in range(32)]
            manager.partition_batch(batch, 2, 2)
            record = json.loads(
                next((Path(folder) / "pcp_trace").glob("*.jsonl")).read_text()
            )
            self.assertEqual(max(record["actual"]["attention"]), 65538)
            self.assertEqual(record["mode"], "FULL")
            self.assertEqual(record["actual"]["rows"], [2] * 16)
            manager.decode_balance_policy = "load_balance"
            manager._decode_partition_plan = SimpleNamespace(
                owner_ranks=list(range(16)) * 2
            )
            manager._pcp_bench_trace_state["steps"] = 32
            manager.partition_batch(batch, 2, 2)
            lines = (
                next((Path(folder) / "pcp_trace").glob("*.jsonl"))
                .read_text()
                .splitlines()
            )
            self.assertTrue(json.loads(lines[-1])["has_plan"])


if __name__ == "__main__":
    unittest.main()
