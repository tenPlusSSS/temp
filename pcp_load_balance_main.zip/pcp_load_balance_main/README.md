# PCP decode load_balance 主干迁移包

本包包含生产补丁、10 个修改后的完整源码文件、验证记录，以及独立的主干版 prefix90 测试工具。
旧 PR checkout 和旧测试包保持原状。本次没有创建远端 PR，也没有推送 GitHub。

## 1. 版本

- vllm-ascend 基线：`a1df499e0762621c2b9561e2ee66c498a70d0328`。
- 主干配套 vLLM：`ba15685ab7f4f5fbed8630bbb7441f8837e76fbe`。
- 基线另记录 release pin `v0.33.0`；本次源码核对以配套 main 为准，release 组合仍需实际验证。
- 本地分支：`codex/pcp-load-balance-main`，修改保存在工作区，补丁包含全部修改。

这是针对上述固定 main 快照的迁移，不是对任意后续 main 提交的兼容承诺。
不要将此补丁叠加到旧 `#17803` 版修改之上。

## 2. 行为

```json
{
  "pcp_decode_balance_policy": "load_balance",
  "pcp_decode_balance_token_factor": 1.5
}
```

将这两个字段合并进现有 `--additional-config`；默认策略仍为 `round_robin`。
主干不再接受旧启动参数中的 `enable_pcp_decode_sharding` 和 `enable_dsa_cp`，测试脚本已移除它们。

- 目标：最小化各 rank 的最大 decode attention 代理工作量。单请求 cost 为 `q*c + q*(q+1)/2`。
- `q` 是本步 query token 数，`c` 来自 scheduler 的 CPU computed-token 元数据。
- 不再对 token 数和 attention cost 加权。request 数由真实 row/buffer/block-table 容量约束。
- 候选分配的每 rank 总 token 上限为 `min(buffer_capacity, ceil(1.5*总调度token数/PCP数))`，包括固定 prefill chunk 占用。
- Prefill 只预留容量，不加入目标函数；保持主干的 PCP 分块方式。
- 候选分配不满足预算，或最大 cost 没有严格下降，则保留轮询。这个轮询回退可以超过平均预算，但不能超过物理容量。
- 一次预规划同时产生 token 和 request 最大值；dispatch、DP 协商和 partition 消费同一计划。
- 校验最终图描述符，容量不足或计划结构变化时报错，避免 dispatch 后私自换分配。
- 上下文 cost 估计不读取 NPU tensor，不调用 `.item()`/`.cpu()`、设备事件等待或新 collective。
- 投机推理的拒绝校正仍按主干时序执行。校正后的实际长度用于 positions/attention，不能用 cost 的快照替代。
- 保留主干 target/draft 局部批次、采样和恢复流程。PP+投机保守保留轮询；启用 adaptive verification 的步骤不规划。
- 只有主干共享策略认定 decode 可分片时才启用 LB；PCP=1、DCP>1、KPool 等不满足该策略的路径不会被强制改写。

上下文 cost 下降不代表 NPU 吞吐一定提升；更大的图桶、CPU 规划、通信及其他算子可能抵消收益。
此前用户报告的旧版 32K ABBA 无可测收益，不能视为此次主干迁移已验证，也不能宣称本次已加速。

## 3. 修改文件

| 文件 | 作用 |
| --- | --- |
| `vllm_ascend/worker/v2/pcp_manager.py` | 预规划、分配、容量校验、消费计划和异常清理 |
| `vllm_ascend/worker/v2/model_runner.py` | CPU scheduler 元数据入口、计划生命周期、全局/局部输入维度 |
| `vllm_ascend/patch/worker/patch_model_runner.py` | token/request 两维接入 dispatch，校验最终 DP/graph 结果 |
| `vllm_ascend/ascend_config.py` | 独立策略配置及有限数值范围校验 |
| `vllm_ascend/patch/__init__.py` | patch 原因及未来移除条件 |
| `docs/source/user_guide/configuration/additional_config.md` | 配置和行为文档 |
| `tests/ut/worker/test_pcp_decode_balance.py` | 25 项规划、配置、runner/dispatch 回归检查 |
| `tests/ut/worker/test_pcp_manager_v2.py` | 真实父类分区/恢复、q=1/4、eager/FULL、KPool 排除 |
| `tests/ut/worker/test_model_runner_v2.py` | 配置传递、全局数组与局部图 rows 的区分 |
| `tests/e2e/pull_request/four_card/context_parallel/test_accuracy_v2.py` | 普通 decode 和 MTP 图执行用例覆盖两种策略 |

## 4. 服务器安装

先准备与固定 main 基线兼容的 vLLM、CANN、torch_npu 环境。不要直接覆盖仍在使用的旧测试环境。
以下操作在独立源码目录中执行，`BUNDLE` 替换为本迁移包的绝对路径：

```bash
BUNDLE=/absolute/path/to/pcp_load_balance_main
git clone https://github.com/vllm-project/vllm-ascend.git vllm-ascend-main-lb
cd vllm-ascend-main-lb
git checkout -b pcp-load-balance a1df499e0762621c2b9561e2ee66c498a70d0328
git apply --check "$BUNDLE/pcp_load_balance_main.patch"
git apply "$BUNDLE/pcp_load_balance_main.patch"
git diff --check
# 使用已经按基线安装好配套依赖的测试环境，构建此源码。
python -m pip install -e . --no-build-isolation
```

`source/` 是修改文件的完整内容备份，不是完整仓库。优先应用补丁，不要把这几个文件覆盖到其他版本上。

## 5. 验证

本机完成的隔离 CPU 检查不等于完整仓库 UT：它从实际源码抽取方法，设备分区、上游 dispatch 和外层 runtime 使用替身。
具体结果和限制见 `VALIDATION.md` 和 `validation/` 日志。

可以用 NumPy、Pydantic 运行相同的隔离检查：

```bash
python "$BUNDLE/validation/validate_main_balance.py" --repo "$PWD"
```

有完整依赖后运行真实仓库测试：

```bash
pytest -q tests/ut/worker/test_pcp_decode_balance.py \
  tests/ut/worker/test_pcp_manager_v2.py \
  tests/ut/worker/test_model_runner_v2.py tests/ut/test_ascend_config.py
bash format.sh ci
```

在匹配测试模型和硬件的四卡环境执行新增的 E2E 参数组合：

```bash
pytest -sv tests/e2e/pull_request/four_card/context_parallel/test_accuracy_v2.py \
  -k 'dsv3_2_sfa_pcp_model_runner_v2_graph or mtp_mla_spec_decode_with_pcp'
```

这两组 E2E 只覆盖相应模型及模式。Eagle3、DSpark、DFlash、DP>1、PP 组合，以及实际部署的 DeepSeek V4 PCP=16，仍需对应环境的回归。
对于实际部署，先进入 `pcp_main_benefit_bench/`，按 `SERVER_AGENT_RUNBOOK.md` 做诊断，再独立重启服务做 ABBA。
所有 9 个用例保留约 90% 前缀缓存目标；32-token 对齐使 512-token 短请求的目标为 87.5%。
trace 包装已适配 `partition_batch(input_batch, batch_desc)`，不能混用旧版本的 trace 文件。

## 6. 提交 PR 前

本次尚无 PR 编号，附有 `release_note.draft.txt`。创建 PR 后按仓库规则填入真实编号，
放到 `release_notes/fragments/<PR编号>.yaml` 并随该 PR 提交。没有虚构 PR 编号。
提交前完成上述完整依赖/设备检查并记录结果；当前包不包含硬件通过或性能提升的声明。
