# Validation — 2026-11-16

## Completed locally

- 25 isolated CPU metadata tests passed, including 120 seeded mixed batches.
  Tests extract the actual planner, dispatch wrapper and selected runner methods;
  upstream device partitioning/dispatch and surrounding runtime are stubbed.
  Pydantic checks cover the exact new configuration fields plus the required
  sparse_kv_offload_config field, not the full configuration's side effects.
- 35 benchmark CPU tests passed after adapting the trace wrapper to batch_desc.
  The first run hit Windows sandbox TEMP permissions; using a workspace TEMP
  directory resolved this environmental failure.
- 54 cost-model cases regenerated from the migrated source. No device timings.
- Ruff checks/format checks passed for the changed production/test Python files;
  benchmark Python lint and source parsing passed.
- git diff --check passed. The exported patch passed git apply --check on clean
  base files, was applied, and all 10 outputs matched the packaged source files.

## Not completed in this environment

- Real repository pytest: unavailable modules: pytest, torch, torch_npu, vllm, pre_commit.
- The new tests invoking actual upstream tensor partition/restore, and the
  prepare_inputs/configuration integration tests, are written but not executed here.
- Four-card E2E, DeepSeek V4 PCP=16, real target/draft execution, device-sync
  profiling, graph replay, HCCL and throughput measurements remain unrun.
- bash format.sh ci was attempted but Git Bash failed at Windows sandbox startup;
  pre_commit is also not installed. Ruff checks do not replace the complete CI hooks.
- This uses the available Ruff version recorded in environment.json; repository
  pre-commit pins its own version. Run the repository hooks on the server before a PR.
- Main scheduler/PCP APIs were checked at the pinned commits. No blanket claim of
  compatibility with arbitrary later main or every supported speculative method.

The source adds no device reads/event waits/collectives to planning. This is a
code-path observation backed by CPU mocks, not measured proof of end-to-end speed.
See README.md for server commands and the draft release note needed when a PR
number becomes available. Logs are under validation/.
