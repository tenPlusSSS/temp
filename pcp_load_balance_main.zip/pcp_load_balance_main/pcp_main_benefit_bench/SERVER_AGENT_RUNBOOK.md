# 服务器端 agent 执行说明

本目录是 **main 适配版**，与旧测试包分开放置，保留每请求约 90% 输入 token 命中前缀缓存的全部用例。
要求 vllm-ascend 基线 `a1df499e0762621c2b9561e2ee66c498a70d0328` 加本次 LB 补丁；
配套 vLLM 基线为 `ba15685ab7f4f5fbed8630bbb7441f8837e76fbe`。
`pcp_trace.py` 已改用 `partition_batch(input_batch, batch_desc)`，不能直接用于旧 PR 版本；
`serve.sh` 已移除主干不接受的 `enable_pcp_decode_sharding` 和 `enable_dsa_cp`。
先按迁移包根目录的 `README.md` 安装并验证生产补丁，再执行本目录的诊断与 ABBA。
主干共享策略若判定模型不支持 decode 分片，则 LB 不生效，不能绕过该限制硬开。
服务接口、算子、图执行和性能仍需在服务器验证，本地 CPU 测试不代表这些验证已通过。


## 目标与范围

在当前已安装的 PCP decode load_balance 修改上完成两个检查：

1. 从每个 rank 返回的本地批次确认实际请求放置，并区分 LB 生效、保留轮询和没有 plan。
2. 所有用例按每请求约 90% 输入 token 命中前缀缓存构造并核验，保持其他配置一致，用 32K、48K、60K 长上下文的固定 batch 对照，检验是否存在可测吞吐收益。

用户已有冷缓存 32K ABBA 报告显示无可测收益。应保留该结果，客观记录本次的正、零或负收益。新版本改变了缓存条件，不能将旧冷缓存 RR 与本次预热缓存 LB 配成 A/B。代理 attention cost 的下降不能替代设备耗时或吞吐收益。

所有 9 个用例共用新的默认参数：`--prefix-cache-hit-ratio 0.9 --prefix-cache-block-size 32`。每请求预热的前缀长度为 `floor(0.9 × 输入长度 / 32) × 32`，原输入长度和输出预算不变。512-token 请求实际目标为 448/512=87.5%；8K、16K、32K、48K、60K 的目标分别为 89.8438%、89.8438%、89.9414%、89.9740%、90%。报告必须保留这些对齐差异。

本包仅包含测试工具，不包含生产代码补丁。不要为了执行测试而重置、升级、拉取或覆盖服务器现有 vLLM/vllm-ascend。先确认实际加载的是按迁移包说明安装、含 `pcp_decode_balance_policy` 和 `pcp_decode_balance_token_factor` 的版本。详细指标定义见 `README.md`。

## 1. 准备工作

将压缩包解压到一个新目录，进入其中的 `pcp_main_benefit_bench`。使用此前测试成功的 Python/vLLM 环境。以下命令供 Linux Bash 使用。

```bash
BENCH_DIR="$(pwd -P)"
RUN_DIR="$(mktemp -d "$BENCH_DIR/run-$(date +%Y%m%d-%H%M%S)-XXXXXX")"
printf 'BENCH_DIR=%s\nRUN_DIR=%s\n' "$BENCH_DIR" "$RUN_DIR"
python -m unittest -v test_bench.py
```

当前应通过 35 项 CPU 测试。客户端和测试不需要额外 pip 安装；可选的 `analyze.py` 另需 NumPy。不要把单元测试通过当作 NPU 服务已验证。

将输出的 **BENCH_DIR 和 RUN_DIR 两个绝对路径**记录到任务中。后面的服务终端、客户端终端都必须设置为同一组路径，不能在每个终端重新创建 RUN_DIR。

核对 `serve.sh` 与此前测试配置一致：

- 模型：`/mnt/weight/DeepSeek-V4-Flash-0731-w8a8`。
- 对外模型名：`DeepSeek-V4-Flash-w8a8`；端口：50001。
- TP=1、PCP=16、DCP=1、DP=1、PP=1；max_num_seqs=32。
- max_model_len=65536、block_size=32、max_num_batched_tokens=8192。
- `FULL_DECODE_ONLY`、npugraph_ex、async scheduling、EP、FlashComm1、prefix caching 和 chunked prefill 等保留脚本原值。
- decode sharding 两组都开启；factor 两组均为 1.5；只有 balance policy 改变。

记录实际模型目录、Python/vLLM 可执行文件和加载位置、vLLM/vllm-ascend commit 及未提交补丁、NPU 型号、CANN/驱动版本。若模型路径与服务器部署不同，可使用已确认的同一权重目录，并在所有组中保持一致、记录实际命令。

测试应使用原来分配给本实验的 16 张 NPU，期间没有其他请求。先识别 50001 端口及设备占用：正常停止属于本实验的旧服务；不要用广泛匹配命令终止其他服务，也不要并行启动两套模型。若端口或设备属于其他业务且无处置权限，报告阻塞。服务退出后确认它的 workers 已退出、设备资源释放，再启动下一组。

所有服务启动命令均为前台阻塞命令。请使用两个终端/已有会话机制：一个保持服务运行，另一个执行客户端。每次服务启动、客户端日志都保存在 RUN_DIR；不要覆盖以前的测试目录。

## 2. 先做 RR 诊断

服务终端（已设置相同 BENCH_DIR/RUN_DIR）：

```bash
cd "$RUN_DIR"
set -o pipefail
bash "$BENCH_DIR/serve.sh" round_robin 1.5 trace 2>&1 | tee "$RUN_DIR/rr_trace_server.log"
```

这会加载 `pcp_trace.TraceExtension`。诊断 JSONL 位于 `$RUN_DIR/pcp_trace/`，因为它跟随服务工作目录，不跟随客户端目录。

客户端终端：等待服务真正就绪，并确认返回预期模型：

```bash
curl -fsS http://127.0.0.1:50001/v1/models
```

启动过程中失败时查看服务日志，不要无限重试。服务正常后执行下面的诊断循环。任何失败都保留结果，按第 6 节处理，不忽略返回码：

```bash
cd "$BENCH_DIR"
set -euo pipefail
POLICY=round_robin
TAG=rr_trace
for CASE in hot_half_32k hot_half_48k hot_half_60k; do
  OUT="$RUN_DIR/diagnostics/$TAG/$CASE"
  python run_serving.py --policy "$POLICY" --factor 1.5 --case "$CASE" \
    --prefix-cache-hit-ratio 0.9 --prefix-cache-block-size 32 \
    --output-tokens 1024 --warmup-rounds 0 --repeats 1 --out "$OUT" \
    2>&1 | tee "$RUN_DIR/${TAG}_${CASE}_client.log"

  REQUEST_ID="$(python - "$OUT" <<'PY'
import json, sys
from pathlib import Path
files = list(Path(sys.argv[1]).glob('*.json'))
assert len(files) == 1, 'Use a fresh diagnostic output directory with exactly one result'
print(json.loads(files[0].read_text())['request_id'])
PY
)"
  python inspect_trace.py "$RUN_DIR/pcp_trace" --policy "$POLICY" \
    --request-contains "$REQUEST_ID" --details --verify \
    > "$RUN_DIR/${TAG}_${CASE}_placement.txt"
  python inspect_trace.py "$RUN_DIR/pcp_trace" --policy "$POLICY" \
    --request-contains "$REQUEST_ID" --verify \
    > "$RUN_DIR/${TAG}_${CASE}_summary.jsonl"
done
```

这里使用完整、唯一的 request_id 筛选，避免把旧日志或其他波次混在一起。没有加 `--limit`，会核对本波所有已采样快照。

`--warmup-rounds 0` 只关闭额外的完整推理预热轮。每个诊断波次仍会先提交一批前缀预热请求，每请求输出 1 token，完成并等待缓存计数更新后才提交测量请求。两批使用同一个新 salt，前缀相同、边界后首 token 刻意不同；下一波更换 salt。前缀预热元数据保存在本波 JSON 的 `cache_prime` 内，不另外生成结果 JSON，其 `pcpcache-prime-` 请求 ID 不会进入放置 trace。

## 3. 再做 LB 诊断并核对放置

先正常结束 RR 诊断服务，确认其 workers 退出。在服务终端启动：

```bash
cd "$RUN_DIR"
set -o pipefail
bash "$BENCH_DIR/serve.sh" load_balance 1.5 trace 2>&1 | tee "$RUN_DIR/lb_trace_server.log"
```

确认 `/v1/models` 就绪后，在客户端终端重复第 2 节诊断循环，**只将循环前的两行赋值改成**：

```bash
POLICY=load_balance
TAG=lb_trace
```

不要保留旧的 POLICY/TAG，也不要改变 case、factor 或输出长度。客户端 `--policy` 只是结果标签，不能切换服务策略；策略由 `serve.sh` 启动参数决定。

每个用例检查并记录：

- `all_ranks_verified=True` / `partition_verification.verified=true`：同一输入快照下 16 个 rank 的实际本地分区证据齐全且匹配。
- 每 rank 的实际 request ID、c、q、请求/token 数、sum_c、max_c。
- `assignment_status`、`moved_request_count`、`actual_matches_round_robin`。
- RR/LB 的 graph tokens / rows，以及 attention 代理分布。
- 结果 JSON 中 `prefix_cache_verified=true`，`cache_validation.per_request_verified_by_sum_of_bounds=true`，实测 cached/query token 数与 `cache_plan` 目标一致。仅在独占服务、无抢占、每请求缓存上界受控的前提下，从精确总和推导各请求达到其目标，不能称为 API 返回的逐请求计数。

状态解释：

| assignment_status | 解释 |
| --- | --- |
| rr_configured | 配置就是轮询 |
| lb_applied | LB plan 中至少一个请求的 owner 相对本轮轮询改变 |
| rr_retained | 有 LB plan，但最终保留/回退为轮询；不一定是错误 |
| rr_no_plan | LB 配置下本轮没有 plan，使用轮询 |
| inconsistent_trace | 信息不符合当前采集逻辑，需要核查 |

`has_plan=true` 不能证明发生重新分配；`fallback_reason=not_recorded` 表示日志没有记录算法具体回退分支，不得把猜测写成容量不足等确定原因。`moved_request_count` 是相对本轮轮询的 owner 差异，不是 KV cache 搬运次数。

预期的机制对照是：RR 部分 rank 两长、部分两短；LB 每 rank 一长一短，实际最大 tokens 和 graph tokens/rows 通常仍为 2。实际请求顺序或上下文进度可能改变这些结果，应以日志为准。若所有主用例都没有实际重新分配，先核查实际加载代码、配置和输入，不能把两组轮询的结果当成 LB 生效后的性能对照。若所有证据一致、LB 正常保留轮询，则如实报告该输入未触发收益条件。

诊断只采样全局 32 请求、q=1、无 prefill、请求 ID 含 pcpbench 的批次；每 rank 每波最多 16 个样本、间隔 32 步。它不是全量执行日志，不能据此给出精确的全程回退率。`trace` 模式的吞吐不进入正式收益报告。

## 4. 正式 ABBA：四次独立启动，不带 trace

只对两组诊断均有效、能保持共同 decode 窗口且无抢占的用例进入正式对照。默认用例顺序为 32K、48K、60K。若 60K 不满足条件，记录原因并在所有正式组一致排除 60K，不改变 batch 大小伪装成相同实验。

四组按下表依次运行。**每组都要独立重启服务，包括相邻的 lb_a 和 lb_b**；完成该组全部客户端用例后，再正常停服启动下一组。

| 顺序 | TAG | POLICY | 服务启动命令 |
| --- | --- | --- | --- |
| 1 | rr_a | round_robin | `bash "$BENCH_DIR/serve.sh" round_robin 1.5 perf` |
| 2 | lb_a | load_balance | `bash "$BENCH_DIR/serve.sh" load_balance 1.5 perf` |
| 3 | lb_b | load_balance | `bash "$BENCH_DIR/serve.sh" load_balance 1.5 perf` |
| 4 | rr_b | round_robin | `bash "$BENCH_DIR/serve.sh" round_robin 1.5 perf` |

每组服务终端根据表设置 TAG/POLICY 后运行：

```bash
cd "$RUN_DIR"
set -o pipefail
bash "$BENCH_DIR/serve.sh" "$POLICY" 1.5 perf 2>&1 | tee "$RUN_DIR/${TAG}_server.log"
```

服务就绪后，客户端终端也根据同一行设置 TAG/POLICY，并执行：

```bash
cd "$BENCH_DIR"
set -euo pipefail
for CASE in hot_half_32k hot_half_48k hot_half_60k; do
  python run_serving.py --policy "$POLICY" --factor 1.5 --case "$CASE" \
    --prefix-cache-hit-ratio 0.9 --prefix-cache-block-size 32 \
    --output-tokens 1024 --warmup-rounds 1 --repeats 3 \
    --out "$RUN_DIR/perf/$TAG/$CASE" \
    2>&1 | tee "$RUN_DIR/${TAG}_${CASE}_client.log"
done
```

如果已排除某个用例，四组循环必须使用同一个有效用例列表。每个 case 每组都是一轮完整预热加三轮正式测量；没有排除时共四次正式服务启动、每 case 12 个测量波次，RR/LB 各六个。

上述每个完整预热/正式波次都包含独立的前缀预热步骤。前缀预热时间不进入 TTFT、E2E 或 steady TPS；`cache_prime.elapsed_s` 单独记录。缓存命中减少 prefill 工作量，decode 的 c 仍是完整上下文。服务端指标缺失、实际命中数不足或超过目标时，客户端保存失败证据并退出，不得忽略失败继续比较。

不要给 `perf` 服务保留 worker-extension 参数，也不要把已有 trace 服务当作 perf 使用。日志诊断、设备 profiler 与正式吞吐测试均应独立进行。

## 5. 汇总与交付

四组结束后，在客户端终端运行：

```bash
cd "$BENCH_DIR"
python compare.py \
  "$RUN_DIR/perf/rr_a" "$RUN_DIR/perf/lb_a" \
  "$RUN_DIR/perf/lb_b" "$RUN_DIR/perf/rr_b" \
  --output "$RUN_DIR/comparison_abba.json" \
  | tee "$RUN_DIR/comparison_abba.txt"
```

比较工具输入仅指向正式结果目录，不传 diagnostics、不传包含其他汇总 JSON 的整个 RUN_DIR。不要使用 `--allow-missing-metrics` 将缺失抢占指标的实验冒充已验证；90% 模式的缓存与抢占核验不会被该选项绕过。

交付 `report.md` 和本次 RUN_DIR，报告至少包含：

1. 实际版本、完整服务参数、硬件环境、运行顺序和排除/失败用例。
2. 每个长度的 rank 放置示例，RR/LB 状态和 owner 改变数、全 rank 验证结果、图桶是否一致。回退原因未知时明确写未知。
3. 每个长度的 RR/LB steady TPS 中位数及 min/max、gain%、等效 TPOT、各波 preemptions 和 valid_window。保留负收益和失败记录。
4. 输出哈希差异与其验证情况；RR 自身不稳定只支持非确定性假设，不能自动证明所有策略差异无害。
5. 结论区分“分配改变”“代理 cost 降低”“有可测吞吐收益”。若仍无收益，如实写无收益；下一步建议采集 indexer/attention/全局 cache 更新/通信/CPU 间隙的独立设备 profile。
6. 每个用例的目标比例、每请求对齐后的 K/输入长度、各波实际 cached/query token 数和比例、缓存验证状态、前缀预热耗时。不能将 token 加权整批比例说成每个请求恰好 90%。

`batch_equivalent_tpot_ms` 是由同一个吞吐窗口换算的指标，不是另一份独立设备计时。详细客户端指标与采样边界见 README。

## 6. 失败与边界处理

- **缓存预热失败或 `prefix_cache_verified=false`**：先看保存的 `cache_prime_failure` / `cache_validation`，核对 `/metrics` 增量、无其他流量、无抢占及 salt 是否生效。计数异步延迟默认最多等 30 秒，可统一提高 `--cache-metrics-timeout` 后在新目录重跑。不能放宽 hits/queries 的验证条件来宣称命中目标达成。
- **后端实际命中粒度大于 32**：客户端参数只决定构造的前缀长度，不修改服务器缓存粒度。DeepSeek V4 混合/压缩 KV、retention 边界或缓存驱逐可能使实际命中不足。若 512-token 请求无法保留目标前缀，记录失败与实际粒度；不能静默改请求长度、缓存配置或删除短请求。此时需另行调整用例条件后重新配对测试。
- **trace 没有记录**：检查是否启动 trace 模式、worker-extension 是否导入，是否读取服务工作目录，以及是否实际形成 32 请求 q=1 的纯 decode 批次。不要把空日志当成轮询回退。
- **全 rank 验证缺失或失败**：确认采集已结束、日志目录包含所有节点/worker 的文件，使用同一完整 request_id；保留不同节点文件来源，避免覆盖或重复复制。排查实际请求归属、c/q 是否一致，不把残缺证据拼成通过。
- **valid_window=false**：可能是短请求在长请求完成 prefill 前进展过多，无法形成足够长的共同窗口。两种策略可统一改为输出 2048，在新的结果目录重做该用例的诊断和完整 ABBA；同一配对不能混用输出长度。要比较完整长度曲线，应将所有长度统一使用相同输出预算。
- **preemptions>0、OOM、无法维持 32 请求**：当前固定 batch 条件不成立，保留记录并排除该长度；不要减少 batch、提高显存比例或放松窗口后仍声称与原配置直接可比。
- **preemptions=null**：先排查 `/metrics`，保留未验证状态，不跳过检查来生成合格报告。
- **输入哈希或重复次数不匹配**：检查策略标签、参数、目录是否混入历史结果或失败重试；使用新的匹配目录重做，保留原记录。
- **长序列边界**：60K=61440，输出 1024/2048 时最长序列分别为 62464/63488，均小于 65536；这只是序列上限检查，不保证 KV cache 容量足够。
- **同图桶、代理下降但没有收益**：不继续通过调 factor 或挑选样本制造正收益；保留结果并转入算子关键路径分析。

第一轮先按本说明完成 32K/48K/60K。8K/16K 和 balanced_order_32k/uniform_8k 等负对照可在需要进一步定位时补测，不应取代主用例的如实结果。
