# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vllm-ascend project

from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import Mock, patch

import numpy as np
from vllm.config import CUDAGraphMode
from vllm.v1.worker.gpu.cudagraph_utils import BatchExecutionDescriptor
from vllm.v1.worker.gpu.model_runner import GPUModelRunner
from vllm.v1.worker.gpu.pcp_manager import PCPManager

from vllm_ascend.ascend_config import AscendConfig
from vllm_ascend.patch.worker import patch_model_runner as dispatch_module
from vllm_ascend.worker.v2 import model_runner as runner_module
from vllm_ascend.worker.v2 import pcp_manager as pcp_module
from vllm_ascend.worker.v2.model_runner import NPUModelRunner
from vllm_ascend.worker.v2.pcp_manager import AscendPCPManager


def make_manager(world=2, *, rank=0, rows=64, tokens=256, factor=1.5):
    manager = AscendPCPManager.__new__(AscendPCPManager)
    manager.pcp_world_size = world
    manager.pcp_rank = rank
    manager.dcp_world_size = 1
    manager.shard_decode_requests = True
    manager.decode_balance_policy = "load_balance"
    manager.decode_balance_token_factor = factor
    manager.vllm_config = SimpleNamespace(
        parallel_config=SimpleNamespace(
            pipeline_parallel_size=1, prefill_context_parallel_size=world, decode_context_parallel_size=1
        ),
        speculative_config=None,
        model_config=None,
    )
    manager._input_buffers = SimpleNamespace(max_num_reqs=rows, max_num_tokens=tokens)
    manager._local_block_tables = (np.empty((rows, 1)),)
    manager.global_input_buffers = SimpleNamespace(max_num_reqs=rows, max_num_tokens=tokens)
    manager.clear_decode_partition_plan()
    return manager


def prepare(manager, contexts, counts=None, prefilling=None):
    n = len(contexts)
    batch = SimpleNamespace(
        req_ids=[f"r{i}" for i in range(n)],
        num_scheduled_tokens=np.array([1] * n if counts is None else counts, dtype=np.int32),
        is_prefilling_np=np.array([False] * n if prefilling is None else prefilling, dtype=np.bool_),
        num_computed_tokens_np=np.array(contexts, dtype=np.int64),
    )
    manager.prepare_decode_partition(
        batch.req_ids, batch.num_scheduled_tokens, batch.is_prefilling_np, batch.num_computed_tokens_np
    )
    return batch


class TestDecodeBalance(TestCase):
    def test_hot_half_balances_all_sixteen_ranks(self):
        manager = make_manager(16)
        prepare(manager, ([32768] * 8 + [512] * 8) * 2)
        plan = manager._decode_partition_plan
        self.assertEqual(plan.per_rank_num_local_rows, (2,) * 16)
        work = [0] * 16
        for c, owner in zip(plan.cost_context_lens, plan.owner_ranks):
            work[owner] += int(c) + 1
        self.assertEqual(work, [33282] * 16)
        self.assertEqual(plan.max_num_tokens, 2)

    def test_uniform_contexts_keep_round_robin(self):
        manager = make_manager()
        prepare(manager, [512] * 6)
        np.testing.assert_array_equal(manager._decode_partition_plan.owner_ranks, [0, 1, 0, 1, 0, 1])

    def test_average_token_budget_allows_more_requests(self):
        manager = make_manager(factor=1.5)
        batch = prepare(manager, [10000, 1, 1, 1])
        plan = manager._decode_partition_plan
        self.assertEqual(sorted(plan.per_rank_num_local_rows), [1, 3])
        self.assertEqual(manager.get_num_tokens_for_dispatch(batch.num_scheduled_tokens, batch.is_prefilling_np), 3)
        self.assertEqual(manager.get_num_reqs_for_dispatch(3, 1), 3)
        manager.validate_decode_dispatch(BatchExecutionDescriptor(CUDAGraphMode.FULL, 3, 3, 1))

    def test_old_graph_bucket_is_rejected(self):
        manager = make_manager()
        prepare(manager, [10000, 1, 1, 1])
        with self.assertRaisesRegex(RuntimeError, "token capacity"):
            manager.validate_decode_dispatch(BatchExecutionDescriptor(CUDAGraphMode.FULL, 2, 2, 1))
        self.assertIsNone(manager._decode_partition_plan)

    def test_infeasible_budget_keeps_rr_and_dispatches_its_real_size(self):
        manager = make_manager(factor=1.0)
        batch = prepare(manager, [1000, 1, 2], [4, 1, 1])
        self.assertEqual(manager._get_decode_token_budget(batch.num_scheduled_tokens), 3)
        np.testing.assert_array_equal(manager._decode_partition_plan.owner_ranks, [0, 1, 0])
        self.assertEqual(manager.get_num_tokens_for_dispatch(batch.num_scheduled_tokens, batch.is_prefilling_np), 5)

    def test_budget_uses_average_not_rr_order(self):
        manager = make_manager(world=4)
        self.assertEqual(manager._get_decode_token_budget(np.array([1, 7, 2, 4])), 6)
        self.assertEqual(manager._get_decode_token_budget(np.array([4, 2, 7, 1])), 6)
        manager.decode_balance_token_factor = 1e308
        self.assertEqual(manager._get_decode_token_budget(np.array([4, 2, 7, 1])), 14)

    def test_physical_row_and_token_limits_constrain_candidates(self):
        for rows, tokens in ((2, 16), (16, 2)):
            with self.subTest(rows=rows, tokens=tokens):
                manager = make_manager(rows=rows, tokens=tokens)
                prepare(manager, [10000, 1, 1, 1])
                self.assertEqual(manager._decode_partition_plan.per_rank_num_local_rows, (2, 2))
        manager = make_manager(rows=16)
        manager._local_block_tables = (np.empty((2, 1)),)
        prepare(manager, [10000, 1, 1, 1])
        self.assertEqual(manager._decode_partition_plan.max_num_local_rows, 2)

    def test_prefill_reserves_segments_and_tokens(self):
        manager = make_manager()
        prepare(manager, [99999, 1000, 1, 1000, 1], [8, 1, 1, 1, 1], [True, False, False, False, False])
        plan = manager._decode_partition_plan
        self.assertEqual(plan.per_rank_num_prefill_segments, (2, 2))
        self.assertEqual(plan.per_rank_num_decode_reqs, (2, 2))
        self.assertEqual(plan.per_rank_num_local_rows, (4, 4))
        self.assertEqual(plan.per_rank_num_tokens, (6, 6))
        manager.validate_decode_dispatch(BatchExecutionDescriptor(CUDAGraphMode.PIECEWISE, 8, None))

    def test_empty_ranks_have_placeholder_rows(self):
        manager = make_manager(world=4)
        prepare(manager, [9, 9], [1, 0])
        plan = manager._decode_partition_plan
        self.assertEqual(plan.per_rank_num_local_rows, (1, 1, 1, 1))
        self.assertEqual(plan.per_rank_num_tokens, (1, 0, 0, 0))
        np.testing.assert_array_equal(plan.owner_ranks, [0, -1])

    def test_plan_does_not_alias_mutable_inputs(self):
        manager = make_manager()
        batch = prepare(manager, [1000, 1, 1000, 1])
        plan = manager._decode_partition_plan
        batch.req_ids[0] = "changed"
        batch.num_computed_tokens_np[:] = 0
        self.assertEqual(plan.req_ids[0], "r0")
        self.assertEqual(plan.cost_context_lens[0], 1000)
        for array in (plan.cost_context_lens, plan.num_scheduled_tokens, plan.owner_ranks, plan.is_prefilling_np):
            with self.assertRaises(ValueError):
                array[0] = 0

    def test_changed_dispatch_metadata_invalidates_plan(self):
        for field in ("num_scheduled_tokens", "is_prefilling_np"):
            manager = make_manager()
            batch = prepare(manager, [1000, 1, 1000, 1])
            getattr(batch, field)[0] += 1
            with self.assertRaisesRegex(RuntimeError, "metadata changed"):
                manager.get_num_tokens_for_dispatch(batch.num_scheduled_tokens, batch.is_prefilling_np)
            self.assertIsNone(manager._decode_partition_plan)

    def test_dispatch_checks_rows_uniformity_and_physical_padding(self):
        invalid = [
            BatchExecutionDescriptor(CUDAGraphMode.FULL, 2, 1, 1),
            BatchExecutionDescriptor(CUDAGraphMode.FULL, 3, 2, 1),
            BatchExecutionDescriptor(CUDAGraphMode.FULL, 2, 2, None),
            BatchExecutionDescriptor(CUDAGraphMode.PIECEWISE, 512, None),
        ]
        for desc in invalid:
            manager = make_manager()
            prepare(manager, [1000, 1, 1000, 1])
            with self.assertRaises(RuntimeError):
                manager.validate_decode_dispatch(desc)
        manager = make_manager()
        prepare(manager, [1000, 1, 1000, 1])
        manager.global_input_buffers.max_num_reqs = 3
        with self.assertRaisesRegex(RuntimeError, "global request capacity"):
            manager.validate_decode_dispatch(BatchExecutionDescriptor(CUDAGraphMode.FULL, 2, 2, 1))

    def test_disabled_and_pp_speculation_keep_original_policy(self):
        for policy, world, dcp in (("round_robin", 2, 1), ("load_balance", 1, 1), ("load_balance", 2, 2)):
            manager = make_manager(world)
            manager.decode_balance_policy = policy
            manager.vllm_config.parallel_config.decode_context_parallel_size = dcp
            prepare(manager, [1000, 1, 1000, 1])
            self.assertIsNone(manager._decode_partition_plan)
        manager = make_manager()
        manager.vllm_config.parallel_config.pipeline_parallel_size = 2
        manager.vllm_config.speculative_config = object()
        prepare(manager, [1000, 1, 1000, 1])
        np.testing.assert_array_equal(manager._decode_partition_plan.owner_ranks, [0, 1, 0, 1])

    def test_cost_uses_q_and_large_integer_contexts(self):
        manager = make_manager(factor=2)
        prepare(manager, [2**40, 2**38, 2**40, 2**38], [1, 4, 1, 4])
        plan = manager._decode_partition_plan
        self.assertTrue(np.all(plan.cost_context_lens > 2**31))
        work = [0, 0]
        rr = [0, 0]
        for i, (c, q, owner) in enumerate(zip(plan.cost_context_lens, plan.num_scheduled_tokens, plan.owner_ranks)):
            cost = int(c) * int(q) + int(q) * (int(q) + 1) // 2
            work[owner] += cost
            rr[i % 2] += cost
        self.assertLessEqual(max(work), max(rr))

    def test_seeded_mixed_batches_preserve_coverage_and_never_worsen_objective(self):
        rng = np.random.default_rng(17803)
        for _ in range(120):
            n = int(rng.integers(1, 33))
            world = int(rng.choice([2, 4, 8, 16]))
            q = rng.integers(0, 9, n)
            c = rng.integers(0, 65536, n)
            prefill = rng.random(n) < 0.25
            manager = make_manager(world, tokens=1024)
            batch = prepare(manager, c, q, prefill)
            plan = manager._decode_partition_plan
            decode = np.flatnonzero((q > 0) & ~prefill)
            work, rr = [0] * world, [0] * world
            for ordinal, i in enumerate(decode):
                cost = int(q[i]) * int(c[i]) + int(q[i]) * (int(q[i]) + 1) // 2
                work[plan.owner_ranks[i]] += cost
                rr[ordinal % world] += cost
            self.assertLessEqual(max(work), max(rr))
            manager._decode_owner_ranks = plan.owner_ranks
            chunks = [list(manager._iter_rank_chunks(r, q, prefill)) for r in range(world)]
            coverage = np.zeros(n, dtype=np.int64)
            for rank_chunks in chunks:
                for i, _, length in rank_chunks:
                    coverage[i] += length
            np.testing.assert_array_equal(coverage, q)
            self.assertEqual(plan.per_rank_num_tokens, tuple(sum(k for _, _, k in cs) for cs in chunks))
            self.assertEqual(
                manager.get_num_tokens_for_dispatch(batch.num_scheduled_tokens, prefill), max(plan.per_rank_num_tokens)
            )

    def test_partition_checks_structure_but_allows_corrected_execution_lengths(self):
        manager = make_manager()
        batch = prepare(manager, [1000, 1, 1000, 1])
        expected = manager._decode_partition_plan.owner_ranks.copy()
        batch.num_computed_tokens_np -= 1
        local = SimpleNamespace()
        desc = BatchExecutionDescriptor(CUDAGraphMode.FULL, 2, 2, 1)

        def parent(instance, actual, descriptor):
            self.assertIs(actual, batch)
            self.assertIs(descriptor, desc)
            np.testing.assert_array_equal(instance._decode_owner_ranks, expected)
            return local

        with (
            patch.object(PCPManager, "partition_batch", parent),
            patch.object(pcp_module, "AscendInputBatch", SimpleNamespace),
            patch.object(manager, "_finalize_partition", return_value=local),
        ):
            self.assertIs(manager.partition_batch(batch, desc), local)
        self.assertIs(manager._local_batch, local)
        self.assertIsNone(manager._decode_partition_plan)
        self.assertIsNone(manager._decode_owner_ranks)

    def test_partition_cleans_up_on_failure_and_rejects_changed_order(self):
        for changed in (False, True):
            manager = make_manager()
            batch = prepare(manager, [1000, 1, 1000, 1])
            if changed:
                batch.req_ids.reverse()
            with (
                patch.object(PCPManager, "partition_batch", side_effect=RuntimeError("parent failed")) as parent,
                self.assertRaisesRegex(RuntimeError, "metadata changed" if changed else "parent failed"),
            ):
                manager.partition_batch(batch, BatchExecutionDescriptor(CUDAGraphMode.NONE, 2, 2))
            self.assertEqual(parent.call_count, int(not changed))
            self.assertIsNone(manager._decode_partition_plan)
            self.assertIsNone(manager._decode_owner_ranks)


class TestBalanceRunner(TestCase):
    def test_gather_uses_scheduler_counts_after_reorder_without_device_sync(self):
        for speculative in (False, True):
            for skip_sync in (False, True):
                manager = make_manager()
                manager.vllm_config.speculative_config = object() if speculative else None
                runner = NPUModelRunner.__new__(NPUModelRunner)
                runner.pcp_manager = manager
                runner._target_uses_flashmla = True
                runner.adaptive_verification = None
                runner._update_seq_lens_cpu = Mock(side_effect=AssertionError("cost must not sync device lengths"))
                runner._can_skip_spec_cpu_length_sync = Mock(return_value=skip_sync)
                runner.req_states = SimpleNamespace(num_computed_tokens_np=np.array([999] * 4))
                batch = SimpleNamespace(
                    req_ids=["new", "c", "b", "a"],
                    num_scheduled_tokens=np.ones(4, dtype=np.int32),
                    is_prefilling_np=np.zeros(4, dtype=np.bool_),
                )
                scheduler = SimpleNamespace(
                    scheduled_new_reqs=[SimpleNamespace(req_id="new", num_computed_tokens=42)],
                    scheduled_cached_reqs=SimpleNamespace(req_ids=["a", "b", "c"], num_computed_tokens=[10, 1000, 20]),
                    scheduled_spec_decode_tokens={"b": [1]} if speculative else {},
                )
                with (
                    patch.object(GPUModelRunner, "gather_batch_req_state", return_value=(object(), None)),
                    patch.object(runner_module, "prepare_flashmla_batch_req_state", return_value=(batch, 1)),
                ):
                    self.assertEqual(runner.gather_batch_req_state(scheduler, False), (batch, 1))
                np.testing.assert_array_equal(manager._decode_partition_plan.cost_context_lens, [42, 20, 1000, 10])
                runner._update_seq_lens_cpu.assert_not_called()
                runner._can_skip_spec_cpu_length_sync.assert_not_called()
                np.testing.assert_array_equal(runner.req_states.num_computed_tokens_np, [999] * 4)

    def test_dummy_adaptive_and_disabled_paths_do_not_plan(self):
        for dummy, adaptive, policy in (
            (True, False, "load_balance"),
            (False, True, "load_balance"),
            (False, False, "round_robin"),
        ):
            manager = make_manager()
            prepare(manager, [1000, 1, 1000, 1])
            manager.decode_balance_policy = policy
            runner = NPUModelRunner.__new__(NPUModelRunner)
            runner.pcp_manager = manager
            runner._target_uses_flashmla = False
            runner.adaptive_verification = object() if adaptive else None
            with patch.object(GPUModelRunner, "gather_batch_req_state", return_value=(object(), None)):
                runner.gather_batch_req_state(SimpleNamespace(scheduled_spec_decode_tokens={"a": [1]}), dummy)
            self.assertIsNone(manager._decode_partition_plan)

    def test_scope_clears_old_and_failed_plans(self):
        runner = NPUModelRunner.__new__(NPUModelRunner)
        runner.pcp_manager = make_manager()
        prepare(runner.pcp_manager, [1000, 1, 1000, 1])
        with self.assertRaisesRegex(ValueError, "failed"), runner._pcp_decode_plan_scope():
            self.assertIsNone(runner.pcp_manager._decode_partition_plan)
            prepare(runner.pcp_manager, [1000, 1, 1000, 1])
            raise ValueError("failed")
        self.assertIsNone(runner.pcp_manager._decode_partition_plan)

    def test_dispatch_uses_both_plan_dimensions_and_preserves_dp_kwargs(self):
        manager = make_manager()
        prepare(manager, [10000, 1, 1, 1])
        graph = SimpleNamespace(model_runner=SimpleNamespace(pcp_manager=manager), vllm_config=manager.vllm_config)
        desc = BatchExecutionDescriptor(CUDAGraphMode.FULL, 4, 4, 1)
        sync = object()
        with patch.object(dispatch_module, "_dispatch_cg_and_sync_dp", return_value=(desc, sync)) as dispatch:
            result = dispatch_module.dispatch_cg_and_sync_dp(graph, 4, 3, 1, 2, 0, allow_skip_drafts=True)
        self.assertEqual(result, (desc, sync))
        self.assertEqual(dispatch.call_args.args[1:], (3, 3, 1, 2, 0))
        self.assertEqual(dispatch.call_args.kwargs, {"allow_skip_drafts": True})

    def test_dispatch_validates_the_final_dp_bucket(self):
        manager = make_manager()
        prepare(manager, [10000, 1, 1, 1])
        graph = SimpleNamespace(model_runner=SimpleNamespace(pcp_manager=manager))
        desc = BatchExecutionDescriptor(CUDAGraphMode.FULL, 2, 2, 1)
        with (
            patch.object(dispatch_module, "_dispatch_cg_and_sync_dp", return_value=(desc, object())),
            self.assertRaisesRegex(RuntimeError, "token capacity"),
        ):
            dispatch_module.dispatch_cg_and_sync_dp(graph, 4, 3, 1, 2, 0)

    def test_unplanned_dispatch_keeps_existing_uniform_and_profile_behavior(self):
        for graph, rows, tokens, q, expected_rows in (
            (SimpleNamespace(vllm_config=make_manager().vllm_config), 4, 2, 1, 2),
            (None, 3, 8, None, 3),
        ):
            with patch.object(dispatch_module, "_dispatch_cg_and_sync_dp", return_value=(object(), None)) as dispatch:
                dispatch_module.dispatch_cg_and_sync_dp(graph, rows, tokens, q, 1, 0)
                self.assertEqual(dispatch.call_args.args[1], expected_rows)


class TestBalanceConfig(TestCase):
    def test_defaults_and_valid_values(self):
        cfg = AscendConfig(sparse_kv_offload_config=SimpleNamespace(enabled=False))
        self.assertEqual(cfg.pcp_decode_balance_policy, "round_robin")
        self.assertEqual(cfg.pcp_decode_balance_token_factor, 1.5)
        for value in (1, 1.5, 2.0):
            cfg = AscendConfig(
                sparse_kv_offload_config=SimpleNamespace(enabled=False),
                pcp_decode_balance_policy="load_balance",
                pcp_decode_balance_token_factor=value,
            )
            self.assertEqual(cfg.pcp_decode_balance_token_factor, value)

    def test_invalid_policy_and_factor(self):
        for value in ("context", "balanced", None):
            with self.assertRaisesRegex(ValueError, "pcp_decode_balance_policy"):
                AscendConfig(sparse_kv_offload_config=SimpleNamespace(enabled=False), pcp_decode_balance_policy=value)
        for value in (0.9, -1, float("nan"), float("inf"), True, "1.5"):
            with self.assertRaisesRegex(ValueError, "pcp_decode_balance_token_factor"):
                AscendConfig(
                    sparse_kv_offload_config=SimpleNamespace(enabled=False), pcp_decode_balance_token_factor=value
                )
