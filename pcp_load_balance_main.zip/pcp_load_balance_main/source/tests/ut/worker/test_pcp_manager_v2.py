# Adapt from https://github.com/vllm-project/vllm/blob/main/vllm/v1/worker/gpu/model_runner.py
# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
# Copyright (c) 2026 Huawei Technologies Co., Ltd. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# This file is a part of the vllm-ascend project.
#
from contextlib import nullcontext
from inspect import signature
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import numpy as np
import pytest
import torch
from vllm.config import CUDAGraphMode, ParallelConfig
from vllm.config.utils import replace
from vllm.v1.worker.gpu import cudagraph_utils
from vllm.v1.worker.gpu import model_runner as vllm_model_runner
from vllm.v1.worker.gpu.cudagraph_utils import BatchExecutionDescriptor
from vllm.v1.worker.gpu.input_batch import InputBatch
from vllm.v1.worker.gpu.pcp_manager import PCPManager

from vllm_ascend.attention.context_parallel.common_cp import is_pcp_decode_sharding_enabled
from vllm_ascend.platform import _setup_worker_and_scheduler
from vllm_ascend.worker.v2 import states as states_module
from vllm_ascend.worker.v2.aclgraph_utils import ModelAclGraphManager
from vllm_ascend.worker.v2.input_batch import AscendInputBatch, AscendInputBuffers
from vllm_ascend.worker.v2.model_runner import NPUModelRunner
from vllm_ascend.worker.v2.model_states.default import AscendModelState
from vllm_ascend.worker.v2.pcp_manager import AscendPCPManager
from vllm_ascend.worker.v2.spec_decode.dflash.speculator import AscendDFlashSpeculator
from vllm_ascend.worker.v2.spec_decode.dspark.speculator import AscendDSparkSpeculator
from vllm_ascend.worker.v2.spec_decode.target_dependent_ar import aclgraph as aclgraph_module
from vllm_ascend.worker.v2.spec_decode.target_dependent_ar.aclgraph import AutoRegressiveAclGraphManager
from vllm_ascend.worker.v2.spec_decode.target_dependent_ar.speculator import (
    AscendTargetDependentARSpeculator,
)


def _mock_async_copy_to_cpu(value, out=None, device=None):
    """Copy PCP metadata without requiring device hooks in CPU-only UTs."""
    if isinstance(value, np.ndarray):
        value = torch.from_numpy(value)
    elif not isinstance(value, torch.Tensor):
        value = torch.as_tensor(value)

    if out is not None:
        out.copy_(value)
        return out

    return value.to(device="cpu")


def _make_pcp_config(
    cudagraph_mode: CUDAGraphMode,
    *,
    sparse_mla: bool = True,
    pipeline_parallel_size: int = 1,
    data_parallel_size: int = 1,
    speculative_config=None,
):
    hf_text_config = SimpleNamespace(index_topk=2048) if sparse_mla else SimpleNamespace()
    return SimpleNamespace(
        parallel_config=SimpleNamespace(
            prefill_context_parallel_size=2,
            decode_context_parallel_size=1,
            pipeline_parallel_size=pipeline_parallel_size,
            data_parallel_size=data_parallel_size,
        ),
        model_config=SimpleNamespace(
            use_mla=True,
            is_encoder_decoder=False,
            hf_text_config=hf_text_config,
        ),
        lora_config=None,
        speculative_config=speculative_config,
        compilation_config=SimpleNamespace(cudagraph_mode=cudagraph_mode),
    )


def _partition_batch(manager, batch, *, padded_num_tokens=None, batch_desc=None):
    """Use the batch descriptor API without token/request padding by default."""
    if batch_desc is None:
        batch_desc = BatchExecutionDescriptor(
            CUDAGraphMode.NONE,
            int(getattr(batch, "num_tokens", 0)),
            None,
        )
    return manager.partition_batch(batch, batch_desc)


@pytest.mark.parametrize(
    "cudagraph_mode,speculative,pcp_size,dcp_size,expected_sharding",
    [
        (CUDAGraphMode.NONE, False, 2, 1, True),
        (CUDAGraphMode.NONE, True, 2, 1, True),
        (CUDAGraphMode.NONE, False, 1, 1, False),
        (CUDAGraphMode.NONE, False, 2, 2, False),
        (CUDAGraphMode.FULL_DECODE_ONLY, False, 2, 1, True),
        (CUDAGraphMode.FULL_DECODE_ONLY, True, 2, 1, True),
    ],
)
@pytest.mark.parametrize("upstream_decode_sharding", [False, True])
def test_decode_sharding_uses_parallel_config(
    cudagraph_mode, speculative, pcp_size, dcp_size, expected_sharding, upstream_decode_sharding
):
    config = _make_pcp_config(cudagraph_mode)
    config.parallel_config.prefill_context_parallel_size = pcp_size
    config.parallel_config.decode_context_parallel_size = dcp_size
    config.speculative_config = SimpleNamespace(method="mtp") if speculative else None
    assert is_pcp_decode_sharding_enabled(config) is expected_sharding
    rank = pcp_size - 1
    manager = AscendPCPManager(
        pcp_size, rank, torch.device("cpu"), shard_decode_requests=upstream_decode_sharding, dcp_world_size=dcp_size
    )
    manager.bind_config(config)
    counts = np.array([1, 1], dtype=np.int32)
    prefilling = np.array([False, False])

    assert manager.vllm_config is config
    assert manager.is_decode_sharded is expected_sharding
    expected_upstream_sharding = upstream_decode_sharding and expected_sharding
    assert manager.shard_decode_requests is expected_upstream_sharding
    for _ in range(2):
        np.testing.assert_array_equal(
            manager.replicated_requests(counts, prefilling), [not expected_sharding, not expected_sharding]
        )
        assert manager.shard_decode_requests is expected_upstream_sharding
    expected = [(1, 0, 1)] if expected_sharding else [(0, 0, 1), (1, 0, 1)]
    assert list(manager._iter_rank_chunks(rank, counts, prefilling)) == expected


def test_constructor_forwards_decode_sharding_with_release_compatible_arguments():
    manager = AscendPCPManager(2, 0, torch.device("cpu"), shard_decode_requests=True, moe_gathers_tokens=True)
    assert manager.shard_decode_requests is True


def test_decode_sharding_does_not_add_a_parallel_config_field():
    parallel_config = ParallelConfig(prefill_context_parallel_size=2, decode_context_parallel_size=1)
    parallel_config.worker_cls = "test-worker"
    config = SimpleNamespace(
        parallel_config=parallel_config,
        speculative_config=SimpleNamespace(method="mtp"),
        compilation_config=SimpleNamespace(cudagraph_mode=CUDAGraphMode.NONE),
        cache_config=None,
    )
    ascend_config = SimpleNamespace(
        scheduler_config=SimpleNamespace(
            dyntra_lb_config=SimpleNamespace(enabled=False),
            batch_job_sched_config=SimpleNamespace(enabled=False),
        )
    )
    with (
        patch("vllm_ascend.platform.get_current_hardware_profile") as hardware_profile,
        patch("vllm_ascend.platform.refresh_block_size"),
    ):
        hardware_profile.return_value.supports.return_value = False
        _setup_worker_and_scheduler(config, ascend_config)
    # vLLM main declares this on ParallelConfig itself.
    assert parallel_config.pcp_shard_decode_requests is True
    replace(parallel_config)
    assert is_pcp_decode_sharding_enabled(config) is True


@pytest.mark.parametrize("bind_runner_state", [False, True])
@pytest.mark.parametrize("speculative", [False, True])
@pytest.mark.parametrize("upstream_decode_sharding", [False, True])
def test_kpool_decode_keeps_replicated_pcp_state(
    speculative: bool, upstream_decode_sharding: bool, bind_runner_state: bool
):
    config = _make_pcp_config(CUDAGraphMode.NONE)
    config.model_config.hf_text_config.index_kpool = 4
    config.speculative_config = SimpleNamespace(method="mtp") if speculative else None
    config.parallel_config = ParallelConfig(prefill_context_parallel_size=2, decode_context_parallel_size=1)
    manager = AscendPCPManager(2, 1, torch.device("cpu"), shard_decode_requests=upstream_decode_sharding)
    if bind_runner_state:
        manager.set_runner_state(config, SimpleNamespace(), SimpleNamespace())
    else:
        manager.bind_config(config)
    assert manager.vllm_config is config
    assert not manager.shard_decode_requests
    assert config.parallel_config.pcp_shard_decode_requests is True
    replace(config.parallel_config)
    query_len = 6 if speculative else 1
    counts = np.array([query_len, query_len], dtype=np.int32)
    prefilling = np.array([False, False])

    assert not is_pcp_decode_sharding_enabled(config)
    manager.decode_balance_policy = "load_balance"
    assert not manager.decode_balance_enabled
    np.testing.assert_array_equal(manager.replicated_requests(counts, prefilling), [True, True])
    assert not manager.shard_decode_requests
    assert list(manager._iter_rank_chunks(1, counts, prefilling)) == [(0, 0, query_len), (1, 0, query_len)]


def test_validate_config_allows_sparse_mla_full_decode_only():
    vllm_config = _make_pcp_config(CUDAGraphMode.FULL_DECODE_ONLY)

    with patch.object(
        vllm_model_runner.pcp.PCPManager,
        "validate_config",
        side_effect=AssertionError("Ascend validation must not delegate to the upstream implementation."),
    ) as upstream_validate_config:
        AscendPCPManager.validate_config(vllm_config, supports_mm_inputs=False)

    upstream_validate_config.assert_not_called()
    assert vllm_config.compilation_config.cudagraph_mode == CUDAGraphMode.FULL_DECODE_ONLY


def test_validate_config_allows_gqa():
    vllm_config = _make_pcp_config(CUDAGraphMode.NONE, sparse_mla=False)
    vllm_config.model_config.use_mla = False

    AscendPCPManager.validate_config(vllm_config, supports_mm_inputs=False)


def test_validate_config_allows_pipeline_parallelism():
    vllm_config = _make_pcp_config(
        CUDAGraphMode.FULL_DECODE_ONLY,
        pipeline_parallel_size=2,
    )

    AscendPCPManager.validate_config(vllm_config, supports_mm_inputs=False)


def test_validate_config_allows_kpool_model_registered_as_multimodal():
    vllm_config = _make_pcp_config(CUDAGraphMode.NONE)
    vllm_config.model_config.hf_text_config.index_kpool = 4

    AscendPCPManager.validate_config(vllm_config, supports_mm_inputs=True)


@pytest.mark.parametrize(
    "cudagraph_mode",
    [CUDAGraphMode.PIECEWISE, CUDAGraphMode.FULL_AND_PIECEWISE],
)
def test_validate_config_allows_sparse_mla_piecewise_graph_modes(cudagraph_mode):
    vllm_config = _make_pcp_config(cudagraph_mode)

    AscendPCPManager.validate_config(vllm_config, supports_mm_inputs=False)


@pytest.mark.parametrize("sparse_mla", [True, False])
def test_validate_config_rejects_full_graph(sparse_mla):
    vllm_config = _make_pcp_config(CUDAGraphMode.FULL, sparse_mla=sparse_mla)

    with pytest.raises(NotImplementedError, match="does not support FULL CUDA graphs"):
        AscendPCPManager.validate_config(vllm_config, supports_mm_inputs=False)


def test_pcp_manager_uses_persistent_ascend_input_buffers():
    manager = AscendPCPManager(
        pcp_world_size=2,
        pcp_rank=0,
        device=torch.device("cpu"),
        max_num_reqs=3,
        max_num_tokens=16,
    )

    assert isinstance(manager._input_buffers, AscendInputBuffers)
    assert manager._input_buffers.max_num_reqs == 6
    assert manager._input_buffers.seq_lens_np.shape == (6,)
    assert manager._input_buffers.query_start_loc.shape == (7,)
    assert manager.input_buffers is manager._input_buffers


def _make_local_pcp_batch():
    """Build a local batch in the shape returned by the community PCP manager."""
    input_buffers = AscendInputBuffers(
        max_num_reqs=4,
        max_num_tokens=16,
        device=torch.device("cpu"),
    )
    base_batch = InputBatch.make_dummy(
        num_reqs=2,
        num_tokens=6,
        input_buffers=input_buffers,
    )

    # Local PCP rows: one starts at position 6 and contains two tokens; the
    # other starts at position 13 and contains four tokens.
    base_batch.req_ids = ["req-head", "req-tail"]
    base_batch.idx_mapping = torch.tensor([3, 7], dtype=torch.int32)
    base_batch.idx_mapping_np = np.array([3, 7], dtype=np.int32)
    base_batch.expanded_idx_mapping = base_batch.idx_mapping
    base_batch.num_scheduled_tokens = np.array([2, 4], dtype=np.int32)
    base_batch.query_start_loc_np = np.array([0, 2, 6], dtype=np.int32)
    base_batch.query_start_loc.copy_(torch.tensor([0, 2, 6], dtype=torch.int32))
    base_batch.num_computed_tokens_np = np.array([6, 13], dtype=np.int32)
    base_batch.prefill_len_np = np.array([32, 32], dtype=np.int32)
    base_batch.num_computed_prefill_tokens_np = np.array([6, 13], dtype=np.int32)
    base_batch.is_prefilling_np = np.array([True, True])
    base_batch.seq_lens.copy_(torch.tensor([8, 17], dtype=torch.int32))
    base_batch.seq_lens_cpu_upper_bound = torch.tensor([500, 600], dtype=torch.int32)
    base_batch.input_ids.copy_(torch.tensor([10, 11, 20, 21, 22, 23], dtype=torch.int32))
    base_batch.positions.copy_(torch.tensor([6, 7, 13, 14, 15, 16], dtype=torch.int64))
    base_batch.is_padding.fill_(False)

    return AscendInputBatch(
        **base_batch.__dict__,
        seq_lens_np=np.array([101, 102], dtype=np.int32),
        attn_state="global-attn-state",
    )


def _make_global_pcp_batch():
    """Build the global batch that is passed into PCPManager.partition_batch."""
    input_buffers = AscendInputBuffers(
        max_num_reqs=4,
        max_num_tokens=32,
        device=torch.device("cpu"),
    )
    base_batch = InputBatch.make_dummy(
        num_reqs=1,
        num_tokens=18,
        input_buffers=input_buffers,
    )
    base_batch.req_ids = ["global-req"]
    base_batch.idx_mapping = torch.tensor([3], dtype=torch.int32)
    base_batch.idx_mapping_np = np.array([3], dtype=np.int32)
    base_batch.expanded_idx_mapping = base_batch.idx_mapping
    base_batch.num_scheduled_tokens = np.array([18], dtype=np.int32)
    base_batch.query_start_loc_np = np.array([0, 18], dtype=np.int32)
    base_batch.query_start_loc.copy_(torch.tensor([0, 18], dtype=torch.int32))
    base_batch.num_computed_tokens_np = np.array([0], dtype=np.int32)
    base_batch.prefill_len_np = np.array([18], dtype=np.int32)
    base_batch.num_computed_prefill_tokens_np = np.array([0], dtype=np.int32)
    base_batch.is_prefilling_np = np.array([True])
    base_batch.seq_lens.copy_(torch.tensor([18], dtype=torch.int32))
    base_batch.seq_lens_cpu_upper_bound = torch.tensor([18], dtype=torch.int32)
    base_batch.input_ids.copy_(torch.arange(18, dtype=torch.int32))
    base_batch.positions.copy_(torch.arange(18, dtype=torch.int64))
    base_batch.is_padding.fill_(False)

    return AscendInputBatch(
        **base_batch.__dict__,
        seq_lens_np=np.array([18], dtype=np.int32),
        attn_state="global-attn-state",
    )


def test_partition_batch_refreshes_local_ascend_input_batch_metadata():
    """Refresh Ascend metadata after the real PCP local-batch rewrite."""
    global_batch = _make_global_pcp_batch()
    req_states = SimpleNamespace(
        last_sampled_tokens=torch.zeros(4, dtype=torch.int64),
        prefill_len=SimpleNamespace(gpu=torch.zeros(4, dtype=torch.int32)),
        draft_tokens=torch.empty((4, 0), dtype=torch.int64),
    )
    manager = AscendPCPManager(
        pcp_world_size=2,
        pcp_rank=0,
        device=torch.device("cpu"),
        req_states=req_states,
        max_num_reqs=1,
        max_num_tokens=18,
    )
    manager.vllm_config = _make_pcp_config(CUDAGraphMode.NONE)
    local_attn_state = object()

    with (
        # Upstream main (#56888) moved the device copy to async_tensor_h2d and
        # no longer imports prepare_pos_seq_lens / combine_sampled_and_draft_tokens
        # into pcp_manager. Stub only the CPU-incompatible copy;
        # AscendPCPManager.partition_batch and PCPManager.partition_batch both
        # execute unmocked below.
        patch(
            "vllm.v1.worker.gpu.pcp_manager.async_tensor_h2d",
            side_effect=_mock_async_copy_to_cpu,
        ),
        patch(
            "vllm_ascend.worker.v2.pcp_manager.build_attn_state",
            return_value=local_attn_state,
        ) as build_attn_state,
    ):
        result = _partition_batch(
            manager,
            global_batch,
            padded_num_tokens=12,
            batch_desc=BatchExecutionDescriptor(CUDAGraphMode.PIECEWISE, 12, None),
        )

    assert isinstance(result, AscendInputBatch)
    assert result is not global_batch
    assert manager.global_batch is global_batch
    np.testing.assert_array_equal(global_batch.seq_lens_np, np.array([18], dtype=np.int32))
    assert global_batch.attn_state == "global-attn-state"

    # PCP=2 rank 0 owns the head chunk then the tail chunk; the real base
    # implementation produces this canonical local row order and pads to rank
    # 1's size.
    assert result.req_ids == ["global-req", "global-req"]
    np.testing.assert_array_equal(result.idx_mapping_np, np.array([3, 3], dtype=np.int32))
    np.testing.assert_array_equal(result.num_scheduled_tokens, np.array([5, 3], dtype=np.int32))
    np.testing.assert_array_equal(result.query_start_loc_np, np.array([0, 5, 8], dtype=np.int32))
    assert result.num_tokens == 8
    expected_num_tokens_after_padding = 12
    assert result.num_tokens_after_padding == expected_num_tokens_after_padding
    assert torch.equal(result.input_ids[:8], torch.tensor([0, 1, 2, 3, 4, 15, 16, 17], dtype=torch.int32))

    # dataclasses.replace() retains the global Ascend-only fields by default;
    # the override must refresh them from real PCP-local CPU rows.
    expected_seq_lens = np.array([5, 18], dtype=np.int32)
    np.testing.assert_array_equal(result.seq_lens_np, expected_seq_lens)
    assert result.attn_state is local_attn_state
    build_attn_state.assert_called_once()
    args = build_attn_state.call_args.args
    assert args[0] is manager.vllm_config
    np.testing.assert_array_equal(args[1], expected_seq_lens)
    assert args[2] == result.num_reqs
    np.testing.assert_array_equal(args[3], result.num_scheduled_tokens)
    np.testing.assert_array_equal(args[4], result.num_scheduled_tokens)


@pytest.mark.parametrize("query_len", [1, 4])
@pytest.mark.parametrize("graph_mode", [CUDAGraphMode.NONE, CUDAGraphMode.FULL])
def test_load_balance_real_partition_and_restore_with_corrected_lengths(query_len, graph_mode):
    """Exercise upstream tensor partitioning with uneven owners and graph rows."""
    buffers = AscendInputBuffers(4, 4 * query_len, device=torch.device("cpu"))
    base = InputBatch.make_dummy(num_reqs=4, num_tokens=4 * query_len, input_buffers=buffers)
    base.req_ids = [f"r{i}" for i in range(4)]
    base.is_dummy = False
    base.has_prefill = False
    base.num_draft_tokens = 4 * (query_len - 1)
    base.idx_mapping = torch.arange(4, dtype=torch.int32)
    base.idx_mapping_np = np.arange(4, dtype=np.int32)
    base.expanded_idx_mapping = base.idx_mapping
    base.num_scheduled_tokens = np.full(4, query_len, dtype=np.int32)
    base.query_start_loc_np = np.arange(5, dtype=np.int32) * query_len
    base.query_start_loc.copy_(torch.from_numpy(base.query_start_loc_np))
    base.is_prefilling_np = np.zeros(4, dtype=np.bool_)
    scheduler_context = np.array([10000, 10, 10, 10], dtype=np.int32)
    # Execution lengths are corrected after planning; only these lengths may
    # reach the actual positions and attention sequence-length metadata.
    base.num_computed_tokens_np = scheduler_context - 1
    base.prefill_len_np = base.num_computed_tokens_np.copy()
    base.num_computed_prefill_tokens_np = base.prefill_len_np.copy()
    seq_lens = base.num_computed_tokens_np + query_len
    base.seq_lens.copy_(torch.from_numpy(seq_lens))
    base.seq_lens_cpu_upper_bound = torch.from_numpy(seq_lens.copy())
    base.input_ids.copy_(torch.arange(4 * query_len, dtype=torch.int32))
    base.positions.copy_(torch.from_numpy((base.num_computed_tokens_np[:, None] + np.arange(query_len)).ravel()))
    base.is_padding.fill_(False)
    batch = AscendInputBatch(**base.__dict__, seq_lens_np=seq_lens.copy(), attn_state="decode")
    padded_rows = 4 if graph_mode == CUDAGraphMode.FULL else 3
    desc = BatchExecutionDescriptor(graph_mode, padded_rows * query_len, padded_rows, query_len)
    locals_by_rank = []
    for rank in range(2):
        manager = AscendPCPManager(2, rank, torch.device("cpu"), max_num_reqs=4, max_num_tokens=4 * query_len)
        manager.vllm_config = _make_pcp_config(CUDAGraphMode.FULL_DECODE_ONLY)
        manager.global_input_buffers = buffers
        manager.decode_balance_policy = "load_balance"
        manager.prepare_decode_partition(
            batch.req_ids, batch.num_scheduled_tokens, batch.is_prefilling_np, scheduler_context
        )
        plan = manager._decode_partition_plan
        np.testing.assert_array_equal(plan.owner_ranks, [0, 1, 1, 1])
        assert plan.per_rank_num_local_rows == (1, 3)
        assert manager.get_num_tokens_for_dispatch(batch.num_scheduled_tokens, batch.is_prefilling_np) == 3 * query_len
        with (
            patch("vllm.v1.worker.gpu.pcp_manager.async_tensor_h2d", side_effect=_mock_async_copy_to_cpu),
            patch("vllm_ascend.worker.v2.pcp_manager.async_copy_to_gpu", side_effect=_mock_async_copy_to_cpu),
        ):
            local = manager.partition_batch(batch, desc)
        expected = np.flatnonzero(plan.owner_ranks == rank)
        assert local.req_ids == [batch.req_ids[i] for i in expected]
        assert local.num_tokens == len(expected) * query_len
        assert local.num_tokens_after_padding == padded_rows * query_len
        assert local.num_reqs_after_padding == (padded_rows if graph_mode == CUDAGraphMode.FULL else len(expected))
        np.testing.assert_array_equal(local.seq_lens_np[: len(expected)], seq_lens[expected])
        assert torch.equal(local.seq_lens[: len(expected)], torch.from_numpy(seq_lens[expected]))
        assert manager._local_batch is local
        assert manager._decode_partition_plan is None
        assert manager._decode_owner_ranks is None
        assert int(manager._gathered_kv_write_mask.sum()) == batch.num_tokens
        locals_by_rank.append(local.input_ids.clone())
    restored = torch.cat(locals_by_rank)[manager._hidden_restore_idx]
    assert torch.equal(restored, batch.input_ids)


def test_full_decode_request_layout_is_token_sized_only_without_drafts():
    manager = AscendPCPManager.__new__(AscendPCPManager)
    decode_batch = SimpleNamespace(is_prefilling_np=np.zeros(4, dtype=np.bool_), num_draft_tokens=0)
    draft_decode_batch = SimpleNamespace(is_prefilling_np=np.zeros(4, dtype=np.bool_), num_draft_tokens=8)
    prefill_batch = SimpleNamespace(is_prefilling_np=np.ones(2, dtype=np.bool_), num_draft_tokens=0)

    manager.vllm_config = _make_pcp_config(CUDAGraphMode.FULL_DECODE_ONLY)
    assert manager._full_decode_requests_are_token_sized(decode_batch) is True
    # Speculative (MTP/Eagle3) decode slots carry more than one token, so
    # request metadata must stay at the request extent (not the token extent).
    assert manager._full_decode_requests_are_token_sized(draft_decode_batch) is False
    assert manager._full_decode_requests_are_token_sized(prefill_batch) is False

    manager.vllm_config = _make_pcp_config(CUDAGraphMode.NONE)
    assert manager._full_decode_requests_are_token_sized(decode_batch) is False


class _ReplicatedPCPManager(AscendPCPManager):
    """Exercise replicated layouts explicitly, independently of speculation."""

    @property
    def is_decode_sharded(self):
        return False


def _make_replicated_pcp_manager():
    manager = _ReplicatedPCPManager(2, 0, torch.device("cpu"), max_num_reqs=8, max_num_tokens=32)
    manager.vllm_config = _make_pcp_config(
        CUDAGraphMode.FULL_DECODE_ONLY,
        speculative_config=SimpleNamespace(num_speculative_tokens=3),
    )
    manager._hidden_restore_idx = torch.arange(32, dtype=torch.int64)
    return manager


@pytest.mark.parametrize("requests_already_padded", [False, True])
def test_partition_batch_pads_decode_requests_when_tokens_are_already_padded(requests_already_padded):
    """Keep request metadata aligned when upstream already pads tokens."""
    input_buffers = AscendInputBuffers(
        max_num_reqs=4,
        max_num_tokens=4,
        device=torch.device("cpu"),
    )
    base_batch = InputBatch.make_dummy(
        num_reqs=3,
        num_tokens=3,
        input_buffers=input_buffers,
        max_query_len=1,
    )
    local_batch = AscendInputBatch(
        **base_batch.__dict__,
        seq_lens_np=np.array([11, 21, 31], dtype=np.int32),
        attn_state="local-attn-state",
    )
    local_batch.is_dummy = False
    local_batch.num_reqs = 3
    local_batch.num_reqs_after_padding = 3
    local_batch.num_tokens = 3
    local_batch.num_tokens_after_padding = 4
    local_batch.num_scheduled_tokens = np.ones(3, dtype=np.int32)
    local_batch.num_computed_tokens_np = np.array([10, 20, 30], dtype=np.int32)
    local_batch.is_prefilling_np = np.zeros(3, dtype=np.bool_)
    local_batch.seq_lens_cpu_upper_bound = torch.tensor([11, 21, 31], dtype=torch.int32)
    local_batch.num_draft_tokens_per_req = None

    global_input_buffers = AscendInputBuffers(
        max_num_reqs=4,
        max_num_tokens=4,
        device=torch.device("cpu"),
    )
    global_base_batch = InputBatch.make_dummy(
        num_reqs=3,
        num_tokens=3,
        input_buffers=global_input_buffers,
        max_query_len=1,
    )
    global_batch = AscendInputBatch(
        **global_base_batch.__dict__,
        seq_lens_np=np.array([11, 21, 31], dtype=np.int32),
        attn_state="global-attn-state",
    )
    global_batch.num_reqs_after_padding = 4
    global_batch.num_tokens_after_padding = 4
    global_batch.is_prefilling_np = np.zeros(3, dtype=np.bool_)
    global_batch.query_start_loc = global_input_buffers.query_start_loc[:5]
    global_batch.query_start_loc.copy_(torch.tensor([0, 1, 2, 3, 4], dtype=torch.int32))
    global_batch.query_start_loc_np = np.array([0, 1, 2, 3, 4], dtype=np.int32)

    input_buffers.input_ids[:4].copy_(torch.tensor([101, 102, 103, 99], dtype=torch.int32))
    input_buffers.positions[:4].copy_(torch.tensor([10, 20, 30, 99], dtype=torch.int64))
    input_buffers.is_padding[:4].fill_(False)
    input_buffers.query_start_loc[:5].copy_(torch.tensor([0, 1, 2, 3, -1], dtype=torch.int32))
    input_buffers.seq_lens[:4].copy_(torch.tensor([11, 21, 31, 99], dtype=torch.int32))
    if requests_already_padded:
        local_batch.num_reqs_after_padding = 4
        local_batch.query_start_loc = input_buffers.query_start_loc[:5]
        local_batch.query_start_loc_np = np.array([0, 1, 2, 3, 3], dtype=np.int32)
        local_batch.query_start_loc.copy_(torch.from_numpy(local_batch.query_start_loc_np))
        local_batch.seq_lens = input_buffers.seq_lens[:4]
        local_batch.seq_lens_cpu_upper_bound = torch.tensor([11, 21, 31, 0], dtype=torch.int32)

    manager = _make_replicated_pcp_manager()
    manager._input_buffers = input_buffers
    manager.vllm_config = _make_pcp_config(
        CUDAGraphMode.FULL_DECODE_ONLY,
        speculative_config=SimpleNamespace(num_speculative_tokens=3),
    )
    manager._hidden_restore_idx = torch.arange(4, dtype=torch.int64)
    # Upstream replace() preserves the global attention state.
    local_batch.attn_state = global_batch.attn_state
    batch_desc = BatchExecutionDescriptor(CUDAGraphMode.FULL_DECODE_ONLY, 4, None)

    with (
        patch.object(
            vllm_model_runner.pcp.PCPManager,
            "partition_batch",
            return_value=local_batch,
        ) as upstream_partition,
        patch(
            "vllm_ascend.worker.v2.pcp_manager.build_attn_state",
        ) as build_attn_state,
        patch(
            "vllm_ascend.worker.v2.pcp_manager.async_copy_to_gpu",
            side_effect=_mock_async_copy_to_cpu,
        ),
    ):
        result = _partition_batch(manager, global_batch, padded_num_tokens=4, batch_desc=batch_desc)

    upstream_partition.assert_called_once_with(global_batch, batch_desc)
    assert result.num_reqs == 3
    assert result.num_reqs_after_padding == 4
    assert result.num_tokens == 3
    assert result.num_tokens_after_padding == 4
    assert torch.equal(result.query_start_loc, torch.tensor([0, 1, 2, 3, 4], dtype=torch.int32))
    np.testing.assert_array_equal(result.query_start_loc_np, np.array([0, 1, 2, 3, 4], dtype=np.int32))
    assert torch.equal(result.seq_lens, torch.tensor([11, 21, 31, 0], dtype=torch.int32))
    np.testing.assert_array_equal(result.seq_lens_np, np.array([11, 21, 31, 0], dtype=np.int32))
    assert torch.equal(result.seq_lens_cpu_upper_bound, torch.tensor([11, 21, 31, 0], dtype=torch.int32))
    assert torch.equal(result.input_ids, torch.tensor([101, 102, 103, 0], dtype=torch.int32))
    assert torch.equal(result.positions, torch.tensor([10, 20, 30, 0], dtype=torch.int64))
    assert torch.equal(result.is_padding, torch.tensor([False, False, False, True]))
    assert result.attn_state == global_batch.attn_state
    build_attn_state.assert_not_called()


def test_partition_batch_keeps_piecewise_request_extent():
    """Token padding in PIECEWISE mode must not create dummy requests."""
    batch = _make_local_pcp_batch()
    batch.num_reqs = 2
    batch.num_reqs_after_padding = 2
    batch.num_tokens = 2
    batch.num_tokens_after_padding = 4
    batch.num_scheduled_tokens = np.ones(2, dtype=np.int32)
    batch.num_computed_tokens_np = np.array([10, 20], dtype=np.int32)
    batch.is_prefilling_np = np.zeros(2, dtype=np.bool_)
    batch.query_start_loc = torch.tensor([0, 1, 2], dtype=torch.int32)
    batch.query_start_loc_np = np.array([0, 1, 2], dtype=np.int32)

    manager = _make_replicated_pcp_manager()
    manager._input_buffers = None
    manager.vllm_config = _make_pcp_config(
        CUDAGraphMode.PIECEWISE,
        speculative_config=SimpleNamespace(num_speculative_tokens=3),
    )
    batch_desc = BatchExecutionDescriptor(CUDAGraphMode.PIECEWISE, 4, None)

    with (
        patch.object(
            vllm_model_runner.pcp.PCPManager,
            "partition_batch",
            return_value=batch,
        ) as upstream_partition,
        patch("vllm_ascend.worker.v2.pcp_manager.build_attn_state"),
    ):
        result = _partition_batch(manager, batch, padded_num_tokens=4, batch_desc=batch_desc)

    upstream_partition.assert_called_once_with(batch, batch_desc)
    assert result.num_reqs_after_padding == 2
    assert torch.equal(result.query_start_loc, torch.tensor([0, 1, 2], dtype=torch.int32))
    np.testing.assert_array_equal(result.query_start_loc_np, np.array([0, 1, 2], dtype=np.int32))
    np.testing.assert_array_equal(result.seq_lens_np, np.array([11, 21], dtype=np.int32))


@pytest.mark.parametrize("dcp_world_size", [1, 2])
@pytest.mark.parametrize("is_prefilling", [False, True])
def test_attention_context_collects_global_pcp_data(dcp_world_size, is_prefilling):
    manager = AscendPCPManager.__new__(AscendPCPManager)
    manager.device = torch.device("cpu")
    manager.dcp_world_size = dcp_world_size
    input_batch = _make_local_pcp_batch()
    input_batch.idx_mapping_np = np.array([7, 3, -1, -1], dtype=np.int32)
    input_batch.idx_mapping = torch.from_numpy(input_batch.idx_mapping_np)
    input_batch.num_reqs_after_padding = 4
    input_batch.is_prefilling_np[:] = is_prefilling
    block_tables = (
        torch.tensor([[1], [2], [0], [0]], dtype=torch.int32),
        torch.tensor([[3], [4], [0], [0]], dtype=torch.int32),
    )
    slot_mapping_capacity = input_batch.num_tokens_after_padding + 3
    global_slot_mappings = torch.arange(
        len(block_tables) * slot_mapping_capacity,
        dtype=torch.int64,
    ).view(len(block_tables), slot_mapping_capacity)
    gather_block_tables = MagicMock(return_value=block_tables)
    num_blocks = np.arange(16, dtype=np.int32).reshape(2, 8)
    manager._global_batch = input_batch
    manager._local_batch = SimpleNamespace(
        num_reqs=3,
        num_tokens=input_batch.num_tokens,
        num_tokens_after_padding=input_batch.num_tokens_after_padding,
        idx_mapping_np=np.array([3, 3, 7], dtype=np.int32),
    )
    manager._local_gather_idx = torch.arange(input_batch.num_tokens + 3, dtype=torch.int64)
    manager._block_tables = SimpleNamespace(
        gather_block_tables=gather_block_tables,
        num_blocks=SimpleNamespace(np=num_blocks),
    )
    manager._global_batch_slot_mappings = global_slot_mappings
    hidden_restore_idx = torch.arange(input_batch.num_tokens, dtype=torch.int64)
    manager._hidden_restore_idx = hidden_restore_idx
    manager._padded_gather_idx = None
    manager._gathered_kv_write_mask = None

    actual = manager.build_attention_context()

    if dcp_world_size > 1 and is_prefilling:
        assert actual.global_block_table_num_blocks.device == manager.device
        torch.testing.assert_close(
            actual.global_block_table_num_blocks, torch.tensor([[7, 3], [15, 11]], dtype=torch.int32)
        )
        num_blocks.fill(0)
        assert actual.global_block_table_num_blocks[0, 0] == 7
        assert actual.local_to_global_req_indices == (1, 1, 0)
    else:
        assert actual.global_block_table_num_blocks is None
        assert actual.local_to_global_req_indices is None
    assert actual.global_batch is input_batch
    assert actual.global_block_tables is block_tables
    assert torch.equal(
        actual.global_slot_mappings,
        global_slot_mappings[:, : input_batch.num_tokens_after_padding],
    )
    assert actual.hidden_restore_idx is hidden_restore_idx
    torch.testing.assert_close(actual.local_token_indices, manager._local_gather_idx[: input_batch.num_tokens])
    gather_block_tables.assert_called_once_with(
        input_batch.idx_mapping,
        input_batch.num_reqs_after_padding,
    )


def test_prepare_slot_mappings_pads_each_pcp_rank_for_full_decode_graph() -> None:
    manager = _make_replicated_pcp_manager()
    manager.pcp_world_size = 2
    manager._global_batch = SimpleNamespace(
        num_tokens_after_padding=8,
        num_tokens=4,
        is_prefilling_np=np.array([False, False, False, False]),
    )
    manager._gathered_kv_slot_mappings = torch.full((1, 16), -99, dtype=torch.int64)
    compact_slot_mappings = manager._gathered_kv_slot_mappings[:, :8]
    compact_slot_mappings.copy_(torch.tensor([[10, 11, 12, 13, 20, 21, 22, 23]]))

    with patch.object(vllm_model_runner.pcp.PCPManager, "prepare_slot_mappings", return_value=compact_slot_mappings):
        result = manager.prepare_slot_mappings()

    expected = torch.tensor([[10, 11, 12, 13, -1, -1, -1, -1, 20, 21, 22, 23, -1, -1, -1, -1]])
    assert torch.equal(result, expected)


def test_partition_batch_preserves_fia_dummy_layout() -> None:
    global_batch = _make_global_pcp_batch()
    global_batch.req_ids = ["decode-req"]
    global_batch.num_scheduled_tokens = np.array([1], dtype=np.int32)
    global_batch.num_tokens = 1
    global_batch.num_reqs_after_padding = 2
    global_batch.num_tokens_after_padding = 4
    global_batch.query_start_loc_np = np.array([0, 1, 4], dtype=np.int32)
    global_batch.query_start_loc = torch.tensor(
        [0, 1, 4],
        dtype=torch.int32,
    )
    global_batch.num_computed_tokens_np = np.array([10], dtype=np.int32)
    global_batch.prefill_len_np = np.array([10], dtype=np.int32)
    global_batch.num_computed_prefill_tokens_np = np.array(
        [10],
        dtype=np.int32,
    )
    global_batch.is_prefilling_np = np.array([False])
    global_batch.seq_lens = torch.tensor([11, 999], dtype=torch.int32)
    global_batch.seq_lens_cpu_upper_bound = torch.tensor(
        [11],
        dtype=torch.int32,
    )
    global_batch.input_ids[:4].copy_(torch.tensor([101, 999, 999, 999], dtype=torch.int32))
    global_batch.positions[:4].copy_(torch.tensor([10, 999, 999, 999], dtype=torch.int64))
    global_batch.is_padding[:4].fill_(False)

    req_states = SimpleNamespace(
        last_sampled_tokens=torch.zeros(2, dtype=torch.int64),
        prefill_len=SimpleNamespace(gpu=torch.zeros(2, dtype=torch.int32)),
        draft_tokens=torch.empty((2, 0), dtype=torch.int64),
    )
    manager = _ReplicatedPCPManager(
        pcp_world_size=2,
        pcp_rank=0,
        device=torch.device("cpu"),
        req_states=req_states,
        max_num_reqs=2,
        max_num_tokens=4,
    )
    # PIECEWISE pads tokens without padding requests, so the request-shaped
    # metadata must stay at the global batch's request extent.
    manager.vllm_config = _make_pcp_config(
        CUDAGraphMode.PIECEWISE,
        speculative_config=SimpleNamespace(num_speculative_tokens=3),
    )
    input_buffers = manager._input_buffers
    assert input_buffers is not None
    input_buffers.positions[0] = 10
    input_buffers.seq_lens[0] = 11

    with (
        patch(
            "vllm.v1.worker.gpu.pcp_manager.async_tensor_h2d",
            side_effect=_mock_async_copy_to_cpu,
        ),
        patch(
            "vllm_ascend.worker.v2.pcp_manager.async_copy_to_gpu",
            side_effect=_mock_async_copy_to_cpu,
        ),
        patch(
            "vllm_ascend.worker.v2.pcp_manager.build_attn_state",
            return_value=object(),
        ),
    ):
        local_batch = _partition_batch(manager, global_batch)

    assert local_batch.num_reqs == 1
    assert local_batch.num_reqs_after_padding == 2
    assert local_batch.num_tokens == 1
    assert local_batch.num_tokens_after_padding == 4
    expected_query_start_loc = np.array([0, 1, 4], dtype=np.int32)
    np.testing.assert_array_equal(
        local_batch.query_start_loc_np,
        expected_query_start_loc,
    )
    torch.testing.assert_close(
        local_batch.query_start_loc,
        torch.from_numpy(expected_query_start_loc),
    )
    assert local_batch.input_ids.tolist() == [101, 0, 0, 0]
    assert local_batch.positions.tolist() == [10, 0, 0, 0]
    assert local_batch.seq_lens.tolist() == [11, 0]
    np.testing.assert_array_equal(
        local_batch.seq_lens_np,
        np.array([11, 0], dtype=np.int32),
    )
    assert local_batch.seq_lens_cpu_upper_bound.tolist() == [11, 0]
    assert local_batch.is_padding.tolist() == [False, True, True, True]
    assert manager._hidden_restore_idx is not None
    assert manager._hidden_restore_idx[1:4].tolist() == [0, 0, 0]


@pytest.mark.parametrize("pcp_rank", [0, 1])
def test_partition_batch_preserves_speculative_target_inputs(pcp_rank) -> None:
    from vllm_ascend.attention.attention_v1 import AscendAttentionState
    from vllm_ascend.worker.v2.attn_utils import build_attn_state

    config = _make_pcp_config(CUDAGraphMode.NONE)
    config.speculative_config = SimpleNamespace(method="mtp")
    config.model_config.runner_type = "generate"
    config.scheduler_config = SimpleNamespace(enable_chunked_prefill=False)
    buffers = AscendInputBuffers(2, 5, torch.device("cpu"))
    base = InputBatch.make_dummy(2, 5, buffers, max_query_len=3)
    global_batch = AscendInputBatch(**base.__dict__, seq_lens_np=np.array([12, 23], dtype=np.int32))
    global_batch.is_dummy = False
    global_batch.req_ids = ["spec-a", "spec-b"]
    global_batch.input_ids.copy_(torch.tensor([101, 102, 201, 202, 203], dtype=torch.int32))
    global_batch.positions.copy_(torch.tensor([10, 11, 20, 21, 22], dtype=torch.int64))
    global_batch.num_scheduled_tokens = np.array([2, 3], dtype=np.int32)
    global_batch.query_start_loc_np = np.array([0, 2, 5], dtype=np.int32)
    global_batch.query_start_loc.copy_(torch.tensor([0, 2, 5], dtype=torch.int32))
    global_batch.num_computed_tokens_np = np.array([10, 20], dtype=np.int32)
    global_batch.prefill_len_np = np.array([10, 20], dtype=np.int32)
    global_batch.num_computed_prefill_tokens_np = np.array([10, 20], dtype=np.int32)
    global_batch.is_prefilling_np = np.array([False, False])
    global_batch.has_prefill = False
    global_batch.seq_lens.copy_(torch.tensor([12, 23], dtype=torch.int32))
    global_batch.num_draft_tokens = 3
    global_batch.num_draft_tokens_per_req = np.array([1, 2], dtype=np.int32)
    global_batch.attn_state = build_attn_state(
        config, global_batch.seq_lens_np, 2, global_batch.num_scheduled_tokens, np.ones(2, dtype=np.int32)
    )
    manager = _ReplicatedPCPManager(2, pcp_rank, torch.device("cpu"), max_num_reqs=2, max_num_tokens=5)
    manager.vllm_config = config

    with (
        patch("vllm.v1.worker.gpu.pcp_manager.async_tensor_h2d", side_effect=_mock_async_copy_to_cpu),
        patch("vllm_ascend.worker.v2.pcp_manager.build_attn_state") as recompute,
    ):
        result = _partition_batch(manager, global_batch)

    assert manager.global_batch is global_batch
    assert global_batch.num_draft_tokens == 3
    np.testing.assert_array_equal(global_batch.num_draft_tokens_per_req, np.array([1, 2], dtype=np.int32))
    assert result.req_ids == global_batch.req_ids
    torch.testing.assert_close(result.input_ids, global_batch.input_ids)
    torch.testing.assert_close(result.positions, global_batch.positions)
    np.testing.assert_array_equal(result.num_scheduled_tokens, np.array([2, 3], dtype=np.int32))
    np.testing.assert_array_equal(result.seq_lens_np, np.array([12, 23], dtype=np.int32))
    assert result.num_draft_tokens == 0
    assert result.num_draft_tokens_per_req is None
    assert result.attn_state == global_batch.attn_state == AscendAttentionState.ChunkedPrefill
    recompute.assert_not_called()


def test_request_state_cpu_and_numpy_tokens_share_storage() -> None:
    def init_base_state(
        state,
        max_num_reqs,
        max_model_len,
        max_num_batched_tokens,
        num_speculative_steps,
        vocab_size,
        device,
        use_dense_all_token_ids=False,
    ) -> None:
        state.max_num_reqs = max_num_reqs
        state.num_computed_tokens_np = np.zeros(max_num_reqs, dtype=np.int32)

    with patch.object(
        states_module.RequestState,
        "__init__",
        init_base_state,
    ):
        state = states_module.AscendRequestState(
            max_num_reqs=2,
            max_model_len=16,
            max_num_batched_tokens=16,
            num_speculative_steps=1,
            vocab_size=32,
            device=torch.device("cpu"),
        )

    assert state.num_computed_tokens_cpu.data_ptr() == state.num_computed_tokens_np.ctypes.data
    state.num_computed_tokens_np[0] = 17
    assert state.num_computed_tokens_cpu[0].item() == 17
    state.num_computed_tokens_cpu[1] = 23
    assert state.num_computed_tokens_np[1] == 23


@pytest.mark.parametrize("is_draft_prefill_sharded", [False, True], ids=["replicated", "sharded"])
def test_sampling_restore_exposes_unpadded_global_view(is_draft_prefill_sharded: bool) -> None:
    manager = AscendPCPManager.__new__(AscendPCPManager)
    manager._is_draft_prefill_sharded = is_draft_prefill_sharded
    batch = _make_global_pcp_batch()
    batch.is_dummy = False
    batch.num_tokens = 12
    batch.num_tokens_after_padding = 16
    batch.query_start_loc_np = np.array([0, 12, 16], dtype=np.int32)
    batch.query_start_loc = torch.tensor([0, 12, 16], dtype=torch.int32)
    manager._global_batch = batch
    hidden_states = torch.arange(32).reshape(16, 2)
    local_aux = [torch.zeros(8, 2)]

    def parent_restore(self, hidden, aux):
        restored_aux = None if aux is None else [hidden_states for _ in aux]
        return hidden_states, restored_aux, batch

    with (
        patch.object(AscendPCPManager, "_restore_unpadded_global_batch", return_value=True),
        patch.object(PCPManager, "restore_for_sampling", autospec=True, side_effect=parent_restore) as parent,
    ):
        # vLLM #57980 threads aux_hidden_states through this hook.
        restored_hidden, restored_aux, restored_batch = manager.restore_for_sampling(torch.zeros(8, 2), local_aux)
    assert len(restored_aux) == 1
    if is_draft_prefill_sharded:
        # Sharded drafts consume aux states next to the local last hidden states.
        assert parent.call_args.args[2] is None
        assert restored_aux is local_aux
    else:
        assert restored_aux[0].shape == (12, 2)
        assert restored_aux[0].data_ptr() == hidden_states.data_ptr()
    assert manager._sampling_global_batch is restored_batch
    assert restored_batch is not batch
    assert restored_batch.num_tokens_after_padding == 12
    assert restored_batch.query_start_loc.tolist() == [0, 12]
    assert restored_batch.query_start_loc_np.tolist() == [0, 12]
    assert restored_hidden.shape == (12, 2)
    assert restored_hidden.data_ptr() == hidden_states.data_ptr()
    assert batch.num_tokens_after_padding == 16
    assert batch.query_start_loc.tolist() == [0, 12, 16]


def test_pcp_manager_preserves_unpadded_restored_hidden_states() -> None:
    manager = AscendPCPManager.__new__(AscendPCPManager)
    manager._global_batch = SimpleNamespace(num_tokens=6, num_tokens_after_padding=6)
    restored_hidden_states = torch.randn(6, 2)

    with (
        patch(
            "vllm_ascend.worker.v2.pcp_manager.get_pp_group",
            return_value=SimpleNamespace(is_last_rank=True),
        ),
        patch.object(PCPManager, "restore_hidden_states", return_value=restored_hidden_states),
    ):
        result = manager.restore_hidden_states(torch.randn(3, 2))

    assert result is restored_hidden_states


@pytest.mark.parametrize("strided", [False, True])
def test_pcp_hidden_restore_preserves_values_and_collective_layout(strided):
    manager = AscendPCPManager.__new__(AscendPCPManager)
    manager._global_batch = SimpleNamespace(num_tokens=6, num_tokens_after_padding=6)
    manager._hidden_restore_idx = torch.tensor([0, 3, 1, 4, 2, 5])
    hidden_states = torch.arange(24).reshape(3, 8)[:, ::2]
    if not strided:
        hidden_states = hidden_states.contiguous()

    def all_gather(value, dim):
        assert value.is_contiguous(), "HCCL requires contiguous inputs"
        torch.testing.assert_close(value, hidden_states)
        if not strided:
            assert value.data_ptr() == hidden_states.data_ptr()
        return torch.cat([value, value + 100], dim=dim)

    with (
        patch("vllm_ascend.worker.v2.pcp_manager.get_pp_group", return_value=SimpleNamespace(is_last_rank=True)),
        patch("vllm.v1.worker.gpu.pcp_manager.get_pcp_group", return_value=SimpleNamespace(all_gather=all_gather)),
    ):
        restored = manager.restore_hidden_states(hidden_states)
    expected = torch.cat([hidden_states, hidden_states + 100])[manager._hidden_restore_idx]
    torch.testing.assert_close(restored, expected)


def test_pcp_manager_skips_hidden_restore_before_last_pp_rank() -> None:
    manager = AscendPCPManager.__new__(AscendPCPManager)
    hidden_states = torch.randn(2, 4)

    with (
        patch(
            "vllm_ascend.worker.v2.pcp_manager.get_pp_group",
            return_value=SimpleNamespace(is_last_rank=False),
        ),
        patch.object(PCPManager, "restore_hidden_states") as parent_restore,
    ):
        restored_hidden_states = manager.restore_hidden_states(hidden_states)

    assert restored_hidden_states is hidden_states
    parent_restore.assert_not_called()


@pytest.mark.parametrize("method", ["mtp", "eagle3", "dspark", "dflash"])
@pytest.mark.parametrize("draft_sample_method", ["greedy", "probabilistic"])
@pytest.mark.parametrize(
    ("cudagraph_mode", "sparse_mla"),
    [(CUDAGraphMode.NONE, False), (CUDAGraphMode.NONE, True), (CUDAGraphMode.FULL_DECODE_ONLY, True)],
)
def test_validate_config_allows_supported_speculators(
    method: str, draft_sample_method: str, cudagraph_mode: CUDAGraphMode, sparse_mla: bool
) -> None:
    speculative_config = SimpleNamespace(
        method=method,
        draft_sample_method=draft_sample_method,
    )
    vllm_config = _make_pcp_config(cudagraph_mode, sparse_mla=sparse_mla)
    vllm_config.speculative_config = speculative_config

    AscendPCPManager.validate_config(
        vllm_config,
        supports_mm_inputs=False,
    )


@pytest.mark.parametrize(
    ("method", "draft_sample_method", "error"),
    [
        ("draft_model", "greedy", "supports speculative decoding only with"),
    ],
)
def test_validate_config_rejects_unsupported_speculator_options(
    method: str,
    draft_sample_method: str,
    error: str,
) -> None:
    vllm_config = _make_pcp_config(CUDAGraphMode.NONE, sparse_mla=False)
    vllm_config.speculative_config = SimpleNamespace(
        method=method,
        draft_sample_method=draft_sample_method,
    )

    with pytest.raises(NotImplementedError, match=error):
        AscendPCPManager.validate_config(vllm_config, supports_mm_inputs=False)


def test_main2main_v2_overrides_accept_new_upstream_keywords() -> None:
    """Lock the keyword contracts added by vLLM #53694 and #53869."""
    # vLLM #60754 renamed `dp_sync` -> `dp_sync_state` on main.
    dp_sync_param = "dp_sync_state"
    for speculator_cls in (
        AscendTargetDependentARSpeculator,
        AscendDFlashSpeculator,
        AscendDSparkSpeculator,
    ):
        assert dp_sync_param in signature(speculator_cls.propose).parameters
    assert "pcp_manager" in signature(ModelAclGraphManager.capture).parameters


def test_main_pcp_capture_block_tables_keep_runtime_storage() -> None:
    manager = AscendPCPManager.__new__(AscendPCPManager)
    local_block_tables = (
        torch.full((4, 8), 7, dtype=torch.int32),
        torch.full((4, 4), 9, dtype=torch.int32),
    )
    manager._local_block_tables = local_block_tables

    dummy_block_tables = manager.get_dummy_block_tables(2)

    assert len(dummy_block_tables) == len(local_block_tables)
    for dummy, runtime_table in zip(dummy_block_tables, local_block_tables):
        assert dummy.data_ptr() == runtime_table.data_ptr()
        assert torch.count_nonzero(dummy) == 0
        assert torch.count_nonzero(runtime_table[2:]) > 0


def test_mrv2_runner_registers_ascend_pcp_manager() -> None:
    runner = NPUModelRunner.__new__(NPUModelRunner)
    assert runner.pcp_manager_cls is AscendPCPManager


@pytest.mark.parametrize("is_last_pp_rank", [False, True])
def test_sample_tokens_leaves_pcp_batch_selection_to_upstream(
    is_last_pp_rank: bool,
) -> None:
    runner = NPUModelRunner.__new__(NPUModelRunner)
    manager = AscendPCPManager.__new__(AscendPCPManager)
    local_batch = _make_local_pcp_batch()
    global_batch = _make_global_pcp_batch()
    manager._global_batch = global_batch
    runner.pcp_manager = manager
    runner.is_last_pp_rank = is_last_pp_rank
    runner.speculator = None
    # Dump contract from the production initializer; helpers no-op on None.
    runner.debugger = None
    runner._debugger_started = False
    runner.prompt_logprobs_worker = None
    # Optional state fields differ between supported vLLM revisions.
    state_kwargs: dict = {
        field: None
        for field in ("dp_sync", "dp_sync_state", "cudagraph_stats", "routed_experts")
        if field in vllm_model_runner.ExecuteModelState._fields
    }
    if "num_spec_tokens_to_schedule" in vllm_model_runner.ExecuteModelState._fields:
        state_kwargs["num_spec_tokens_to_schedule"] = 0
    runner.execute_model_state = vllm_model_runner.ExecuteModelState(
        input_batch=local_batch,
        attn_metadata=None,
        slot_mappings_by_layer=None,
        hidden_states=None,
        aux_hidden_states=None,
        finished_req_ids=set(),
        ec_connector_output=None,
        **state_kwargs,
    )
    grammar_output = object()
    expected_output = object()

    with patch.object(
        vllm_model_runner.GPUModelRunner,
        "sample_tokens",
        return_value=expected_output,
    ) as parent_sample_tokens:
        actual_output = runner.sample_tokens(grammar_output)

    # Upstream sample_tokens selects pcp_manager.global_batch on non-last PP
    # ranks and restore_for_sampling's batch on the last one.
    assert runner.execute_model_state.input_batch is local_batch
    assert actual_output is expected_output
    parent_sample_tokens.assert_called_once_with(grammar_output)


def test_partition_batch_clears_padded_dcp_local_seq_lens() -> None:
    manager = _make_replicated_pcp_manager()
    manager.vllm_config = _make_pcp_config(
        CUDAGraphMode.FULL_DECODE_ONLY,
        speculative_config=SimpleNamespace(num_speculative_tokens=3),
    )
    manager._input_buffers = AscendInputBuffers(
        max_num_reqs=8,
        max_num_tokens=16,
        device=torch.device("cpu"),
    )
    manager._input_buffers.dcp_local_seq_lens.fill_(777)
    manager._input_buffers.dcp_local_seq_lens[:2].copy_(torch.tensor([4, 5], dtype=torch.int32))
    manager._hidden_restore_idx = torch.arange(8, dtype=torch.int64)

    local_batch = _make_local_pcp_batch()
    local_batch.num_reqs = 2
    local_batch.num_tokens = 6
    local_batch.num_tokens_after_padding = 6
    local_batch.is_prefilling_np = np.array([False, False])
    local_batch.dcp_local_seq_lens = manager._input_buffers.dcp_local_seq_lens[:2]
    global_batch = SimpleNamespace(
        num_draft_tokens=0,
        num_tokens=6,
        num_tokens_after_padding=8,
        num_reqs_after_padding=8,
        query_start_loc_np=np.array([0, 1, 2, 2, 2, 2, 2, 2, 2], dtype=np.int32),
        is_prefilling_np=np.array([False, False]),
    )

    with (
        patch.object(
            vllm_model_runner.pcp.PCPManager,
            "partition_batch",
            return_value=local_batch,
        ),
        patch(
            "vllm_ascend.worker.v2.pcp_manager.build_attn_state",
            return_value=object(),
        ),
        patch(
            "vllm_ascend.worker.v2.pcp_manager.async_copy_to_gpu",
            side_effect=_mock_async_copy_to_cpu,
        ),
    ):
        result = _partition_batch(manager, global_batch)

    assert result.dcp_local_seq_lens is not None
    torch.testing.assert_close(
        result.dcp_local_seq_lens,
        torch.tensor([4, 5, 0, 0, 0, 0, 0, 0], dtype=torch.int32),
    )


@pytest.mark.parametrize(
    "dp_size,cudagraph_mode",
    [
        (2, CUDAGraphMode.NONE),
        (2, CUDAGraphMode.FULL_DECODE_ONLY),
        (2, CUDAGraphMode.PIECEWISE),
        (2, CUDAGraphMode.FULL_AND_PIECEWISE),
        (1, CUDAGraphMode.PIECEWISE),
    ],
)
def test_validate_config_pcp_dp_graph_modes(dp_size, cudagraph_mode):
    config = _make_pcp_config(cudagraph_mode, sparse_mla=False, data_parallel_size=dp_size)
    AscendPCPManager.validate_config(config, supports_mm_inputs=False)


@pytest.mark.parametrize("pcp_rank", [0, 1])
@pytest.mark.parametrize("has_stale_batch", [False, True])
def test_dummy_attention_context_uses_current_batch(pcp_rank, has_stale_batch):
    manager = _ReplicatedPCPManager(2, pcp_rank, torch.device("cpu"))
    # Exercise the replicated dummy layout explicitly.
    manager.vllm_config = _make_pcp_config(
        CUDAGraphMode.NONE,
        speculative_config=SimpleNamespace(num_speculative_tokens=3),
    )
    saved_batch = _make_global_pcp_batch() if has_stale_batch else None
    manager._global_batch = saved_batch
    manager._hidden_restore_idx = torch.tensor([99]) if has_stale_batch else None
    saved_indices = manager._hidden_restore_idx
    manager._block_tables = SimpleNamespace(gather_block_tables=MagicMock())
    manager._global_batch_slot_mappings = torch.full((2, 32), 99, dtype=torch.int64)
    dummy = _make_local_pcp_batch()
    dummy.is_dummy = True
    dummy.num_tokens = 4  # Exercise padding: the layout stride must still be 6.
    block_tables = (torch.zeros((2, 1), dtype=torch.int32),) * 2
    slot_mappings = torch.arange(24, dtype=torch.int64).reshape(2, 12)

    context = manager.build_attention_context(dummy, block_tables, slot_mappings)

    assert context.global_batch is dummy
    assert context.global_block_tables is block_tables
    start = pcp_rank * 6
    torch.testing.assert_close(context.global_slot_mappings, slot_mappings[:, start : start + 6])
    gathered_hidden = torch.arange(12).reshape(12, 1)
    torch.testing.assert_close(gathered_hidden[context.hidden_restore_idx], gathered_hidden[start : start + 6])
    assert manager._global_batch is saved_batch
    assert manager._hidden_restore_idx is saved_indices
    manager._block_tables.gather_block_tables.assert_not_called()


def test_capture_input_uses_upstream_staging_path():
    manager = AscendPCPManager(2, 0, torch.device("cpu"))
    input_batch = SimpleNamespace()
    staged_batch = _make_local_pcp_batch()

    stage_name = "prepare_inputs_for_capture_or_profile"
    with (
        patch.object(PCPManager, stage_name, return_value=staged_batch) as stage,
        patch.object(manager, "partition_batch") as partition,
    ):
        result = getattr(manager, stage_name)(input_batch)

    assert result is staged_batch
    stage.assert_called_once_with(input_batch)
    partition.assert_not_called()


@pytest.mark.parametrize(
    "counts,prefilling,expected",
    [
        ([44], [True], 22),
        ([18], [True], 10),
        ([1], [True], 1),
        ([4, 18], [False, True], 12),
        ([4, 4], [False, False], 4),
        ([18, 7], [True, True], 14),
        ([0], [False], 0),
    ],
)
def test_pcp_dispatch_counts_match_partition(counts, prefilling, expected):
    manager = AscendPCPManager(pcp_world_size=2, pcp_rank=0, device=torch.device("cpu"))
    manager.vllm_config = _make_pcp_config(CUDAGraphMode.NONE)
    assert manager.get_num_tokens_for_dispatch(np.array(counts), np.array(prefilling)) == expected


@pytest.mark.parametrize("slot_dtype", [torch.int32, torch.int64])
def test_pcp_slot_buffers_match_block_tables(slot_dtype):
    def init_buffers(manager, **kwargs):
        manager._global_batch_slot_mappings = torch.empty((1, 4), dtype=torch.int64)
        manager._gathered_kv_slot_mappings = torch.empty((1, 8), dtype=torch.int64)
        manager._pad_slot_id = torch.tensor(-1, dtype=torch.int64)
        manager.pcp_world_size = 2

    block_tables = SimpleNamespace(slot_mappings=torch.empty((1, 4), dtype=slot_dtype))
    with patch.object(PCPManager, "__init__", init_buffers):
        manager = AscendPCPManager(2, 0, torch.device("cpu"), block_tables=block_tables)

    assert manager._global_batch_slot_mappings.dtype == slot_dtype
    assert manager._gathered_kv_slot_mappings.dtype == slot_dtype
    manager._global_batch_slot_mappings.copy_(torch.tensor([[3200, 3201, -1, 3203]]))
    manager._padded_gather_idx = torch.tensor([3, 0, 1, 2])
    manager._gathered_kv_write_mask = torch.tensor([True, True, False, True])
    buffer_ptr = manager._gathered_kv_slot_mappings.data_ptr()

    gathered = manager._convert_to_gathered_slot_mappings(manager._global_batch_slot_mappings)
    assert gathered.tolist() == [[3203, 3200, -1, -1]]
    assert gathered.dtype == slot_dtype
    assert gathered.data_ptr() == buffer_ptr

    dummy = manager.get_dummy_slot_mappings(2)
    assert dummy.tolist() == [[-1, -1, -1, -1]]
    assert dummy.dtype == slot_dtype
    assert dummy.data_ptr() == buffer_ptr


@pytest.mark.parametrize("pcp_rank", [0, 7])
def test_speculative_decode_keeps_draft_tokens_on_pcp_ranks(pcp_rank):
    computed = 127
    batch = _make_global_pcp_batch()
    batch.num_tokens = batch.num_tokens_after_padding = 4
    batch.num_scheduled_tokens = np.array([4], dtype=np.int32)
    batch.query_start_loc_np = np.array([0, 4], dtype=np.int32)
    batch.query_start_loc.copy_(torch.tensor([0, 4], dtype=torch.int32))
    batch.num_computed_tokens_np = np.array([computed], dtype=np.int32)
    batch.prefill_len_np = np.array([computed], dtype=np.int32)
    batch.num_computed_prefill_tokens_np = np.array([computed], dtype=np.int32)
    batch.is_prefilling_np = np.array([False])
    batch.input_ids = torch.tensor([101, 0, 0, 0], dtype=torch.int32)
    batch.positions = torch.arange(computed, computed + 4, dtype=torch.int64)
    batch.is_padding = torch.zeros(4, dtype=torch.bool)
    batch.num_draft_tokens = 3
    batch.num_draft_tokens_per_req = np.array([3], dtype=np.int32)
    manager = _ReplicatedPCPManager(8, pcp_rank, torch.device("cpu"), max_num_reqs=1, max_num_tokens=32)
    manager.vllm_config = _make_pcp_config(CUDAGraphMode.FULL_DECODE_ONLY)
    manager.vllm_config.speculative_config = SimpleNamespace(num_speculative_tokens=3)
    with (
        patch("vllm.v1.worker.gpu.pcp_manager.async_tensor_h2d", side_effect=_mock_async_copy_to_cpu),
        patch("vllm_ascend.worker.v2.pcp_manager.build_attn_state"),
    ):
        local = _partition_batch(manager, batch)
    assert manager.get_num_tokens_for_dispatch(batch.num_scheduled_tokens, batch.is_prefilling_np) == 4
    # Replicated layouts keep the target verification tokens on every rank.
    assert local.num_tokens == 4
    assert local.req_ids == batch.req_ids
    assert batch.num_draft_tokens_per_req.tolist() == [3]
    assert batch.num_draft_tokens == 3
    assert local.num_draft_tokens_per_req is None
    assert local.num_draft_tokens == 0
    assert local.input_ids.tolist() == batch.input_ids.tolist()
    assert local.positions.tolist() == batch.positions.tolist()
    assert local.is_prefilling_np.tolist() == [False]
    assert manager._hidden_restore_idx[:4].tolist() == [0, 1, 2, 3]


@pytest.mark.parametrize("num_prefill_tokens", [1, 3, 7])
def test_short_prefill_leaves_empty_pcp_ranks_in_mixed_batch(num_prefill_tokens):
    manager = AscendPCPManager(8, 0, torch.device("cpu"))
    manager.vllm_config = _make_pcp_config(CUDAGraphMode.NONE)
    counts = np.array([4, 4, 4, num_prefill_tokens], dtype=np.int32)
    prefilling = np.array([False, False, False, True])
    for rank in range(8):
        chunks = list(manager._iter_rank_chunks(rank, counts, prefilling))
        expected = []
        if rank < 3:
            expected.append((rank, 0, 4))
        if rank < num_prefill_tokens:
            expected.append((3, rank, 1))
        assert chunks == expected
    assert manager.get_num_tokens_for_dispatch(counts, prefilling) == 5


def _hook_manager() -> AscendPCPManager:
    manager = AscendPCPManager.__new__(AscendPCPManager)
    manager.vllm_config = SimpleNamespace(
        parallel_config=ParallelConfig(prefill_context_parallel_size=2),
        speculative_config=SimpleNamespace(method="mtp"),
    )
    manager._staged_draft_inputs = None
    manager._sampling_global_batch = None
    manager.draft_prefill_batch = None
    return manager


@pytest.mark.parametrize("use_sampling_batch", [True, False])
def test_prepare_draft_prefill_accepts_unpadded_sampling_batch(use_sampling_batch: bool) -> None:
    manager = _hook_manager()
    manager._global_batch = object()
    manager._sampling_global_batch = object()
    batch = manager._sampling_global_batch if use_sampling_batch else object()
    input_ids = torch.arange(4)
    with patch.object(PCPManager, "prepare_draft_prefill") as parent:
        manager.prepare_draft_prefill(batch, input_ids)
    expected = manager._global_batch if use_sampling_batch else batch
    parent.assert_called_once_with(expected, input_ids)


@pytest.mark.parametrize("draft_pcp_size", [1, 2], ids=["replicated", "sharded"])
def test_is_target_attn_groups_excludes_draft_only_groups(draft_pcp_size) -> None:
    manager = _hook_manager()
    group = lambda *names: SimpleNamespace(layer_names=list(names))  # noqa: E731
    # Before a speculator is set, every group is a target group.
    assert manager.is_target_attn_groups([[group("mtp.layers.0")]])
    speculator = SimpleNamespace(
        draft_attn_layer_names={"mtp.layers.0"},
        vllm_config=SimpleNamespace(parallel_config=ParallelConfig(prefill_context_parallel_size=draft_pcp_size)),
    )
    manager.set_speculator(speculator)
    assert manager._is_draft_prefill_sharded == (draft_pcp_size > 1)
    # Target forwards and draft prefill capture use (possibly filtered) target groups.
    assert manager.is_target_attn_groups([[group("model.layers.0", "mtp.layers.0")], [group("model.layers.1")]])
    assert manager.is_target_attn_groups([[group("model.layers.1")]])
    # Draft decode metadata covers draft-only layers on the global batch.
    assert not manager.is_target_attn_groups([[group("mtp.layers.0")]])


def _get_draft_input_buffers(manager, buffers, num_tokens):
    """Both supported upstream versions return the MoE padding mask."""
    return manager.get_draft_input_buffers(buffers, num_tokens)[0]


def test_sharded_draft_prefill_handoff_across_pcp_ranks() -> None:
    """partition -> target -> restore_for_sampling -> draft prefill hooks.

    Two PCP ranks run the real upstream partition. The fake target and draft
    emit each token's global position, so restoration must recover the global
    order, and the staged draft inputs must be exactly the rank-local tokens.
    """
    world = 2
    managers, local_batches = [], []
    for rank in range(world):
        manager = _ReplicatedPCPManager(world, rank, torch.device("cpu"), max_num_reqs=4, max_num_tokens=32)
        manager.vllm_config = _make_pcp_config(CUDAGraphMode.NONE, speculative_config=SimpleNamespace(method="mtp"))
        global_batch = _make_global_pcp_batch()
        global_batch.is_dummy = False
        with (
            patch("vllm.v1.worker.gpu.pcp_manager.async_tensor_h2d", side_effect=_mock_async_copy_to_cpu),
            patch("vllm_ascend.worker.v2.pcp_manager.build_attn_state"),
            patch("vllm_ascend.worker.v2.pcp_manager.get_pp_group", return_value=SimpleNamespace(is_last_rank=True)),
        ):
            local_batches.append(_partition_batch(manager, global_batch))
        managers.append(manager)
    num_local_padded = local_batches[0].num_tokens_after_padding
    assert all(batch.num_tokens_after_padding == num_local_padded for batch in local_batches)

    def gather_from(per_rank):
        return SimpleNamespace(all_gather=lambda tensor, dim=0: torch.cat(per_rank, dim=0))

    # Target forward: hidden row = global position (padding rows are -1).
    target_hidden = [
        torch.where(batch.is_padding[:num_local_padded], -1, batch.positions[:num_local_padded]).float()[:, None]
        for batch in local_batches
    ]
    sampling_batches = []
    with (
        patch("vllm.v1.worker.gpu.pcp_manager.get_pcp_group", return_value=gather_from(target_hidden)),
        patch("vllm_ascend.worker.v2.pcp_manager.get_pp_group", return_value=SimpleNamespace(is_last_rank=True)),
    ):
        for manager, hidden in zip(managers, target_hidden):
            restored, _, batch = manager.restore_for_sampling(hidden, None)
            assert restored[:, 0].tolist() == list(range(18))
            sampling_batches.append(batch)

    draft_outputs = []
    staged_buffers = []
    for manager, batch, local in zip(managers, sampling_batches, local_batches):
        # Upstream propose: global draft inputs, then rank-local prefill.
        buffers = AscendInputBuffers(max_num_reqs=4, max_num_tokens=32, device=torch.device("cpu"))
        buffers.input_ids[:18].copy_(torch.arange(1000, 1018, dtype=buffers.input_ids.dtype))
        buffers.positions[:18].copy_(torch.arange(18, dtype=buffers.positions.dtype))
        assert _get_draft_input_buffers(manager, buffers, 18) is buffers
        global_ids, global_positions = buffers.input_ids.clone(), buffers.positions.clone()
        global_padding = buffers.is_padding.clone()
        ids_ptr = buffers.input_ids.data_ptr()
        manager.prepare_draft_prefill(batch, buffers.input_ids[: batch.num_tokens_after_padding])
        assert manager.draft_prefill_batch is local
        assert manager.draft_prefill_batch.num_tokens_after_padding == num_local_padded
        staged = _get_draft_input_buffers(manager, buffers, num_local_padded)
        assert staged is buffers
        assert staged.input_ids.data_ptr() == ids_ptr
        assert torch.equal(staged.is_padding[:num_local_padded], local.is_padding[:num_local_padded])
        real = ~local.is_padding[:num_local_padded]
        assert (staged.input_ids[:num_local_padded][real] - 1000).tolist() == (
            local.positions[:num_local_padded][real].tolist()
        )
        assert staged.positions[:num_local_padded].tolist() == local.positions[:num_local_padded].tolist()
        draft_outputs.append(staged.input_ids[:num_local_padded].float()[:, None].clone())
        staged_buffers.append((buffers, global_ids, global_positions, global_padding))

    with (
        patch("vllm.v1.worker.gpu.pcp_manager.get_pcp_group", return_value=gather_from(draft_outputs)),
        patch("vllm_ascend.worker.v2.pcp_manager.get_pp_group", return_value=SimpleNamespace(is_last_rank=True)),
    ):
        for manager, output, (buffers, global_ids, global_positions, global_padding) in zip(
            managers, draft_outputs, staged_buffers
        ):
            last, hidden = manager.restore_draft_prefill(output, output)
            assert last is hidden
            assert last[:, 0].tolist() == [float(1000 + i) for i in range(18)]
            assert manager.draft_prefill_batch is None
            # Draft decode reads the global positions again after prefill.
            assert torch.equal(buffers.input_ids, global_ids)
            assert torch.equal(buffers.positions, global_positions)
            assert torch.equal(buffers.is_padding, global_padding)
            assert manager._staged_draft_inputs is None


@pytest.mark.parametrize(
    ("dcp_size", "num_reqs"),
    [(2, 2), (1, 3)],
    ids=["pcp2_dcp2_replicated", "pcp2_dcp1_nonuniform_dummy"],
)
def test_draft_prefill_capture_accepts_draft_slot_mappings(dcp_size: int, num_reqs: int):
    """Draft-prefill capture stages its dummy through the PCP manager.

    The capture builds a target-group PCP context. Without the manager its
    slots would come from BlockTables as [G, T], which the dummy context
    path (replicated DCP>1 decode, or a non-uniform PIECEWISE dummy) views
    as [G, PCP, T] and fails on.
    """
    manager = AscendPCPManager(2, 0, torch.device("cpu"), max_num_reqs=4, max_num_tokens=16)
    vllm_config = _make_pcp_config(CUDAGraphMode.PIECEWISE, speculative_config=SimpleNamespace(method="mtp"))
    vllm_config.parallel_config.decode_context_parallel_size = dcp_size
    manager.vllm_config = vllm_config
    assert manager.is_decode_sharded == (dcp_size == 1)
    manager._draft_layer_names = frozenset({"draft.attn"})
    manager._local_block_tables = (torch.full((8, 4), 7, dtype=torch.int32),)
    manager._gathered_kv_slot_mappings = torch.full((1, 32), 5, dtype=torch.int64)
    state = AscendModelState.__new__(AscendModelState)
    state.pcp_manager = manager
    state.prepare_attn = lambda batch, _mode, tables, slots, groups, _kv, for_capture: (
        manager.build_attention_context(batch, tables, slots) if manager.is_target_attn_groups(groups) else None
    )
    target_attn_groups = [[SimpleNamespace(layer_names=["target.attn"])]]
    target_input_buffers = AscendInputBuffers(max_num_reqs=4, max_num_tokens=16, device=torch.device("cpu"))
    # The runner's BlockTables would hand out [G, T] dummy slots.
    block_tables = SimpleNamespace(cp_size=1, get_dummy_block_tables=MagicMock(), get_dummy_slot_mappings=MagicMock())
    graph_manager = AutoRegressiveAclGraphManager.__new__(AutoRegressiveAclGraphManager)
    graph_manager.is_draft_model_prefill = True
    graph_manager.speculator = None
    graph_manager.max_num_reqs = 4
    graph_manager.vllm_config = vllm_config
    forward_fn = MagicMock()
    desc = BatchExecutionDescriptor(CUDAGraphMode.PIECEWISE, 8, num_reqs)

    def capture_one(self, create_forward_fn, progress_bar_desc):
        create_forward_fn(desc, False)(CUDAGraphMode.PIECEWISE)

    with (
        patch("vllm_ascend.worker.v2.input_batch.update_cos_sin"),
        patch.object(aclgraph_module, "communicator_switch", nullcontext),
        patch.object(aclgraph_module, "model_capture_wrapper", lambda *_: nullcontext()),
        patch.object(aclgraph_module.CudaGraphManager, "capture", capture_one),
        patch.object(cudagraph_utils, "build_slot_mappings_by_layer", side_effect=lambda slots, _: slots),
    ):
        graph_manager.capture(
            forward_fn,
            state,
            target_input_buffers,
            block_tables,
            target_attn_groups,
            None,
            pcp_manager=manager,
        )

    block_tables.get_dummy_slot_mappings.assert_not_called()
    block_tables.get_dummy_block_tables.assert_not_called()
    num_reqs_arg, num_tokens_arg, context, slot_mappings, num_tokens_across_dp, cg_mode = forward_fn.call_args.args
    assert (num_reqs_arg, num_tokens_arg, num_tokens_across_dp, cg_mode) == (
        num_reqs,
        8,
        None,
        CUDAGraphMode.PIECEWISE,
    )
    assert slot_mappings.shape == (1, 16)
    assert context.global_slot_mappings.shape == (1, 8)
    assert context.global_block_tables[0].data_ptr() == manager._local_block_tables[0].data_ptr()
