# Adapt from https://github.com/vllm-project/vllm/blob/main/vllm/v1/worker/gpu/model_runner.py
# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
# Copyright (c) 2025 Huawei Technologies Co., Ltd. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# This file is a part of the vllm-ascend project.
#

import inspect
import logging
from collections.abc import Mapping
from contextlib import AbstractContextManager, contextmanager, nullcontext
from copy import deepcopy
from typing import Any

import numpy as np
import torch
from vllm.compilation import breakable_cudagraph
from vllm.config import VllmConfig
from vllm.config.compilation import CompilationMode, CUDAGraphMode
from vllm.distributed.kv_transfer import get_kv_transfer_group, has_kv_transfer_group
from vllm.distributed.parallel_state import get_pp_group
from vllm.distributed.utils import get_distributed_timeout_or_none
from vllm.logger import logger
from vllm.sequence import IntermediateTensors
from vllm.utils.torch_utils import async_tensor_h2d as async_copy_to_gpu
from vllm.v1.core.sched.output import SchedulerOutput
from vllm.v1.kv_cache_interface import KVCacheConfig, KVCacheSpec
from vllm.v1.worker.dp_utils import skip_dp_coordination
from vllm.v1.worker.gpu import model_runner as vllm_model_runner
from vllm.v1.worker.gpu.cudagraph_utils import BatchExecutionDescriptor
from vllm.v1.worker.gpu.eplb_utils import step_eplb_after
from vllm.v1.worker.gpu.input_batch import (
    combine_sampled_and_draft_tokens,
    expand_idx_mapping,
    prepare_pos_seq_lens,
    prepare_prefill_inputs,
)
from vllm.v1.worker.gpu.kv_connector import KVConnector
from vllm.v1.worker.gpu.model_runner import (
    BatchReqState,
    ExecuteModelState,
    GPUModelRunner,
)
from vllm.v1.worker.gpu.model_states.mamba_hybrid import MambaHybridModelState
from vllm.v1.worker.gpu.spec_decode.speculator import DraftModelSpeculator

from vllm_ascend.ascend_config import get_ascend_config
from vllm_ascend.ascend_forward_context import (
    MoECommType,
    get_mc2_tokens_capacity,
    override_mrv2_in_profile_run,
    select_moe_comm_method,
    set_mc2_mask,
    set_mc2_tokens_capacity,
)
from vllm_ascend.attention.attention_c8_mxfp import (
    AscendC8MXFPAttentionBackendImpl,
    fill_mxfp_v_scale_cache,
)
from vllm_ascend.attention.attention_v1 import AscendAttentionBackend
from vllm_ascend.attention.fa_v1 import AscendFlashAttentionBackend
from vllm_ascend.attention.flashmla import prepare_flashmla_batch_req_state
from vllm_ascend.attention.mla_v1 import AscendMLABackend
from vllm_ascend.core.kv_cache_interface import is_circular_kv_cache_spec
from vllm_ascend.distributed.kv_transfer.kv_p2p.sfa_pd_rd2h.dspark_context import (
    bind_dspark_context_receiver,
    configure_dspark_kv_transfer,
    find_dspark_context_connector,
    find_dspark_prefix_connector,
    get_pd_dspark_aux_layer_ids,
    send_dspark_prefill_kv,
)
from vllm_ascend.distributed.kv_transfer.kv_p2p.sfa_pd_rd2h.dspark_kv import (
    apply_dspark_resident_kv_specs,
    get_resident_dspark_layer_names,
)
from vllm_ascend.distributed.kv_transfer.kv_pool.ascend_store.layerwise.layerwise_cache_layout import (
    apply_layerwise_kv_cache_plan,
)
from vllm_ascend.distributed.kv_transfer.sparse_kv_offload.sparse_kv_offload_manager import (
    allocate_kv_offload_topk_profile_buffers,
    init_sparse_kv_offload_manager,
)
from vllm_ascend.hisparse.host_mirror import HostMirrorConnector, overlap_target_host_mirror
from vllm_ascend.models.deepseek_v41.cache_config import uses_a5_packed_cache
from vllm_ascend.observability.runtime_guard.hooks import (
    runtime_guard_sample_tokens,
    runtime_guard_step,
)
from vllm_ascend.observability.runtime_guard.processor import RuntimeGuardProcessor
from vllm_ascend.ops.rotary_embedding import set_cos_and_sin, update_cos_sin
from vllm_ascend.utils import (
    create_hccl_pg_options,
    enable_sfa_dcp_sharded_indexer,
    is_c8_mxfp_kv_quant,
    is_deepseek_v41,
    lmhead_tp_enable,
    lmhead_tp_max_num_logits,
    lmhead_tp_pad_rows,
    requires_lmhead_dp_sync,
    set_potential_max_tokens,
    should_skip_allreduce_across_dp_group,
    vllm_version_is,
)
from vllm_ascend.worker.device_metadata import TargetDeviceMetadata
from vllm_ascend.worker.utils import disable_compilation
from vllm_ascend.worker.v2.aclgraph_utils import ModelAclGraphManager
from vllm_ascend.worker.v2.attn_utils import (
    build_attn_state,
    skip_ring_state_update,
)
from vllm_ascend.worker.v2.eplb import AscendEPLBController
from vllm_ascend.worker.v2.input_batch import AscendInputBatch, AscendInputBuffers
from vllm_ascend.worker.v2.kv_connector import MambaCopyKVConnector
from vllm_ascend.worker.v2.kvpp import KVPPRuntime
from vllm_ascend.worker.v2.pcp_manager import AscendPCPManager
from vllm_ascend.worker.v2.pp_transport import resolve_spec_pp_support
from vllm_ascend.worker.v2.spec_decode import init_speculator
from vllm_ascend.worker.v2.states import AscendRequestState
from vllm_ascend.worker.v2.utils import (
    AscendV2KVBlockZeroer,
    C8KVBlockZeroer,
    communicator_switch,
    prepare_v41_dummy_ring_state,
    prepare_v41_source_rope,
    torch_cuda_wrapper,
)


class NPUModelRunner(GPUModelRunner):
    """Model runner for Ascend NPUs."""

    # vLLM #51718 overlays hybrid Attention/Mamba groups in one standardized
    # backing allocation. Ascend MRV2 preserves that allocation and exposes
    # backend-specific views; MLA may use a page-strided fused/component view.
    supports_standardized_shared_kv_backing = True

    execute_model_state: ExecuteModelState | None
    kv_connector: KVConnector
    max_num_reqs: int
    max_num_tokens: int

    def __init__(self, vllm_config: VllmConfig, device: torch.device):
        # Ascend-specific configurations
        self.ascend_config = get_ascend_config()
        self.sparse_kv_offload_manager = None
        self.kvpp = KVPPRuntime()
        # Adaptive verification uses this flag to apply FIA-specific query
        # boundary and sequence length padding during FULL graph execution.
        self.use_fia = False
        self._target_uses_flashmla = False
        # #56492: inherited dummy runs inspect this even on non-VMM platforms.
        self.extensible_kv_cache = None
        # FusedMoE can be constructed by the parent initializer and reads this
        # capacity while setting up MC2 communication.
        set_potential_max_tokens(vllm_config)
        parallel_config = vllm_config.parallel_config

        spec_pp_support = resolve_spec_pp_support(vllm_config)
        with torch_cuda_wrapper():
            super().__init__(vllm_config, device)
        if self.use_pp:
            assert self.pp_handler is not None
            old_broadcast_group = self.pp_handler.broadcast_group
            if torch.distributed.get_backend(old_broadcast_group) == "hccl":
                broadcast_group, _ = torch.distributed.new_subgroups_by_enumeration(
                    get_pp_group().group_ranks,
                    timeout=get_distributed_timeout_or_none(),
                    backend="hccl",
                    pg_options=create_hccl_pg_options("pp_broadcast"),
                    group_desc="pp_broadcast",
                )
                assert broadcast_group is not None
                self.pp_handler.broadcast_group = broadcast_group
                torch.distributed.destroy_process_group(old_broadcast_group)
        # These FIA models need post-rejection host counts on every PP stage.
        # TODO: Remove this extra PP sync when FIA and its metadata builders
        # use device lengths instead of exact CPU lengths.
        self.sync_spec_pp_cpu_counts = (
            self.use_pp
            and self.num_speculative_steps > 0
            and self.model_config.architecture
            in (
                "KimiLinearForCausalLM",
                "KimiK3ForCausalLM",
                "KimiK3ForConditionalGeneration",
                "Qwen3_5ForConditionalGeneration",
            )
        )
        # These draft heads consume target aux states collected across PP ranks.
        if spec_pp_support is not None and spec_pp_support.needs_aux_hidden_states:
            self.use_aux_hidden_state_outputs = True

        # Only a real split (size > 1) exchanges across ranks, and graph dispatch keeps it aligned.
        ftpc = self.ascend_config.finegrained_tp_config
        self._finegrained_tp_requires_graph = (
            ftpc.oproj_tensor_parallel_size > 1 or ftpc.mlp_tensor_parallel_size > 1
        ) and self.dp_size > 1

        self.use_aclgraph = (
            self.compilation_config.cudagraph_mode != CUDAGraphMode.NONE
            and (
                self.compilation_config.mode == CompilationMode.VLLM_COMPILE
                or (
                    breakable_cudagraph.is_breakable_cudagraph_enabled()
                    if vllm_version_is("0.33.0")
                    else breakable_cudagraph.is_breakable_cudagraph_enabled(self.compilation_config)
                )
            )
            and not self.model_config.enforce_eager
        )
        self.eplb = AscendEPLBController(
            parallel_config,
            device,
            self.ascend_config.eplb_config if parallel_config.enable_eplb else None,
        )

        self.update_stream = None
        if self.compilation_config.cudagraph_mode.has_full_cudagraphs():
            self.update_stream = torch.npu.Stream()

        # because we will override these attribute, delete these attribute to
        # make sure it's collected by python gc immediately.
        del self.req_states
        del self.input_buffers
        del self.speculator

        self.pd_dspark_aux_layer_ids: tuple[int, ...] = ()
        self._dspark_prefill_progress: dict[str, tuple[str, int]] = {}

        # AscendRequestState has extra `num_computed_tokens_cpu` attribute.
        # so reinitialize req_states here.
        self.req_states: AscendRequestState = AscendRequestState(
            max_num_reqs=self.max_num_reqs,
            max_model_len=self.max_model_len,
            max_num_batched_tokens=self.max_num_tokens,
            num_speculative_steps=self.num_speculative_steps,
            vocab_size=self.vocab_size,
            device=self.device,
            use_dense_all_token_ids=(
                self.speculative_config is not None and self.speculative_config.method in ("ngram", "ngram_gpu")
            ),
        )
        # The upstream speculator was constructed with the discarded upstream
        # request state. This construction does not use that speculator: it
        # binds n-gram to the new state and selects Ascend implementations for
        # model-based methods through the Ascend factory.
        self.speculator: Any = None
        if self.speculative_config is not None and self.is_last_pp_rank:
            self.speculator = init_speculator(self.vllm_config, self.device, self.req_states)
            # Share the update stream between the target and draft graph managers.
            self.speculator.update_stream = self.update_stream
        # AscendInputBuffers has extra `seq_lens_cpu` attribute.
        # so reinitialize input_buffers here.
        self.input_buffers: AscendInputBuffers = AscendInputBuffers(
            max_num_reqs=self.max_num_reqs,
            max_num_tokens=self.max_num_tokens,
            device=self.device,
        )

        # Pinned D2H staging for corrected device state after spec rejection.
        # The authoritative host state is the shared NumPy/torch RequestState view.
        self.num_computed_tokens_event = torch.npu.Event()
        self.num_computed_tokens_stream = torch.npu.Stream()
        self.num_computed_tokens_cpu = torch.empty(
            self.max_num_reqs,
            dtype=torch.int32,
            device="cpu",
            pin_memory=True,
        )

        # NOTE: In GPUModelRunner, decode_query_len is initialized in load_model(),
        # +1 is hardcoded here but not in vllm.
        self.decode_query_len = self.num_speculative_steps + 1
        # Set _mc2_tokens_capacity and _reserved_mc2_mask for MoE communication optimization.
        # TODO: remove set_cos_and_sin (together with update_cos_sin) when mla can properly handle cos/sin internally
        set_cos_and_sin(vllm_config, self.max_num_reqs, self.decode_query_len, self.dtype, self.device)
        set_mc2_tokens_capacity(vllm_config, self.max_num_reqs, self.decode_query_len)
        set_mc2_mask(vllm_config, self.device)
        set_potential_max_tokens(vllm_config)

        # msprobe dump (same as v1 NPUModelRunner; not via DFX).
        dump_cfg = self.ascend_config.dump_config_path
        self.debugger = None
        if dump_cfg is not None:
            self._debugger_started = False
            if self.compilation_config.cudagraph_mode == CUDAGraphMode.NONE:
                from msprobe.pytorch import PrecisionDebugger

                self.debugger = PrecisionDebugger(dump_cfg)
            else:
                try:
                    from msprobe.pytorch import AclGraphDumper
                except Exception as exc:
                    raise RuntimeError(
                        "Failed to import AclGraphDumper from msprobe. "
                        "Please install/rebuild msprobe with aclgraph_dump enabled."
                    ) from exc

                self.debugger = AclGraphDumper(dump_cfg)
        self.runtime_guard = RuntimeGuardProcessor.bind(self)

    @property
    def pcp_manager_cls(self) -> type[AscendPCPManager]:
        return AscendPCPManager

    def load_model(self, load_dummy_weights: bool = False, *args, **kwargs) -> None:
        from vllm_ascend.model_executor.warmup.nz_warmup import (
            join_nz_warm_thread,
            start_nz_warm_thread,
        )

        # Overlap the one-off NZ cast with weight I/O. Every model goes
        # through here.
        start_nz_warm_thread("thread")
        try:
            aux_layers = get_pd_dspark_aux_layer_ids(self.vllm_config)
            super().load_model(load_dummy_weights, *args, **kwargs)
            self.pd_dspark_aux_layer_ids = aux_layers
        finally:
            # Join even when weight loading fails: these threads touch the NPU
            # device and must not outlive this call. Joining here is also before
            # memory profiling.
            join_nz_warm_thread()

        # In cudagraph modes the dumper must be started before graph capture so
        # that aclgraph capture/replay is instrumented (v1 parity: v1 starts
        # the dumper at the end of load_model).
        if self.compilation_config.cudagraph_mode != CUDAGraphMode.NONE:
            self._start_dump_data()
        self.model_state.prompt_logprobs_worker = self.prompt_logprobs_worker

    @runtime_guard_sample_tokens
    def sample_tokens(self, grammar_output):
        if (
            lmhead_tp_enable()
            and self.prompt_logprobs_worker is not None
            and (
                self.prompt_logprobs_worker.uses_prompt_logprobs.any()
                or getattr(self.prompt_logprobs_worker, "token_id_scores", {})
            )
        ):
            # The prompt-logprobs worker issues a second compute_logits with
            # unpadded rows that desyncs the LM-head collectives and hangs.
            # vLLM #54335 adds fixed-token scoring through the same unpadded
            # compute_logits path, so it has the same collective restriction.
            raise NotImplementedError(
                "prompt logprobs and fixed-token prompt scoring are not supported with lmhead TP."
            )

        state = self.execute_model_state
        self._lmhead_pad_size = self._get_lmhead_pad_size(state) if state is not None and lmhead_tp_enable() else None
        output = super().sample_tokens(grammar_output)
        self._lmhead_pad_size = None
        # Close the per-step msprobe dump cycle on the normal last-PP-rank
        # path (v1 parity: v1 finalizes at the end of sample_tokens).
        self._finalize_dump_data()
        if isinstance(mirror := getattr(self, "kv_connector", None), HostMirrorConnector):
            mirror.join_pending()
        return output

    def pool(self):
        output = super().pool()
        # Pooling models never go through sample_tokens() in the v2
        # architecture: the worker calls pool() directly, and the engine skips
        # sampling whenever execute_model()/pool() returns a non-None output.
        # Close the dump cycle here, mirroring v1 which finalizes after
        # _pool() on the pooling path.
        self._finalize_dump_data()
        return output

    def get_kv_cache_spec(self) -> dict[str, KVCacheSpec]:
        kv_cache_spec = super().get_kv_cache_spec()

        return apply_dspark_resident_kv_specs(
            kv_cache_spec,
            self.vllm_config,
            self.speculator,
            sparse_offload_enabled=self.ascend_config.sparse_kv_offload_config.enabled,
            is_last_pp_rank=self.is_last_pp_rank,
            shared_kv_cache_layers=getattr(self, "shared_kv_cache_layers", None),
        )

    def _init_kv_zero_meta(self) -> None:
        """Use a tuple-aware zeroer for Ascend V1-compatible cache protocols."""
        offload_manager = getattr(self, "sparse_kv_offload_manager", None)
        excluded_cache_components = (
            offload_manager.get_topk_cache_components() if offload_manager is not None else set()
        )
        self.kv_block_zeroer = AscendV2KVBlockZeroer(
            self.device,
            attn_groups_iter=(g for groups in self.attn_groups for g in groups),
            kernel_block_sizes=self.kernel_block_sizes,
            static_forward_context=self.compilation_config.static_forward_context,
            num_blocks=self.kv_cache_config.num_blocks,
            cache_dtype=self.cache_config.cache_dtype,
            excluded_cache_components=excluded_cache_components,
        )
        if is_c8_mxfp_kv_quant(self.vllm_config):
            # The zeroer skips the static V scales (4th tuple component); the
            # wrapper restores them on pages reassigned from Mamba.
            self.kv_block_zeroer = C8KVBlockZeroer(  # type: ignore[assignment]
                self.kv_block_zeroer, self._c8_mxfp_v_scale_caches, fill_mxfp_v_scale_cache
            )

    def _initialize_kv_cache_upstream(
        self,
        kv_cache_config: KVCacheConfig,
        kv_cache_allocation_context: AbstractContextManager | None,
    ) -> None:
        # Upstream initialize_kv_cache builds the attention metadata builders
        # via init_attn_backend; the DSA builder registers its fused Q-RMS
        # JIT kernel during construction, so hold a registry window open
        # around the super() call (v1 parity; the v1 runner wraps its
        # initialize_metadata_builders instead). Runners built without the
        # upstream __init__ (tests, partial mocks) have no registry; the
        # window is optional for them.
        registry = getattr(self, "jit_warmup_registry", None)
        window = registry.activate() if registry is not None else nullcontext()
        with window:
            super().initialize_kv_cache(
                kv_cache_config,
                kv_cache_allocation_context=kv_cache_allocation_context,
            )

    def _has_target_flashmla_attention(self) -> bool:
        # Draft attention has its own graph dispatch. Only target layers may
        # restrict target batches containing decode-like PD prompt tails.
        draft_layer_names = getattr(self.speculator, "draft_attn_layer_names", ())
        return any(
            any(layer_name not in draft_layer_names for layer_name in group.layer_names)
            and getattr(group.get_metadata_builder(0), "flashmla_state", None) is not None
            for groups in self.attn_groups
            for group in groups
        )

    def initialize_kv_cache(
        self,
        kv_cache_config: KVCacheConfig,
        kv_cache_allocation_context: AbstractContextManager | None = None,
    ) -> None:
        # Match V1's physical buffer plan without mutating the scheduler's
        # logical cache configuration. Allocation must honor zero-stride aliases.
        kv_cache_config = deepcopy(kv_cache_config)
        sparse_cfg = self.ascend_config.sparse_kv_offload_config
        configure_dspark_kv_transfer(
            self.vllm_config, self.speculator, kv_cache_config, is_last_pp_rank=self.is_last_pp_rank
        )
        resident_draft_names = get_resident_dspark_layer_names(
            self.vllm_config,
            self.speculator,
            sparse_offload_enabled=sparse_cfg.enabled,
            is_last_pp_rank=self.is_last_pp_rank,
            shared_kv_cache_layers=getattr(self, "shared_kv_cache_layers", None),
        )
        # P also needs persistent prompt draft KV until D acknowledges its
        # transfer. It must never alias target layerwise scratch buffers.
        persistent_draft_names = resident_draft_names | set(getattr(kv_cache_config, "dspark_draft_layer_names", ()))
        apply_layerwise_kv_cache_plan(kv_cache_config, self.vllm_config, excluded_layer_names=persistent_draft_names)
        if sparse_cfg.enabled:
            self.sparse_kv_offload_manager = init_sparse_kv_offload_manager(
                self.vllm_config, kv_cache_config, sparse_cfg
            )
            self.model_state._offload_live_req_ids = self.req_states.req_id_to_index
            self.model_state._offload_draft_layer_names = (
                getattr(self.speculator, "draft_attn_layer_names", set[str]()) - resident_draft_names
                if sparse_cfg.use_fused_copy_sfa
                else set()
            )
        with graph_manager_wrapper(self):
            self._initialize_kv_cache_upstream(kv_cache_config, kv_cache_allocation_context)
            self._target_uses_flashmla = self._has_target_flashmla_attention()
            if self.pcp_manager is not None:
                assert isinstance(self.pcp_manager, AscendPCPManager)
                self.pcp_manager.set_runner_state(self.vllm_config, kv_cache_config, self.input_buffers)
                self.pcp_manager.decode_balance_policy = self.ascend_config.pcp_decode_balance_policy
                self.pcp_manager.decode_balance_token_factor = self.ascend_config.pcp_decode_balance_token_factor
                if isinstance(self.speculator, DraftModelSpeculator):
                    self.pcp_manager.set_speculator(self.speculator)
                self.model_state.pcp_manager = self.pcp_manager
        bind_dspark_context_receiver(
            self.vllm_config,
            sparse_offload_enabled=sparse_cfg.enabled,
            is_last_pp_rank=self.is_last_pp_rank,
            max_requests=self.max_num_reqs,
        )
        if sparse_cfg.enabled and self.speculator is not None:
            # Resident MLA DSpark has no host-pool LRU or LIM tail state.
            self.model_state._offload_draft_attn_groups = (
                [] if resident_draft_names else getattr(self.speculator, "attn_groups", [])
            )
        if any(is_circular_kv_cache_spec(group.kv_cache_spec) for group in self.kv_cache_config.kv_cache_groups):
            from vllm_ascend.models.deepseek_v41.compressor import DeepseekV41Compressor

            for module in self.model.modules():
                if isinstance(module, DeepseekV41Compressor) and module.ratio == 2:
                    module.prepare_ring_compressor(self.max_num_tokens, self.device)
        prepare_v41_source_rope(self)
        # Recreate along with KV initialization: profiling capture owns a
        # throwaway model state and must not leak event/buffer bindings.
        self.model_state.device_metadata = (
            TargetDeviceMetadata()
            if uses_a5_packed_cache()
            and (
                self.model_config.architecture == "DeepseekV41ForCausalLM"
                or (
                    self.model_config.architecture == "KimiK31ForConditionalGeneration"
                    and enable_sfa_dcp_sharded_indexer(self.vllm_config)
                    and self.vllm_config.attention_config.indexer_kv_dtype == "fp8"
                )
            )
            else None
        )

        # Register the exact bound state-copy layouts; kernel_warmup owns
        # compilation before model dummy runs and graph capture.
        from vllm_ascend.ops.kda_state_copy_plan import initialize_kda_state_copy

        registry = getattr(self, "jit_warmup_registry", None)
        with registry.activate() if registry is not None else nullcontext():
            initialize_kda_state_copy(
                self.vllm_config.compilation_config.static_forward_context,
                self.vllm_config.scheduler_config.max_num_seqs,
            )

        copy_mamba_state = getattr(self.model_state, "copy_state_after_kv_load", None)
        if (
            callable(copy_mamba_state)
            and has_kv_transfer_group()
            and getattr(get_kv_transfer_group(), "requires_mamba_state_copy_after_load", False)
        ):
            self.kv_connector = MambaCopyKVConnector(self.kv_connector, copy_mamba_state)

        initialize_cpu_lengths = getattr(self.model_state, "initialize_spec_cpu_length_sync", None)
        if callable(initialize_cpu_lengths):
            initialize_cpu_lengths(self)

        # Only target-model layers determine whether FIA is in use. This flag
        # is used for adaptive verification handling.
        draft_layer_names: set[str] = getattr(self.speculator, "draft_attn_layer_names", set())
        self.use_fia = any(
            (group.backend is AscendAttentionBackend or group.backend is AscendMLABackend)
            and any(layer_name not in draft_layer_names for layer_name in group.layer_names)
            for groups in self.attn_groups
            for group in groups
        )

        self.kvpp = KVPPRuntime.create_from_kv_cache(
            vllm_config=self.vllm_config,
            kv_cache_config=self.kv_cache_config,
            static_forward_context=self.compilation_config.static_forward_context,
        )
        self.model_state.kvpp_runtime = self.kvpp

        self._fill_c8_mxfp_v_scale_caches()
        if self.vllm_config.attention_config.hisparse_config is not None:
            self.kv_connector = overlap_target_host_mirror(self)

    def _fill_c8_mxfp_v_scale_caches(self) -> None:
        """Initialize C8 V scales and retain views for page reassignment."""
        self._c8_mxfp_v_scale_caches = []
        num_blocks = self.kv_cache_config.num_blocks
        if num_blocks <= 0:
            return
        for layer in self.compilation_config.static_forward_context.values():
            if isinstance(getattr(layer, "impl", None), AscendC8MXFPAttentionBackendImpl):
                value_scale_cache = layer.kv_cache[3]
                assert value_scale_cache.shape[0] % num_blocks == 0
                kernel_blocks_per_page = value_scale_cache.shape[0] // num_blocks
                self._c8_mxfp_v_scale_caches.append((layer.v_cache_scale, value_scale_cache, kernel_blocks_per_page))
                fill_mxfp_v_scale_cache(layer.v_cache_scale, value_scale_cache)

    def shutdown(self) -> None:
        model = getattr(self, "model", None)
        shared_embeddings = getattr(self, "_shared_engram_shutdown_pending", None) or (
            [module for module in model.modules() if getattr(module, "_shared_pool_client", None) is not None]
            if model is not None
            else []
        )
        # Drop C8 packet views before the parent collects tensors and
        # empties the allocator cache.
        entries = getattr(self, "_c8_mxfp_v_scale_caches", None)
        if entries is not None:
            entries.clear()
        zeroer = getattr(self, "kv_block_zeroer", None)
        if isinstance(zeroer, C8KVBlockZeroer):
            zeroer.entries.clear()
            self.kv_block_zeroer = zeroer.delegate
        self._shared_engram_shutdown_pending = shared_embeddings
        if not getattr(self, "_shared_engram_parent_stopped", False):
            super().shutdown()
            self._shared_engram_parent_stopped = True
        first_error = None
        for embedding in shared_embeddings:
            try:
                embedding.close_host_offload()
            except Exception as exc:
                if first_error is None:
                    first_error = exc
        if first_error is not None:
            raise first_error
        self._shared_engram_shutdown_pending = []

    def _register_sparse_kv_caches(self, kv_caches: dict[str, Any]) -> None:
        """Bind host pools before the V2 KV connector registers its destinations."""
        manager = self.sparse_kv_offload_manager
        if manager is None:
            return
        manager.register_kv_caches(kv_caches)
        if not self.ascend_config.sparse_kv_offload_config.use_fused_copy_sfa:
            return

        from vllm_ascend.attention.sfa_kv_offload import AscendSFAKVOffloadImpl

        owners: dict[int, AscendSFAKVOffloadImpl] = {}
        for layer in self.compilation_config.static_forward_context.values():
            impl = getattr(layer, "impl", None)
            if not isinstance(impl, AscendSFAKVOffloadImpl):
                continue
            shared = impl.topk_indices_buffer
            if shared is None:
                continue
            key = shared.data_ptr()
            if impl.skip_topk:
                if key not in owners:
                    raise RuntimeError("fused_copy_sfa shared attention precedes its indexer owner")
                impl.lim_indexer_owner = owners[key]
            else:
                owners[key] = impl
        for layer_name in manager.offload_layer_names:
            layer = self.compilation_config.static_forward_context[layer_name]
            layer.impl.bind_copy_sfa_kv_cache(manager, layer_name)

    @torch.inference_mode()
    def capture_model(self, *, profile_only: bool = False) -> int:
        """Capture decoder and multimodal encoder graphs on Ascend."""
        if hasattr(self, "model_state") and self.model_state.supports_mm_inputs:
            encoder_runner = getattr(self.model_state, "encoder_runner", None)
            encoder_manager = getattr(encoder_runner, "cudagraph_manager", None)
            if encoder_manager is not None and self.update_stream is not None:
                encoder_manager.update_stream = self.update_stream

        # EncoderRunner uses vLLM's generic graph_capture(), whose communicator
        # type check expects the CUDA symbol. Temporarily bind that symbol to
        # NPUCommunicator, as is already done for decoder ACL graph capture.
        with torch_cuda_wrapper(), communicator_switch():
            if "profile_only" not in inspect.signature(GPUModelRunner.capture_model).parameters:
                if profile_only:
                    raise NotImplementedError("Graph memory profiling is unavailable in this vLLM version.")
                return super().capture_model()
            return super().capture_model(profile_only=profile_only)

    # runtime_guard_step must stay INNER (below @torch.inference_mode()) so the
    # wave sync keeps running inside the inference-mode context.
    @torch.inference_mode()
    @runtime_guard_step
    def execute_model(
        self,
        scheduler_output: SchedulerOutput,
        intermediate_tensors: IntermediateTensors | None = None,
        dummy_run: bool = False,
        skip_attn_for_dummy_run: bool = False,
        is_profile: bool = False,
        context_len: int = 0,
        valid_dummy_state_slots: bool = False,
        randomize_inputs: bool = False,
    ):
        if isinstance(mirror := getattr(self, "kv_connector", None), HostMirrorConnector):
            mirror.begin_execution(not dummy_run and not is_profile)

        # Preemption stores must complete before the parent updates states and
        # reuses or zeroes the preempted requests' physical KV cache blocks.
        if has_kv_transfer_group():
            kv_connector_metadata = scheduler_output.kv_connector_metadata
            assert kv_connector_metadata is not None
            get_kv_transfer_group().handle_preemptions(kv_connector_metadata)

        dump_forward = dummy_run or scheduler_output.total_num_scheduled_tokens > 0
        # Eager PrecisionDebugger is started only for real scheduler steps.
        # Graph dumping is already active from load_model(), so dummy forwards
        # only need to flush the graph dumper below without writing a step.
        if dump_forward and not dummy_run:
            self._start_dump_data(scheduled_tokens=scheduler_output.num_scheduled_tokens)

        self.model_state.kvpp_is_dummy_run = dummy_run or is_profile
        # Reduced LMHead padding needs synchronized token buckets for V2,
        # DCP=1. Share the MC2 dispatcher's policy so active masks agree;
        # DCP>1 retains full capacity and the original coordination policy.
        # TODO: Merge the requires_lmhead_dp_sync interface into
        # should_skip_allreduce_across_dp_group in a future refactor.
        skip_dp_metadata_sync = should_skip_allreduce_across_dp_group(self.vllm_config) and not requires_lmhead_dp_sync(
            self.vllm_config
        )
        dp_coordination_context = skip_dp_coordination() if skip_dp_metadata_sync else nullcontext()
        profile_kwargs = {"randomize_inputs": randomize_inputs}
        forward_failed = True
        with dp_coordination_context, self._pcp_decode_plan_scope():
            try:
                output = super().execute_model(
                    scheduler_output,
                    intermediate_tensors=intermediate_tensors,
                    dummy_run=dummy_run,
                    skip_attn_for_dummy_run=skip_attn_for_dummy_run,
                    is_profile=is_profile,
                    context_len=context_len,
                    valid_dummy_state_slots=valid_dummy_state_slots,
                    **profile_kwargs,
                )
                forward_failed = False
            finally:
                finish_execution = getattr(self.model_state, "finish_execution", None)
                if finish_execution is not None:
                    finish_execution(failed=forward_failed)
        if not dummy_run and not is_profile:
            self._maybe_send_draft_kv(scheduler_output)
        self.model_state.kvpp_is_dummy_run = False
        if dummy_run and lmhead_tp_enable() and not is_profile and self.is_last_pp_rank:
            # Idle ranks join the same LMHead collective size as active ranks.
            if self.execute_model_state is None:
                raise RuntimeError(
                    "lmhead TP dummy join expects execute_model_state published by the upstream dummy execute_model."
                )
            dummy_indices = torch.zeros(
                self._get_lmhead_pad_size(self.execute_model_state),
                dtype=torch.int64,
                device=self.device,
            )
            self.model.compute_logits(self.execute_model_state.hidden_states[dummy_indices])
        self.kvpp.complete_forward()

        if dump_forward:
            if dummy_run:
                self._finalize_dump_data(dump=False)
            elif isinstance(output, IntermediateTensors) and self.is_pooling_model:
                # Non-last pooling ranks do not reach pool(). Decoding ranks
                # finalize after sample_tokens(), including non-last PP ranks.
                self._finalize_dump_data()

        return output

    def _maybe_send_draft_kv(self, scheduler_output: SchedulerOutput) -> None:
        """Write draft KV on P, then let D pull the exact allocated cache pages."""
        if not getattr(self, "pd_dspark_aux_layer_ids", ()) or not self.is_last_pp_rank:
            return
        connector, metadata = find_dspark_context_connector(
            get_kv_transfer_group(), scheduler_output.kv_connector_metadata
        )
        requests = getattr(metadata, "requests", {})
        if not any(getattr(req_meta, "dspark_context_generation", None) for req_meta in requests.values()):
            return
        state = self.execute_model_state
        if state is None or state.aux_hidden_states is None:
            if scheduler_output.total_num_scheduled_tokens:
                raise RuntimeError("P produced no target auxiliary states for an active remote DSpark request")
            return
        prefix_store = find_dspark_prefix_connector(get_kv_transfer_group(), scheduler_output.kv_connector_metadata)
        send_dspark_prefill_kv(
            self.speculator,
            state.input_batch,
            state.aux_hidden_states,
            requests,
            connector,
            self._dspark_prefill_progress,
            getattr(scheduler_output, "finished_req_ids", ()) or (),
            prefix_connector=prefix_store[0] if prefix_store is not None else None,
            prefix_metadata=prefix_store[1] if prefix_store is not None else None,
        )

    @torch.inference_mode()
    def profile_run(self, randomize_inputs: bool = False) -> None:
        """Override GPUModelRunner.profile_run for Ascend NPUs.
        When running moe models, we need an extra dummy run with mc2_tokens_capacity tokens to reserve
        necessary HCCL buffer for the MC2 operator before standard `profile_run`. Additionally, we set
        override_mrv2_in_profile_run to True to force moe load to be balanced when executing `profile_run`
        """
        sparse_cfg = self.ascend_config.sparse_kv_offload_config
        if sparse_cfg.enabled:
            allocate_kv_offload_topk_profile_buffers(self.get_kv_cache_spec(), self.vllm_config, sparse_cfg)
        profile_kwargs = {"randomize_inputs": randomize_inputs}
        mc2_tokens_capacity = get_mc2_tokens_capacity()
        global_tokens = self.max_num_tokens
        profile_tokens = self._get_pcp_profile_num_tokens()
        with override_mrv2_in_profile_run(True):
            if (
                mc2_tokens_capacity is not None
                and profile_tokens > mc2_tokens_capacity
                and select_moe_comm_method(mc2_tokens_capacity, self.vllm_config)
                in {MoECommType.MC2, MoECommType.FUSED_MC2}
            ):
                # Use a call-scoped bypass because skip_compiled would require runner-specific ForwardContext plumbing.
                with disable_compilation(self.get_model()):
                    self._dummy_run(
                        mc2_tokens_capacity,
                        skip_attn=True,
                        skip_eplb=True,
                        is_profile=True,
                        **profile_kwargs,
                    )
            self.max_num_tokens = profile_tokens
            try:
                super().profile_run(**profile_kwargs)
            finally:
                self.max_num_tokens = global_tokens

    @contextmanager
    def _pcp_decode_plan_scope(self):
        manager = self.pcp_manager
        if manager is not None:
            manager.clear_decode_partition_plan()
        try:
            yield
        finally:
            if manager is not None:
                manager.clear_decode_partition_plan()

    def gather_batch_req_state(self, scheduler_output: SchedulerOutput, dummy_run: bool):
        if self.pcp_manager is not None:
            self.pcp_manager.clear_decode_partition_plan()
        batch_state, uniform_token_count = super().gather_batch_req_state(scheduler_output, dummy_run)
        if self._target_uses_flashmla and batch_state is not None:
            # The backend order must precede derived inputs and graph dispatch.
            batch_state, uniform_token_count = prepare_flashmla_batch_req_state(batch_state, uniform_token_count)
        if (
            batch_state is not None
            and not dummy_run
            and self.pcp_manager is not None
            and self.pcp_manager.decode_balance_enabled
            and not (self.adaptive_verification is not None and scheduler_output.scheduled_spec_decode_tokens)
        ):
            # Scheduler counts are shared across PCP ranks, even when async
            # speculation makes them optimistic. Use them only for cost; keep
            # the existing device-length correction in prepare_inputs intact.
            # No device copy, event wait or collective is added for planning.
            cached = scheduler_output.scheduled_cached_reqs
            contexts = dict(zip(cached.req_ids, cached.num_computed_tokens, strict=True))
            contexts.update((req.req_id, req.num_computed_tokens) for req in scheduler_output.scheduled_new_reqs)
            cost_context_lens = np.fromiter(
                (contexts[req_id] for req_id in batch_state.req_ids), dtype=np.int64, count=len(batch_state.req_ids)
            )
            self.pcp_manager.prepare_decode_partition(
                batch_state.req_ids,
                batch_state.num_scheduled_tokens,
                batch_state.is_prefilling_np,
                cost_context_lens,
            )
        return batch_state, uniform_token_count

    def _check_finegrained_tp_graph_step(self, cg_mode: CUDAGraphMode) -> None:
        # Eager dispatch keeps per-rank token counts; the cross-DP o_proj/MLP exchanges would desync.
        if self._finegrained_tp_requires_graph and cg_mode == CUDAGraphMode.NONE:
            raise RuntimeError(
                "o_proj / MLP TP require every step on a captured graph: this step dispatched "
                "to eager, which desyncs the cross-DP HCCL collectives (mixed or oversized "
                "batch, a request-arrival step misclassified as prefill, or a full prefill "
                "scheduled locally — a request sent directly to the decode node)."
            )

    def prepare_padding_mask(self, num_tokens: int, num_tokens_after_padding: int) -> torch.Tensor:
        # EPLB and decoder replay also consume validity when MoE padding skipping is off.
        mask = self.input_buffers.is_padding[:num_tokens_after_padding]
        mask[:num_tokens].fill_(False)
        mask[num_tokens:].fill_(True)
        return mask

    def _prepare_inputs_impl(
        self,
        scheduler_output: SchedulerOutput,
        batch_req_state: BatchReqState,
        batch_desc: BatchExecutionDescriptor,
    ) -> AscendInputBatch:
        """Shared implementation for GPUModelRunner.prepare_inputs on Ascend.

        npu attention backends need seq_lens_cpu to work, so we prepare
        seq_lens_cpu here.
        """
        self._check_finegrained_tp_graph_step(batch_desc.cg_mode)
        if self.pcp_manager is not None:
            self.pcp_manager.validate_decode_dispatch(batch_desc)
        num_tokens = batch_req_state.num_tokens
        num_tokens_after_padding = max(num_tokens, batch_desc.num_tokens)
        graph_num_reqs = batch_desc.num_reqs
        if (
            self.pcp_manager is not None
            and self.pcp_manager._decode_partition_plan is not None
            and batch_desc.cg_mode != CUDAGraphMode.FULL
        ):
            # Non-FULL dispatch describes local rows (including two segments
            # per prefill), not the global input request-array extent.
            graph_num_reqs = None
        global_graph_num_reqs = (
            self.pcp_manager.get_global_graph_num_reqs(batch_desc) if self.pcp_manager is not None else None
        )
        if global_graph_num_reqs is not None:
            graph_num_reqs = global_graph_num_reqs
            num_tokens_after_padding = global_graph_num_reqs * batch_desc.uniform_token_count
        assert num_tokens > 0

        req_ids = batch_req_state.req_ids

        self._update_seq_lens_cpu(scheduler_output, req_ids)

        num_scheduled_tokens_np = batch_req_state.num_scheduled_tokens
        idx_mapping_np = batch_req_state.idx_mapping_np
        idx_mapping = async_copy_to_gpu(idx_mapping_np, device=self.device)
        num_reqs = len(req_ids)

        num_valid_tokens = num_scheduled_tokens_np
        if scheduler_output.scheduled_spec_decode_tokens:
            num_valid_tokens = np.array(
                [
                    num_toks - len(scheduler_output.scheduled_spec_decode_tokens.get(i, []))
                    for num_toks, i in zip(num_scheduled_tokens_np, req_ids)
                ],
                dtype=np.int32,
            )
        attn_state = build_attn_state(
            self.vllm_config,
            self.input_buffers.seq_lens_np,
            num_reqs,
            num_scheduled_tokens_np,
            num_valid_tokens,
            kv_cache_config=self.kv_cache_config,
        )

        # Get the number of draft tokens for each request.
        draft_tokens = scheduler_output.scheduled_spec_decode_tokens
        num_draft_tokens_per_req = None
        if not draft_tokens:
            # No draft token scheduled (common case).
            total_num_draft_tokens = 0
            total_num_logits = num_reqs
            cu_num_logits_np = np.arange(num_reqs + 1, dtype=np.int32)
            cu_num_logits = torch.arange(num_reqs + 1, device=self.device, dtype=torch.int32)
            expanded_idx_mapping = idx_mapping
            expanded_local_pos = torch.zeros(num_reqs, dtype=torch.int32, device=self.device)
        else:
            num_draft_tokens_per_req = np.fromiter(
                (len(draft_tokens.get(req_id, ())) for req_id in req_ids),
                dtype=np.int32,
                count=num_reqs,
            )
            num_bonus_tokens = self.model_state.num_new_sampled_tokens_per_step
            total_num_draft_tokens = int(num_draft_tokens_per_req.sum())
            total_num_logits = num_reqs * num_bonus_tokens + total_num_draft_tokens
            num_logits = num_draft_tokens_per_req + num_bonus_tokens
            cu_num_logits_np = np.empty(num_reqs + 1, dtype=np.int32)
            cu_num_logits_np[0] = 0
            np.cumsum(num_logits, out=cu_num_logits_np[1:])
            cu_num_logits = async_copy_to_gpu(cu_num_logits_np, device=self.device)

        adaptive_verification_manager = self.adaptive_verification
        adaptive_verification_active = (
            adaptive_verification_manager is not None and num_draft_tokens_per_req is not None
        )
        num_scheduled_tokens_upper_bound = num_scheduled_tokens_np
        admitted_draft_kwargs = {}
        if adaptive_verification_active:
            num_scheduled_tokens_np, cu_num_logits_np = adaptive_verification_manager.compact_batch(
                num_draft_tokens_per_req, num_scheduled_tokens_np, cu_num_logits_np
            )
        # Get query_start_loc.
        # NOTE: For FULL mode we change +1 to +2 to reserve extra space for padding.
        # See _pad_query_start_loc_for_fia.
        # Inputs are still global here; eager PCP descriptors carry local counts.
        num_reqs_padded = max(num_reqs, graph_num_reqs or 0)
        query_start_loc_np = np.empty(self.max_num_reqs + 2, dtype=np.int32)
        query_start_loc_np[0] = 0
        np.cumsum(num_scheduled_tokens_np, out=query_start_loc_np[1 : num_reqs + 1])
        # Pad for full CUDA graph mode.
        # Some attention backends like FA3 require query_start_loc to be non-decreasing.
        query_start_loc_np[num_reqs + 1 :] = num_tokens

        if batch_desc.cg_mode == CUDAGraphMode.FULL and not adaptive_verification_manager:
            # This is only required for vllm-ascend.
            query_start_loc_np, num_reqs_padded = self._pad_query_start_loc_for_fia(
                num_tokens_after_padding,
                num_reqs_padded,
                num_reqs,
                query_start_loc_np,
                batch_desc.cg_mode,
                graph_num_reqs,
                uniform_query_len=batch_desc.uniform_token_count,
            )

        query_start_loc = self.input_buffers.query_start_loc
        async_copy_to_gpu(query_start_loc_np, out=query_start_loc)

        if adaptive_verification_active:
            num_scheduled_draft_tokens = total_num_draft_tokens
            self._log_adaptive_verification_costs(adaptive_verification_manager)
            allocation = adaptive_verification_manager.reallocate_drafts(req_ids, idx_mapping)
            cu_num_logits, query_start_loc, total_num_draft_tokens = allocation[:3]
            if len(allocation) == 4:
                admitted_draft_kwargs["num_admitted_draft_tokens"] = allocation[3]
            total_num_logits = num_reqs * num_bonus_tokens + total_num_draft_tokens
            logger.debug(
                "Adaptive verification budget: requests=%d, scheduled_drafts=%d, admitted_drafts=%d, "
                "padded_tokens=%d, graph_mode=%s",
                num_reqs,
                num_scheduled_draft_tokens,
                total_num_draft_tokens,
                num_tokens_after_padding,
                batch_desc.cg_mode,
            )

            # Non-fia backends skip padding query boundary when using adaptive verification
            if self.use_fia:
                self._sync_adaptive_fia_query_start_loc(
                    query_start_loc_np,
                    query_start_loc,
                    num_reqs,
                    num_scheduled_draft_tokens,
                    total_num_draft_tokens,
                )

        if self.use_fia and adaptive_verification_manager:
            if batch_desc.cg_mode == CUDAGraphMode.FULL:
                query_start_loc_np, num_reqs_padded = self._pad_adaptive_query_start_loc_for_fia(
                    num_tokens_after_padding,
                    num_reqs_padded,
                    num_reqs,
                    query_start_loc_np,
                )

            query_start_loc = self.input_buffers.query_start_loc
            async_copy_to_gpu(query_start_loc_np, out=query_start_loc)

        if draft_tokens:
            expanded_idx_mapping, expanded_local_pos = expand_idx_mapping(
                idx_mapping, total_num_logits, cu_num_logits, self.decode_query_len
            )

        query_start_loc_np = query_start_loc_np[: num_reqs_padded + 1]
        query_start_loc = query_start_loc[: num_reqs_padded + 1]
        self.eplb.set_batch_phase(batch_req_state.has_prefill)

        # Graph dispatch may classify a PD prompt-tail step as decode, but
        # its input still comes from all_token_ids rather than sampled tokens.
        # Keep input preparation tied to the actual prefill progress so the
        # prompt tail and MTP lookahead are populated even on a decode graph.
        if np.any(batch_req_state.num_computed_prefill_tokens_np < batch_req_state.prefill_len_np):
            prepare_prefill_inputs(
                self.input_buffers.input_ids,
                self.req_states.next_prefill_tokens,
                idx_mapping,
                query_start_loc,
                self.req_states.all_token_ids.gpu,
                self.req_states.prefill_len.gpu,
                self.req_states.num_computed_tokens.gpu,
            )

        # Prepare positions and seq_lens.
        prepare_pos_seq_lens(
            idx_mapping,
            query_start_loc,
            self.req_states.num_computed_tokens.gpu,
            self.input_buffers.positions,
            self.input_buffers.seq_lens,
        )
        seq_lens = self.input_buffers.seq_lens[:num_reqs_padded]
        if adaptive_verification_active and self.use_fia:
            self.input_buffers.seq_lens_np[:num_reqs] = seq_lens[:num_reqs].cpu().numpy()

        # Pad for full CUDA graph mode.
        self.input_buffers.seq_lens_np[num_reqs:] = 0

        dcp_local_seq_lens = None
        # Main computes DCP lengths in the inherited execute_model after PCP
        # partitioning (vLLM #55212).

        # Some input token ids are directly read from the last sampled tokens
        # and draft tokens. Also, get the logits indices to sample tokens from.
        logits_indices = combine_sampled_and_draft_tokens(
            self.input_buffers.input_ids,
            idx_mapping,
            self.req_states.last_sampled_tokens,
            query_start_loc,
            seq_lens,
            self.req_states.prefill_len.gpu,
            self.req_states.draft_tokens,
            cu_num_logits,
            total_num_logits,
            self.model_state.num_new_sampled_tokens_per_step,
        )

        # CPU upper bound on seq_lens (num_computed_tokens + num_scheduled_tokens).
        # Added by vLLM PR #40654 to avoid GPU->CPU sync for seq_lens.
        num_computed_tokens_np = self.req_states.num_computed_tokens_np[idx_mapping_np]
        seq_lens_cpu_upper_bound_np = np.zeros(num_reqs_padded, dtype=np.int32)
        np.add(
            num_computed_tokens_np,
            num_scheduled_tokens_upper_bound,
            out=seq_lens_cpu_upper_bound_np[:num_reqs],
        )
        seq_lens_cpu_upper_bound = torch.from_numpy(seq_lens_cpu_upper_bound_np)

        prompt_lens = None
        if self.model_config.rswa_window is not None:
            # prompt_lens is only used in R-SWA case.
            prompt_lens = self.req_states.prompt_len.gpu[idx_mapping]

        pp_kwargs = {"max_seq_len_np": batch_req_state.max_seq_len_np}
        pp_kwargs.update(admitted_draft_kwargs)
        input_batch = AscendInputBatch(
            req_ids=req_ids,
            num_reqs=num_reqs,
            num_reqs_after_padding=num_reqs_padded,
            idx_mapping=idx_mapping,
            idx_mapping_np=idx_mapping_np,
            expanded_idx_mapping=expanded_idx_mapping,
            expanded_local_pos=expanded_local_pos,
            num_scheduled_tokens=num_scheduled_tokens_upper_bound,
            num_tokens=num_tokens,
            num_tokens_after_padding=num_tokens_after_padding,
            num_draft_tokens=total_num_draft_tokens,
            num_draft_tokens_per_req=num_draft_tokens_per_req,
            query_start_loc=query_start_loc,
            query_start_loc_np=query_start_loc_np,
            seq_lens=seq_lens,
            seq_lens_cpu_upper_bound=seq_lens_cpu_upper_bound,
            dcp_local_seq_lens=dcp_local_seq_lens,
            num_computed_tokens_np=num_computed_tokens_np,
            prefill_len_np=batch_req_state.prefill_len_np,
            num_computed_prefill_tokens_np=batch_req_state.num_computed_prefill_tokens_np,
            is_prefilling_np=batch_req_state.is_prefilling_np,
            has_prefill=batch_req_state.has_prefill,
            decode_graph_eligible=batch_req_state.decode_graph_eligible,
            prefill_runs_as_decode_np=batch_req_state.prefill_runs_as_decode_np,
            **pp_kwargs,
            input_ids=self.input_buffers.input_ids[:num_tokens_after_padding],
            positions=self.input_buffers.positions[:num_tokens_after_padding],
            is_padding=self.prepare_padding_mask(num_tokens, num_tokens_after_padding),
            logits_indices=logits_indices,
            cu_num_logits=cu_num_logits,
            cu_num_logits_np=cu_num_logits_np,
            has_structured_output_reqs=scheduler_output.has_structured_output_requests,
            # TODO: only populated for R-SWA (not supported yet).
            prompt_lens=prompt_lens,
            # extra attributes for ascend npus.
            seq_lens_np=self.input_buffers.seq_lens_np,
            attn_state=attn_state,
        )
        # vLLM main (#57980) dropped the module-level maybe_partition_pcp_batch
        # helper; PCPManager.partition_batch now takes the batch descriptor.
        if self.pcp_manager is not None:
            input_batch = self.pcp_manager.partition_batch(input_batch, batch_desc)

        # For mla/sfa, update cos/sin. Here is for execute_model.
        update_cos_sin(input_batch.positions)

        return input_batch

    def prepare_inputs(
        self,
        scheduler_output: SchedulerOutput,
        batch_req_state: BatchReqState,
        batch_desc: BatchExecutionDescriptor,
        num_active_loras: int,  # noqa: ARG002
    ) -> AscendInputBatch:
        # vLLM #56456 added num_active_loras to prepare_inputs on main; it
        # only feeds FastPrefillHelper, which this Ascend path does not use.
        return self._prepare_inputs_impl(scheduler_output, batch_req_state, batch_desc)

    def prepare_dummy_attn(
        self, input_batch: AscendInputBatch, valid_state_slots: bool = False
    ) -> tuple[tuple[torch.Tensor, ...], torch.Tensor]:
        block_tables, slot_mappings = super().prepare_dummy_attn(
            input_batch,
            valid_state_slots=valid_state_slots,
        )
        prepare_v41_dummy_ring_state(self, input_batch.num_reqs)
        slot_mappings = self._maybe_extend_slot_mappings(input_batch, slot_mappings)
        return block_tables, slot_mappings

    def _maybe_extend_slot_mappings(self, input_batch: AscendInputBatch, slot_mappings: torch.Tensor) -> torch.Tensor:
        if input_batch.num_tokens_after_padding > input_batch.num_tokens:
            # The parent already filled the entire persistent slot buffer.
            slot_mappings = self.block_tables.slot_mappings[:, : input_batch.num_tokens_after_padding]
        return slot_mappings

    def _lmhead_tp_max_num_logits(self) -> int:
        """Logits row capacity every rank agrees on (config-derived:
        ``max_num_reqs * decode_query_len``); drift desyncs and hangs."""
        return lmhead_tp_max_num_logits(self.max_num_reqs, self.decode_query_len)

    def _get_lmhead_pad_size(self, execute_model_state) -> int:
        pad_size = self._lmhead_tp_max_num_logits()
        if self.dcp_size == 1 and execute_model_state is not None:
            # vLLM #60754 renamed the stored DP-sync state on main.
            dp_sync = execute_model_state.dp_sync if vllm_version_is("0.31.0") else execute_model_state.dp_sync_state
            if dp_sync is not None:
                pad_size = min(pad_size, int(dp_sync.num_tokens_across_dp.max().item()))
        return pad_size

    def sample(self, hidden_states, input_batch, grammar_output):
        """Override GPUModelRunner.sample for lmhead TP: every rank must feed
        compute_logits the same row count — pad up to ``_lmhead_tp_max_num_logits()``
        and trim back; prompt_logprobs stays unsupported (same as V1)."""
        if not lmhead_tp_enable():
            return super().sample(hidden_states, input_batch, grammar_output)

        num_logits = input_batch.logits_indices.shape[0]
        capacity = getattr(self, "_lmhead_pad_size", None) or self._lmhead_tp_max_num_logits()
        # V1-style index pad: pad a private copy of the indices (input_batch keeps
        # the real ones; the V2 sampler gathers penalties by them) so one gather
        # feeds compute_logits the capacity rows; zero entries gather row 0.
        sample_indices = lmhead_tp_pad_rows(
            input_batch.logits_indices,
            capacity,
            "max_num_reqs * decode_query_len",
        )
        logits = self.model.compute_logits(hidden_states[sample_indices])
        logits = logits[:num_logits]

        # Dispatch tail mirrors GPUModelRunner.sample; refresh it on main bumps.
        invalid_drafts = None
        # A diffusion prefill has no logit rows even when a bitmask row arrived.
        if grammar_output is not None and logits.shape[0] > 0:
            # Apply grammar bitmask to the logits in-place.
            assert self.structured_outputs_worker is not None
            self.structured_outputs_worker.apply_grammar_bitmask(
                logits,
                input_batch,
                grammar_output.structured_output_request_ids,
                grammar_output.grammar_bitmask,
            )
            if vllm_version_is("0.33.0"):
                # 0.33.0 rejects drafts verified against a permissive grammar
                # row; main moved that bookkeeping into the scheduler and the
                # draft-token handler.
                import vllm.v1.worker.gpu.structured_outputs as structured_outputs  # type: ignore[import-not-found]

                invalid_drafts = structured_outputs.grammar_invalid_drafts(  # type: ignore[attr-defined]
                    input_batch,
                    grammar_output.structured_output_request_ids,
                    grammar_output.num_acceptable_drafts,  # type: ignore[attr-defined]
                )

        if input_batch.num_draft_tokens == 0 or self.rejection_sampler is None:
            assert self.sampler is not None
            sampler_output = self.sampler(logits, input_batch)
        else:
            # Rejection sampling for spec decoding.
            assert self.rejection_sampler is not None
            assert self.speculator is not None
            if vllm_version_is("0.33.0"):
                sampler_output = self.rejection_sampler(
                    logits,
                    input_batch,
                    # Draft logits are needed for probabilistic rejection sampling.
                    self.speculator.draft_logits,
                    invalid_drafts,
                )
            else:
                sampler_output = self.rejection_sampler(
                    logits,
                    input_batch,
                    self.speculator.draft_logits,
                )

        return sampler_output, sampler_output.num_sampled, sampler_output.num_rejected

    @contextmanager
    def _preserve_dummy_query_tokens(self, num_tokens: int, uniform_decode: bool):
        # TODO: Remove this workaround once upstream dummy-batch preparation
        # preserves logical query lengths separately from graph padding.
        dummy_query_tokens: int | None = None
        if (
            # FULL modes can also pad requests; only change token-only PIECEWISE padding.
            self.compilation_config.cudagraph_mode == CUDAGraphMode.PIECEWISE
            # PCP prepares and partitions its own dummy input layout.
            and self.pcp_manager is None
        ):
            # Match the logical token count in the upstream dummy scheduler.
            dummy_query_tokens = max(num_tokens, self.decode_query_len) if uniform_decode else num_tokens

        previous_dummy_tokens = self.input_buffers.dummy_num_tokens
        self.input_buffers.dummy_num_tokens = dummy_query_tokens
        try:
            yield
        finally:
            self.input_buffers.dummy_num_tokens = previous_dummy_tokens

    def _get_pcp_profile_num_tokens(self) -> int:
        """Keep replicated draft requests when profiling PCP-local prefill.

        Initial memory profiling precedes KV/PCP-manager initialization.
        Block drafters retain the global budget: their context-KV precompute
        processes all target hidden states, independently of short queries.
        """
        pcp_size = self.vllm_config.parallel_config.prefill_context_parallel_size
        if pcp_size <= 1:
            return self.max_num_tokens
        query_per_req = 1
        spec = self.speculative_config
        if spec is not None:
            # Use shared config, not the last PP rank's speculator instance:
            # every pipeline stage must profile the same target token shape.
            if spec.method not in ("mtp", "eagle", "eagle3"):
                return self.max_num_tokens
            query_per_req = 1 + spec.num_speculative_tokens
        local_tokens = (self.max_num_tokens + pcp_size - 1) // pcp_size
        return min(self.max_num_tokens, max(local_tokens, self.max_num_reqs * query_per_req))

    @step_eplb_after(is_dummy=True)
    def _dummy_run(
        self,
        num_tokens: int,
        *args,
        skip_attn: bool = False,
        uniform_decode: bool = False,
        context_len: int = 0,
        skip_eplb: bool = False,
        is_profile: bool = False,
        **kwargs,
    ):
        """Balanced dummy routing for adaptive-verification profiling; EPLB
        steps via ``step_eplb_after`` (#17233). The lmhead TP join lives in the
        ``execute_model`` tail — joining after ``super()._dummy_run`` deadlocks."""
        skip_ring = bool(kwargs.pop("skip_gdn_state_update", False))
        # Adaptive verification profiles eager tail sizes after graph capture.
        # Use balanced dummy routing, as the initial memory profile does, so a
        # synthetic router hotspot cannot exhaust one EP rank during startup.
        profile_adaptive_tail = self.adaptive_verification is not None and context_len > 0
        if profile_adaptive_tail and self.ascend_config.xlite_graph_config.enabled:
            logger.warning_once(
                "Adaptive verification cost profiling with XLite enabled may "
                "produce inaccurate costs because balanced MoE profiling sets "
                "the profile-run marker, which makes XLite bypass its graph path."
            )
        load_balance_ctx = override_mrv2_in_profile_run(True) if profile_adaptive_tail else nullcontext()
        with (
            # Preserve scheduled query tokens before PIECEWISE graph padding.
            self._preserve_dummy_query_tokens(num_tokens, uniform_decode),
            skip_ring_state_update(skip_ring),
            load_balance_ctx,
        ):
            output = super()._dummy_run(
                num_tokens,
                *args,
                skip_attn=skip_attn,
                uniform_decode=uniform_decode,
                context_len=context_len,
                skip_eplb=True,
                is_profile=is_profile,
                **kwargs,
            )
        # Flush the dump window opened across dummy forwards without writing
        # data, so capture/profiling forwards do not leak into the first real
        # step (v1 parity: v1 finalizes with dump=False at the end of
        # _dummy_run).
        self._finalize_dump_data(dump=False)
        return output

    def _can_skip_spec_cpu_length_sync(self) -> bool:
        """Allow device lengths for supported speculative-decoding paths."""
        if self.sync_spec_pp_cpu_counts:
            return False

        if is_deepseek_v41(self.model_config.hf_config):
            return True

        model_can_skip = getattr(getattr(self, "model_state", None), "can_skip_spec_cpu_length_sync", None)
        if callable(model_can_skip) and model_can_skip() is True:
            return True

        spec = self.speculative_config
        if (  # noqa: SIM103
            spec is not None
            and self.speculator is not None
            and spec.method == "dflash"
            and self.model_config.hf_text_config.model_type in ("glm_moe_dsa", "glm5_next_text")
            and spec.draft_model_config is not None
            and "DFlash2DraftModel" in (spec.draft_model_config.architectures or [])
        ):
            return True

        if spec is None or self.speculator is None or spec.method != "dspark" or spec.draft_model_config is None:
            return False

        draft_architectures = spec.draft_model_config.architectures or ()
        use_flashmla = getattr(self.speculator, "use_flashmla", False)
        # K3.1 SFA/KDA and the FlashMLA draft consume corrected device lengths.
        # The initialized target producer also covers sharded SFA DCP metadata.
        kimi_k31_device_lengths = (
            self.model_config.architecture == "KimiK31ForConditionalGeneration"
            and "K3DSparkModel" in draft_architectures
            and use_flashmla
            and getattr(self.model_state, "device_metadata", None) is not None
        )
        if not kimi_k31_device_lengths and (
            self.model_config.architecture
            not in (
                "MiniMaxM3SparseForCausalLM",
                "MiniMaxM3SparseForConditionalGeneration",
                "GlmMoeDsaForCausalLM",
            )
            or (
                "Qwen3DSparkModel" not in draft_architectures
                and ("Glm5DSparkForCausalLM" not in draft_architectures or not use_flashmla)
            )
        ):
            return False

        # Inspect the initialized draft backends instead of repeating selection
        # rules for hardware, Q dtype and KV dtype. Before set_attn, keep syncing.
        draft_backends = getattr(self.speculator, "attn_backends", {})
        parallel_config = self.parallel_config
        # Keep unverified parallel, offload and adaptive paths on host counts.
        return (
            bool(draft_backends)
            and (
                all(backend is AscendFlashAttentionBackend for backend in draft_backends.values())
                or getattr(self.speculator, "use_flashmla", False)
            )
            and parallel_config.pipeline_parallel_size == 1
            and parallel_config.prefill_context_parallel_size == 1
            and (parallel_config.decode_context_parallel_size == 1 or kimi_k31_device_lengths)
            and not self.ascend_config.sparse_kv_offload_config.enabled
            and not spec.enable_adaptive_verification
        )

    def postprocess_sampled(
        self,
        idx_mapping,
        sampled_tokens,
        num_sampled,
        num_rejected,
        query_start_loc=None,
        draft_tokens=None,
    ):
        """Update device state and refresh exact CPU counts when required."""
        if (
            self.use_pp
            and not self.is_last_pp_rank
            and isinstance(self.model_state, MambaHybridModelState)
            and self.cache_config.mamba_cache_mode == "align"
        ):
            # Deferred PP results belong to an older batch than input_block_tables.
            # Restore its rows before Mamba aligns the accepted recurrent state.
            # Postprocess skips -1 (freed/unsampled) rows; gather needs valid indices.
            self.block_tables.gather_block_tables(idx_mapping.clamp_min(0), idx_mapping.shape[0])
        if draft_tokens is None:
            super().postprocess_sampled(
                idx_mapping,
                sampled_tokens,
                num_sampled,
                num_rejected,
                query_start_loc,
            )
        else:
            # Non-last PP ranks receive drafts from the last rank on both versions.
            super().postprocess_sampled(
                idx_mapping,
                sampled_tokens,
                num_sampled,
                num_rejected,
                query_start_loc,
                draft_tokens,  # type: ignore[call-arg]
            )

        # Non-last PP stages receive rejections without owning a speculator.
        if self.speculator is not None or self.sync_spec_pp_cpu_counts:
            self._copy_num_computed_tokens_to_cpu()

    def postprocess_num_computed_tokens(self, input_batch: AscendInputBatch) -> None:
        super().postprocess_num_computed_tokens(input_batch)
        # Unsampled prefill chunks must also refresh the next step's snapshot.
        if self.sync_spec_pp_cpu_counts:
            self._copy_num_computed_tokens_to_cpu()

    def _copy_num_computed_tokens_to_cpu(self):
        if self._can_skip_spec_cpu_length_sync():
            return

        # Match this D2H and event with the consumer in _update_seq_lens_cpu.
        default_stream = torch.cuda.current_stream()
        assert self.num_computed_tokens_stream is not None
        assert self.num_computed_tokens_cpu is not None
        with torch.npu.stream(self.num_computed_tokens_stream):
            self.num_computed_tokens_stream.wait_stream(default_stream)
            self.num_computed_tokens_cpu.copy_(
                self.req_states.num_computed_tokens.gpu,
                non_blocking=True,
            )
            self.num_computed_tokens_event.record()

    def _update_seq_lens_cpu(
        self,
        scheduler_output: SchedulerOutput,
        req_ids: list[str],
    ):
        num_scheduled_tokens = scheduler_output.num_scheduled_tokens

        # Wait for and consume the snapshot only when its producer runs.
        # req_states.num_computed_tokens_cpu also backs the NumPy view used by PCP.
        if (self.speculator is not None or self.sync_spec_pp_cpu_counts) and not self._can_skip_spec_cpu_length_sync():
            # Blocks CPU submission until D2H completes; may stall the async pipeline.
            self.num_computed_tokens_event.synchronize()
            for req_id in scheduler_output.scheduled_cached_reqs.req_ids:
                req_index = self.req_states.req_id_to_index[req_id]
                self.req_states.num_computed_tokens_cpu[req_index] = self.num_computed_tokens_cpu[req_index]

        # Without a CPU consumer, retain the upstream optimistic upper bound.
        # prepare_pos_seq_lens still reads exact rejection-corrected NPU state.
        for i, req_id in enumerate(req_ids):  # type: ignore
            req_index = self.req_states.req_id_to_index[req_id]
            num_computed_tokens = self.req_states.num_computed_tokens_cpu[req_index]
            self.input_buffers.seq_lens_cpu[i] = num_computed_tokens + num_scheduled_tokens[req_id]

    def _pad_query_start_loc_for_fia(
        self,
        num_tokens_padded: int,
        num_reqs_padded: int,
        num_reqs: int,
        query_start_loc_np: np.ndarray,
        cudagraph_runtime_mode: CUDAGraphMode | None = None,
        batch_desc_num_reqs: int | None = None,
        uniform_query_len: int | None = None,
    ) -> tuple[np.ndarray, int]:
        """
        This function is only designed to satisfied the constraint that when the layout is TND,
        the first dimension of `hidden_states` must equal the last element of `actual_seq_lengths_q`.
        """
        # TODO: need refactor later, related to vllm PR #34043 this pr delete func
        # relax_for_mixed_batch_cudagraphs, num_reqs no longer equals the actual number of requests.
        descriptor_num_reqs = batch_desc_num_reqs if batch_desc_num_reqs is not None else num_reqs_padded
        query_len = uniform_query_len or self.decode_query_len
        # This checks query lengths, not request phase: short prefills can also
        # match. Graph dispatch is responsible for excluding incompatible prefills.
        has_uniform_decode_query_lens = np.all(np.diff(query_start_loc_np[: num_reqs + 1]) == query_len)
        matches_uniform_decode_graph_shape = (
            has_uniform_decode_query_lens and num_tokens_padded == descriptor_num_reqs * query_len
        )
        if (
            cudagraph_runtime_mode == CUDAGraphMode.FULL
            and self.compilation_config.cudagraph_mode == CUDAGraphMode.FULL
            and not matches_uniform_decode_graph_shape
        ):
            num_reqs_padded = num_reqs
        else:
            # Preserve the captured request shape for uniform decode graphs.
            # GDN full graphs capture metadata at request granularity, so
            # collapsing all padded tokens into one request changes the graph
            # topology between capture and replay.
            num_reqs_padded = descriptor_num_reqs

        if has_uniform_decode_query_lens and num_tokens_padded == num_reqs_padded * query_len:
            # Uniform-batch case: num_reqs must be no greater than num_reqs_padded
            assert num_reqs <= num_reqs_padded

            last_loc = query_start_loc_np[num_reqs]
            query_start_loc_np[num_reqs + 1 : num_reqs_padded + 1] = (
                np.arange(1, num_reqs_padded + 1 - num_reqs) * query_len + last_loc
            )
        else:
            # Mixed-batch case: num_reqs must equal num_reqs_padded
            assert num_reqs == num_reqs_padded

            # Insert a dummy request instead of setting query_start_loc[num_reqs] = num_tokens_padded directly
            query_start_loc_np[num_reqs_padded + 1] = num_tokens_padded
            num_reqs_padded = num_reqs_padded + 1

        return query_start_loc_np, num_reqs_padded

    def _start_dump_data(self, **kwargs) -> None:
        if self.debugger is None or self._debugger_started:
            return
        self.debugger.start(self.model, **kwargs)
        self._debugger_started = True

    def _finalize_dump_data(self, **kwargs) -> None:
        if self.debugger is None or not self._debugger_started:
            return
        if hasattr(self.debugger, "stop"):
            self.debugger.stop()
            self._debugger_started = False

        self.debugger.step(**kwargs)

    @staticmethod
    def _log_adaptive_verification_costs(manager: Any) -> None:
        if not logger.isEnabledFor(logging.DEBUG):
            return
        scheduled, non_draft, budget = manager._batch_budget
        req_ids = list(scheduled)
        slots = [manager.req_states.req_id_to_index[req_id] for req_id in req_ids]
        confidence = manager._stale_confidences[manager._stale_idx].np[slots].astype(np.float64)
        capacities = np.array(list(scheduled.values()))
        valid = np.arange(manager.num_speculative_steps)[None, :] < capacities[:, None]
        scores = np.sort(np.cumprod(confidence, axis=1)[valid])[::-1]
        max_budget = min(len(scores), max(0, manager._max_total_logits - len(req_ids) * manager.num_bonus_tokens))
        accepted = np.concatenate(([0.0], np.cumsum(scores[:max_budget])))
        base_tokens = sum(non_draft.values())
        draft_cost, verify_cost = manager.cost_tables
        confidence_by_step = [
            float(confidence[valid[:, i], i].mean()) for i in range(confidence.shape[1]) if valid[:, i].any()
        ]
        logger.debug(
            "Adaptive verification costs: budget=%d/%d, base_tokens=%d, draft_ms=%.6f, "
            "verify_ms(zero/chosen/full)=%s, expected_accepted_drafts(chosen/full)=%s, "
            "mean_confidence_by_step=%s",
            budget,
            max_budget,
            base_tokens,
            float(draft_cost[len(req_ids)]),
            [float(verify_cost[base_tokens + n]) for n in (0, budget, max_budget)],
            [float(accepted[n]) for n in (budget, max_budget)],
            confidence_by_step,
        )

    @staticmethod
    def _sync_adaptive_fia_query_start_loc(
        query_start_loc_np: np.ndarray,
        query_start_loc: torch.Tensor,
        num_reqs: int,
        num_scheduled_draft_tokens: int,
        num_admitted_draft_tokens: int,
    ) -> None:
        # compact_batch already gives exact host boundaries for full and zero
        # budgets. Partial budgets may redistribute them on device.
        if 0 < num_admitted_draft_tokens < num_scheduled_draft_tokens:
            query_start_loc_np[: num_reqs + 1] = query_start_loc[: num_reqs + 1].cpu().numpy()
        query_start_loc_np[num_reqs + 1 :] = int(query_start_loc_np[num_reqs])

    def _pad_adaptive_query_start_loc_for_fia(
        self,
        num_tokens_padded: int,
        num_reqs_padded: int,
        num_reqs: int,
        query_start_loc_np: np.ndarray,
    ) -> tuple[np.ndarray, int]:
        """Pad adaptive query boundary to the captured FULL graph request shape."""
        last_loc = int(query_start_loc_np[num_reqs])
        num_padding_tokens = num_tokens_padded - last_loc
        num_padding_reqs = num_reqs_padded - num_reqs
        assert num_padding_tokens >= 0 and num_padding_reqs >= 0

        if num_padding_reqs == 0:
            if num_padding_tokens > 0:
                query_start_loc_np[num_reqs + 1] = num_tokens_padded
                num_reqs_padded += 1
            return query_start_loc_np, num_reqs_padded

        cumulative_padding = np.arange(1, num_padding_reqs + 1, dtype=np.int32) * num_padding_tokens // num_padding_reqs
        query_start_loc_np[num_reqs + 1 : num_reqs_padded + 1] = last_loc + cumulative_padding
        return query_start_loc_np, num_reqs_padded


@contextmanager
def graph_manager_wrapper(model_runner):
    """Context manager to override graph manager."""
    original_graph_manager = vllm_model_runner.ModelCudaGraphManager

    def factory(  # type: ignore[misc]
        vllm_config: VllmConfig,
        device: torch.device,
        cudagraph_mode: CUDAGraphMode,
        decode_query_len: int | None = None,
        lora_capture_cases: list[int] | None = None,
        varlen_decode: bool = False,
        ubatch_runner: Any = None,
        *,
        decode_query_lens: Mapping[int, int] | None = None,
    ):
        query_shapes = decode_query_len if vllm_version_is("0.33.0") else decode_query_lens
        assert query_shapes is not None
        return ModelAclGraphManager(
            vllm_config,
            device,
            cudagraph_mode,
            query_shapes,
            model_runner,
            lora_capture_cases=lora_capture_cases,
            varlen_decode=varlen_decode,
            ubatch_runner=ubatch_runner,
        )

    try:
        vllm_model_runner.ModelCudaGraphManager = factory
        yield
    finally:
        vllm_model_runner.ModelCudaGraphManager = original_graph_manager
