"""Run the new CPU metadata tests from real source without torch/vLLM imports.

This extracts production classes/methods. Device partitioning, graph dispatch
and the surrounding runtime are stubbed; this is not the full repository UT.
"""

from __future__ import annotations

import argparse
import ast
import dataclasses
import math
import sys
import types
import unittest
import unittest.mock
from contextlib import contextmanager
from dataclasses import dataclass, replace
from enum import Enum
from pathlib import Path
from typing import Any, Literal

import numpy as np
from pydantic import ConfigDict, Field
from pydantic.dataclasses import dataclass as validated_dataclass

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--repo", type=Path, default=ROOT / "vllm-ascend-main-lb")
REPO = parser.parse_args().repo.resolve()


class Mode(Enum):
    NONE = 0
    PIECEWISE = 1
    FULL = 2
    FULL_DECODE_ONLY = 3


@dataclass(frozen=True)
class Descriptor:
    cg_mode: Mode
    num_tokens: int
    num_reqs: int | None = None
    uniform_token_count: int | None = None


class ParentPCP:
    def get_num_tokens_for_dispatch(self, counts, prefilling):
        return max(sum(q for _, _, q in self._iter_rank_chunks(r, counts, prefilling)) for r in range(self.pcp_world_size))

    def partition_batch(self, batch, descriptor):
        raise AssertionError("Device partition must be explicitly stubbed")


class ParentRunner:
    def gather_batch_req_state(self, scheduler, dummy):
        raise AssertionError("Parent gather must be explicitly stubbed")


def policy(config):
    return config.parallel_config.prefill_context_parallel_size > 1 and config.parallel_config.decode_context_parallel_size == 1


def module(name, env):
    result = types.ModuleType(name)
    result.__dict__.update(env)
    sys.modules[name] = result
    return result


def execute_nodes(nodes, mod, filename):
    code = compile(ast.Module(body=nodes, type_ignores=[]), str(filename), "exec", flags=0x1000000)
    exec(code, mod.__dict__)


pcp_path = REPO / "vllm_ascend/worker/v2/pcp_manager.py"
pcp = module("validation_pcp", dict(np=np, math=math, dataclass=dataclass, replace=replace, Literal=Literal,
    PCPManager=ParentPCP, CUDAGraphMode=Mode, is_pcp_decode_sharding_enabled=policy,
    vllm_version_is=lambda _: False, AscendInputBatch=types.SimpleNamespace))
pcp_nodes = [n for n in ast.parse(pcp_path.read_text(encoding="utf-8")).body
             if isinstance(n, ast.ClassDef) and n.name in ("PCPDecodePartitionPlan", "AscendPCPManager")]
execute_nodes(pcp_nodes, pcp, pcp_path)

runner_path = REPO / "vllm_ascend/worker/v2/model_runner.py"
runner = module("validation_runner", dict(np=np, contextmanager=contextmanager, GPUModelRunner=ParentRunner,
    prepare_flashmla_batch_req_state=lambda batch, uniform: (batch, uniform)))
cls = next(n for n in ast.parse(runner_path.read_text(encoding="utf-8")).body if isinstance(n, ast.ClassDef) and n.name == "NPUModelRunner")
cls.body = [n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name in ("_pcp_decode_plan_scope", "gather_batch_req_state")]
execute_nodes([cls], runner, runner_path)

dispatch_path = REPO / "vllm_ascend/patch/worker/patch_model_runner.py"
dispatch = module("validation_dispatch", dict(is_pcp_decode_sharding_enabled=policy, _dispatch_cg_and_sync_dp=lambda *args, **kwargs: None))
execute_nodes([n for n in ast.parse(dispatch_path.read_text(encoding="utf-8")).body
               if isinstance(n, ast.FunctionDef) and n.name == "dispatch_cg_and_sync_dp"], dispatch, dispatch_path)

config_path = REPO / "vllm_ascend/ascend_config.py"
config = module("validation_config", dict(Field=Field, Literal=Literal, Any=Any, dataclasses=dataclasses))
cls = next(n for n in ast.parse(config_path.read_text(encoding="utf-8")).body if isinstance(n, ast.ClassDef) and n.name == "AscendConfig")
cls.decorator_list = []
cls.body = [n for n in cls.body if isinstance(n, ast.AnnAssign)
            and (n.target.id.startswith("pcp_decode_balance_") or n.target.id == "sparse_kv_offload_config")]
execute_nodes([cls], config, config_path)
Config = validated_dataclass(config.AscendConfig, config=ConfigDict(extra="forbid"))

test_path = REPO / "tests/ut/worker/test_pcp_decode_balance.py"
tests = module("validation_tests", dict(TestCase=unittest.TestCase, np=np, SimpleNamespace=types.SimpleNamespace,
    Mock=unittest.mock.Mock, patch=unittest.mock.patch, CUDAGraphMode=Mode, BatchExecutionDescriptor=Descriptor,
    AscendPCPManager=pcp.AscendPCPManager, PCPManager=ParentPCP, NPUModelRunner=runner.NPUModelRunner,
    GPUModelRunner=ParentRunner, pcp_module=pcp, runner_module=runner, dispatch_module=dispatch, AscendConfig=Config))
execute_nodes([n for n in ast.parse(test_path.read_text(encoding="utf-8")).body if not isinstance(n, (ast.Import, ast.ImportFrom))], tests, test_path)
result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(tests))
sys.exit(not result.wasSuccessful())
